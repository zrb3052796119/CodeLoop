"""Python port of MiniCode."""

