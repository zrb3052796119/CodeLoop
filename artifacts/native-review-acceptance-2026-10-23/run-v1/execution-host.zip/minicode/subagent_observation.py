"""Versioned, content-free sub-agent completion event contract.

A sub-agent runs a full nested agent loop, but its internal events must not
be written into the parent Run's event stream: readers such as
``skill_evidence`` require exactly one ``task.outcome`` and one
``skill.routed`` per Run, so forwarding the nested loop's own lifecycle
events would silently disqualify every Run that used a sub-agent.

Instead the parent Run records one bounded summary event per sub-agent
invocation. It carries counts and a closed outcome enum only — never the
sub-agent's prompt, findings, tool arguments, or file paths.
"""

from __future__ import annotations

import re
from collections.abc import Mapping

from minicode.run_events import emit_event_safely

SUBAGENT_EVENT_TYPE = "subagent.completed"

_AGENT_TYPES = frozenset({"explore", "plan", "general", "workflow"})


def _is_known_agent_type(agent_type: str) -> bool:
    """Built-in agent types plus valid project-profile type names."""
    from minicode.subagent_profiles import AGENT_NAME_RE

    return agent_type in _AGENT_TYPES or AGENT_NAME_RE.fullmatch(agent_type) is not None

_OUTCOMES = frozenset(
    {
        "completed",
        "failed",
        "depth_rejected",
        "budget_exceeded",
        "timed_out",
        "cancelled",
    }
)
_MAX_COUNT = 100_000
_MAX_DURATION_MS = 86_400_000
_SUBAGENT_ID_RE = re.compile(r"^sub_[0-9a-f]{32}$")
_RESULT_CONTRACT_STATUSES = frozenset(
    {"reported", "fallback", "derived", "unavailable"}
)
_UNSET_TURN_LIMIT = object()
_V1_FIELDS = frozenset(
    {
        "subagentVersion",
        "agentType",
        "outcome",
        "modelTurns",
        "toolCalls",
        "durationMs",
        "maxTurns",
        "resultTruncated",
    }
)
_V2_FIELDS = frozenset(
    {
        "subagentVersion",
        "agentType",
        "outcome",
        "modelTurns",
        "toolCalls",
        "durationMs",
        "modelTurnLimit",
        "phaseCount",
        "maxPhases",
        "resultTruncated",
    }
)
_V3_FIELDS = frozenset(
    {
        "subagentVersion",
        "subagentId",
        "agentType",
        "outcome",
        "modelTurns",
        "toolCalls",
        "durationMs",
        "modelTurnLimit",
        "phaseCount",
        "maxPhases",
        "resultTruncated",
        "resultContractStatus",
    }
)
# v4 = v3 + ``resultPartial``: a soft-landed run exhausted its model-turn
# limit and its summary comes from one tool-free closing turn. Its modelTurns
# counts admitted provider calls, which in-step retries already inflate
# beyond the step limit (pre-partial incident journals show 13-14 against a
# limit of 12), so v4 deliberately keeps only the generic _MAX_COUNT bound
# instead of v3's step-limit invariant. v1-v3 payloads keep their exact
# shapes so stored journals written by older versions still normalize.
_V4_FIELDS = frozenset(_V3_FIELDS | {"resultPartial"})
# v5 = v4 + ``continuedFromSubagentId``: this run resumed a finished
# read-only sub-agent's stored conversation. The marker is content-free —
# an opaque id only — so adoption stays measurable without ever carrying
# prompts or findings into the observation stream.
_V5_FIELDS = frozenset(_V4_FIELDS | {"continuedFromSubagentId"})


def normalize_subagent_payload(
    payload: Mapping[str, object],
) -> dict[str, object] | None:
    """Return the strict v1/v2 whitelist or ``None`` for invalid input.

    An unexpected field is rejected outright rather than quietly dropped: a
    payload carrying anything beyond this contract means the caller is not
    the contract's owner, and silently accepting it would let a future
    change smuggle content into a stream that is required to stay bounded
    and content-free.
    """
    if not isinstance(payload, dict):
        return None
    if payload.get("subagentVersion") == 1:
        return _normalize_v1(payload)
    if payload.get("subagentVersion") == 2:
        return _normalize_v2(payload)
    if payload.get("subagentVersion") == 3:
        return _normalize_v3(payload)
    if payload.get("subagentVersion") == 4:
        return _normalize_v4(payload)
    if payload.get("subagentVersion") == 5:
        return _normalize_v5(payload)
    return None


def _normalize_v1(payload: Mapping[str, object]) -> dict[str, object] | None:
    if set(payload) != _V1_FIELDS:
        return None
    agent_type = payload.get("agentType")
    outcome = payload.get("outcome")
    model_turns = payload.get("modelTurns")
    tool_calls = payload.get("toolCalls")
    duration_ms = payload.get("durationMs")
    max_turns = payload.get("maxTurns")
    result_truncated = payload.get("resultTruncated")
    counts = (model_turns, tool_calls, duration_ms)
    if (
        not _is_known_agent_type(agent_type)
        or outcome not in _OUTCOMES
        or any(
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
            for value in counts
        )
        or (max_turns is not None and (
            isinstance(max_turns, bool) or not isinstance(max_turns, int)
            or not 0 <= max_turns <= _MAX_COUNT
        ))
        or any(value > _MAX_COUNT for value in (model_turns, tool_calls))
        or duration_ms > _MAX_DURATION_MS
        or not isinstance(result_truncated, bool)
    ):
        return None
    return {
        "subagentVersion": 1,
        "agentType": agent_type,
        "outcome": outcome,
        "modelTurns": model_turns,
        "toolCalls": tool_calls,
        "durationMs": duration_ms,
        "maxTurns": max_turns,
        "resultTruncated": result_truncated,
    }


def _normalize_v2(payload: Mapping[str, object]) -> dict[str, object] | None:
    """Workflow-only schema separating model-call and orchestration limits."""
    if set(payload) != _V2_FIELDS:
        return None
    agent_type = payload.get("agentType")
    outcome = payload.get("outcome")
    model_turns = payload.get("modelTurns")
    tool_calls = payload.get("toolCalls")
    duration_ms = payload.get("durationMs")
    model_turn_limit = payload.get("modelTurnLimit")
    phase_count = payload.get("phaseCount")
    max_phases = payload.get("maxPhases")
    result_truncated = payload.get("resultTruncated")
    required_counts = (
        model_turns,
        tool_calls,
        duration_ms,
        phase_count,
        max_phases,
    )
    if (
        agent_type != "workflow"
        or outcome not in _OUTCOMES
        or any(
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
            for value in required_counts
        )
        or isinstance(model_turn_limit, bool)
        or (
            model_turn_limit is not None
            and (
                not isinstance(model_turn_limit, int)
                or model_turn_limit < 0
                or model_turn_limit > _MAX_COUNT
            )
        )
        or any(
            value > _MAX_COUNT
            for value in (model_turns, tool_calls, phase_count, max_phases)
        )
        or duration_ms > _MAX_DURATION_MS
        or max_phases < 1
        or phase_count > max_phases
        or (
            model_turn_limit is not None
            and model_turns > model_turn_limit
        )
        or not isinstance(result_truncated, bool)
    ):
        return None
    return {
        "subagentVersion": 2,
        "agentType": agent_type,
        "outcome": outcome,
        "modelTurns": model_turns,
        "toolCalls": tool_calls,
        "durationMs": duration_ms,
        "modelTurnLimit": model_turn_limit,
        "phaseCount": phase_count,
        "maxPhases": max_phases,
        "resultTruncated": result_truncated,
    }


def _normalize_v3(payload: Mapping[str, object]) -> dict[str, object] | None:
    """Unified, correlatable schema for direct agents and workflows."""
    if set(payload) != _V3_FIELDS:
        return None
    subagent_id = payload.get("subagentId")
    agent_type = payload.get("agentType")
    outcome = payload.get("outcome")
    model_turns = payload.get("modelTurns")
    tool_calls = payload.get("toolCalls")
    duration_ms = payload.get("durationMs")
    model_turn_limit = payload.get("modelTurnLimit")
    phase_count = payload.get("phaseCount")
    max_phases = payload.get("maxPhases")
    result_truncated = payload.get("resultTruncated")
    result_contract_status = payload.get("resultContractStatus")
    required_counts = (
        model_turns,
        tool_calls,
        duration_ms,
        phase_count,
        max_phases,
    )
    if (
        not isinstance(subagent_id, str)
        or _SUBAGENT_ID_RE.fullmatch(subagent_id) is None
        or not _is_known_agent_type(agent_type)
        or outcome not in _OUTCOMES
        or any(
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
            for value in required_counts
        )
        or isinstance(model_turn_limit, bool)
        or (
            model_turn_limit is not None
            and (
                not isinstance(model_turn_limit, int)
                or model_turn_limit < 0
                or model_turn_limit > _MAX_COUNT
            )
        )
        or any(
            value > _MAX_COUNT
            for value in (model_turns, tool_calls, phase_count, max_phases)
        )
        or duration_ms > _MAX_DURATION_MS
        or max_phases < 1
        or phase_count > max_phases
        or not isinstance(result_truncated, bool)
        or result_contract_status not in _RESULT_CONTRACT_STATUSES
        or (
            outcome == "completed"
            and result_contract_status == "unavailable"
        )
    ):
        return None
    return {
        "subagentVersion": 3,
        "subagentId": subagent_id,
        "agentType": agent_type,
        "outcome": outcome,
        "modelTurns": model_turns,
        "toolCalls": tool_calls,
        "durationMs": duration_ms,
        "modelTurnLimit": model_turn_limit,
        "phaseCount": phase_count,
        "maxPhases": max_phases,
        "resultTruncated": result_truncated,
        "resultContractStatus": result_contract_status,
    }


def _normalize_v4(payload: Mapping[str, object]) -> dict[str, object] | None:
    """v3 plus the soft-landing marker, without the step-limit invariant.

    ``modelTurns`` counts admitted provider calls; in-step retries (empty
    responses, recoverable thinking, unfinished actions) already push it past
    the step limit on ordinary runs, and a soft landing adds one closing
    turn. The count stays bounded by ``_MAX_COUNT`` like every other field.
    """
    if set(payload) != _V4_FIELDS:
        return None
    subagent_id = payload.get("subagentId")
    agent_type = payload.get("agentType")
    outcome = payload.get("outcome")
    model_turns = payload.get("modelTurns")
    tool_calls = payload.get("toolCalls")
    duration_ms = payload.get("durationMs")
    model_turn_limit = payload.get("modelTurnLimit")
    phase_count = payload.get("phaseCount")
    max_phases = payload.get("maxPhases")
    result_truncated = payload.get("resultTruncated")
    result_contract_status = payload.get("resultContractStatus")
    result_partial = payload.get("resultPartial")
    required_counts = (
        model_turns,
        tool_calls,
        duration_ms,
        phase_count,
        max_phases,
    )
    if (
        not isinstance(subagent_id, str)
        or _SUBAGENT_ID_RE.fullmatch(subagent_id) is None
        or not _is_known_agent_type(agent_type)
        or outcome not in _OUTCOMES
        or any(
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
            for value in required_counts
        )
        or isinstance(model_turn_limit, bool)
        or (
            model_turn_limit is not None
            and (
                not isinstance(model_turn_limit, int)
                or model_turn_limit < 0
                or model_turn_limit > _MAX_COUNT
            )
        )
        or any(
            value > _MAX_COUNT
            for value in (model_turns, tool_calls, phase_count, max_phases)
        )
        or duration_ms > _MAX_DURATION_MS
        or max_phases < 1
        or phase_count > max_phases
        or not isinstance(result_truncated, bool)
        or result_contract_status not in _RESULT_CONTRACT_STATUSES
        # The marker is the reason v4 exists; a non-partial run stays on v3.
        or result_partial is not True
        or (
            outcome == "completed"
            and result_contract_status == "unavailable"
        )
    ):
        return None
    return {
        "subagentVersion": 4,
        "subagentId": subagent_id,
        "agentType": agent_type,
        "outcome": outcome,
        "modelTurns": model_turns,
        "toolCalls": tool_calls,
        "durationMs": duration_ms,
        "modelTurnLimit": model_turn_limit,
        "phaseCount": phase_count,
        "maxPhases": max_phases,
        "resultTruncated": result_truncated,
        "resultContractStatus": result_contract_status,
        "resultPartial": True,
    }


def _normalize_v5(payload: Mapping[str, object]) -> dict[str, object] | None:
    if set(payload) != _V5_FIELDS:
        return None
    subagent_id = payload.get("subagentId")
    agent_type = payload.get("agentType")
    outcome = payload.get("outcome")
    model_turns = payload.get("modelTurns")
    tool_calls = payload.get("toolCalls")
    duration_ms = payload.get("durationMs")
    model_turn_limit = payload.get("modelTurnLimit")
    phase_count = payload.get("phaseCount")
    max_phases = payload.get("maxPhases")
    result_truncated = payload.get("resultTruncated")
    result_contract_status = payload.get("resultContractStatus")
    result_partial = payload.get("resultPartial")
    continued_from = payload.get("continuedFromSubagentId")
    required_counts = (
        model_turns,
        tool_calls,
        duration_ms,
        phase_count,
        max_phases,
    )
    if (
        not isinstance(subagent_id, str)
        or _SUBAGENT_ID_RE.fullmatch(subagent_id) is None
        or not _is_known_agent_type(agent_type)
        or outcome not in _OUTCOMES
        or any(
            isinstance(value, bool)
            or not isinstance(value, int)
            or value < 0
            for value in required_counts
        )
        or isinstance(model_turn_limit, bool)
        or (
            model_turn_limit is not None
            and (
                not isinstance(model_turn_limit, int)
                or model_turn_limit < 0
                or model_turn_limit > _MAX_COUNT
            )
        )
        or any(
            value > _MAX_COUNT
            for value in (model_turns, tool_calls, phase_count, max_phases)
        )
        or duration_ms > _MAX_DURATION_MS
        or max_phases < 1
        or phase_count > max_phases
        or not isinstance(result_truncated, bool)
        or result_contract_status not in _RESULT_CONTRACT_STATUSES
        or not isinstance(result_partial, bool)
        or (
            outcome == "completed"
            and result_contract_status == "unavailable"
        )
        # The continuation marker is the reason v5 exists. Unlike v4's
        # resultPartial, a continuation run may complete normally, so the
        # boolean stays free; the id itself must be canonical or absent.
        or not (
            continued_from is None
            or (
                isinstance(continued_from, str)
                and _SUBAGENT_ID_RE.fullmatch(continued_from) is not None
            )
        )
    ):
        return None
    return {
        "subagentVersion": 5,
        "subagentId": subagent_id,
        "agentType": agent_type,
        "outcome": outcome,
        "modelTurns": model_turns,
        "toolCalls": tool_calls,
        "durationMs": duration_ms,
        "modelTurnLimit": model_turn_limit,
        "phaseCount": phase_count,
        "maxPhases": max_phases,
        "resultTruncated": result_truncated,
        "resultContractStatus": result_contract_status,
        "resultPartial": result_partial,
        "continuedFromSubagentId": continued_from,
    }


def project_subagent_event(
    *,
    agent_type: str,
    outcome: str,
    model_turns: int,
    tool_calls: int,
    duration_ms: int,
    max_turns: int | None | object = _UNSET_TURN_LIMIT,
    model_turn_limit: int | None = None,
    phase_count: int | None = None,
    max_phases: int | None = None,
    result_truncated: bool,
    subagent_id: str | None = None,
    result_contract_status: str | None = None,
    result_partial: bool = False,
    continued_from_subagent_id: str | None = None,
) -> dict[str, object] | None:
    """Build a strict payload, preserving v1/v2 reader compatibility.

    Producers that provide parent-owned correlation fields get the unified v3
    schema. Omitting both fields retains the legacy v1/v2 projector for stored
    journal replay and compatibility tests. ``result_partial=True`` marks a
    soft-landed run and upgrades the payload to v4, which drops v3's
    step-limit invariant (in-step retries and the closing turn legitimately
    push the provider-call count past the limit); non-partial runs stay on
    v3.
    """
    if subagent_id is not None or result_contract_status is not None:
        if subagent_id is None or result_contract_status is None:
            return None
        is_workflow = phase_count is not None or max_phases is not None
        if is_workflow:
            if phase_count is None or max_phases is None or max_turns not in (None, _UNSET_TURN_LIMIT):
                return None
            projected_phase_count = phase_count
            projected_max_phases = max_phases
            projected_model_limit = model_turn_limit
        else:
            if max_turns is _UNSET_TURN_LIMIT or model_turn_limit is not None:
                return None
            projected_phase_count = 1 if outcome == "completed" else 0
            projected_max_phases = 1
            projected_model_limit = max_turns
        v3_payload: dict[str, object] = {
            "subagentVersion": 3,
            "subagentId": subagent_id,
            "agentType": agent_type,
            "outcome": outcome,
            "modelTurns": model_turns,
            "toolCalls": tool_calls,
            "durationMs": duration_ms,
            "modelTurnLimit": projected_model_limit,
            "phaseCount": projected_phase_count,
            "maxPhases": projected_max_phases,
            "resultTruncated": result_truncated,
            "resultContractStatus": result_contract_status,
        }
        if continued_from_subagent_id is not None and not is_workflow:
            # A continuation resumes a finished read-only run; it can
            # complete normally or soft-land, so resultPartial stays a
            # free boolean and the marker upgrades the payload to v5.
            return normalize_subagent_payload(
                {
                    **v3_payload,
                    "subagentVersion": 5,
                    "resultPartial": result_partial,
                    "continuedFromSubagentId": continued_from_subagent_id,
                }
            )
        if result_partial:
            # A workflow's phases soft-land individually; the workflow-level
            # event has no single closing turn to account for.
            if is_workflow:
                return None
            return normalize_subagent_payload(
                {
                    **v3_payload,
                    "subagentVersion": 4,
                    "resultPartial": True,
                }
            )
        return normalize_subagent_payload(v3_payload)
    if phase_count is not None or max_phases is not None:
        if phase_count is None or max_phases is None or max_turns not in (None, _UNSET_TURN_LIMIT):
            return None
        return normalize_subagent_payload(
            {
                "subagentVersion": 2,
                "agentType": agent_type,
                "outcome": outcome,
                "modelTurns": model_turns,
                "toolCalls": tool_calls,
                "durationMs": duration_ms,
                "modelTurnLimit": model_turn_limit,
                "phaseCount": phase_count,
                "maxPhases": max_phases,
                "resultTruncated": result_truncated,
            }
        )
    if max_turns is _UNSET_TURN_LIMIT or model_turn_limit is not None:
        return None
    return normalize_subagent_payload(
        {
            "subagentVersion": 1,
            "agentType": agent_type,
            "outcome": outcome,
            "modelTurns": model_turns,
            "toolCalls": tool_calls,
            "durationMs": duration_ms,
            "maxTurns": max_turns,
            "resultTruncated": result_truncated,
        }
    )


def emit_subagent_observation(context: object, **fields: object) -> None:
    """Record one bounded sub-agent summary without affecting execution."""
    sink = getattr(context, "_event_sink", None)
    if sink is None:
        return
    try:
        payload = project_subagent_event(**fields)
        if payload is None:
            return
        emit_event_safely(
            sink,
            SUBAGENT_EVENT_TYPE,
            step=getattr(context, "_step", None),
            payload=payload,
        )
    except Exception:  # noqa: BLE001 - observation must never affect the result
        pass


__all__ = [
    "SUBAGENT_EVENT_TYPE",
    "emit_subagent_observation",
    "normalize_subagent_payload",
    "project_subagent_event",
]
