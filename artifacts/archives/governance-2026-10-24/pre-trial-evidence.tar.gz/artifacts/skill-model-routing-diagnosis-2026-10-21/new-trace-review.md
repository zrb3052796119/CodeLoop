# Fresh before/after 轨迹独立复核

本次提示澄清没有改善观察到的发现或严格采用：before **7/36**，after **5/36**。两臂 60 次正例未加载全部没有尝试发现，仍不能把它们称为工具故障。全部 120 记录完成；本复核未改动冻结输入、评分或原始记录。

| 指标 | Fresh before | Fresh after |
|---|---:|---:|
| 正例无加载 | 29/36 | 31/36 |
| 无加载且尝试发现 | 0/29 | 0/31 |
| 正例发现、正确加载且正文交接 | 7/36 | 5/36 |
| 正例错加载 | 0/36 | 0/36 |
| 正例严格 JSON 任务通过 | 21/36 | 23/36 |
| 无加载子集严格任务通过（仅描述性） | 17/29 | 19/31 |
| 负例正文曝光 | 0/24 | 0/24 |
| 不存在名称的被拒加载尝试 | 0 | 2（同一次运行） |

无加载子集由行为结果筛出，不能用其通过率估计提示的任务质量效应。旧实验 24/36 无加载、14/24 严格任务通过只是历史参照；本次配对前臂是全新运行的 29/36，不能混用。

## 目录、发现和正文链路

两个变体的每个正例 HTTP 请求均包含 **66 张目录卡**与 browse/search/load 三个 schema，所有目标目录均可见。全部无加载运行在 16 步预算内正常完成（before 2–8 步，after 2–10 步）。没有目录卡/schema 丢失、正例发现错误、分页截断、正例权限拒绝或预算耗尽的观察证据。

正例 12 次发现全部使用 browse，一次发现后都正确加载、通过实际正文交接验证；没有“发现成功后弃用”或错加载样本。C03-before-C-r1 加载 queue/idempotency、queue/idempotent-consumer-template 和 api/error-contract；两个 queue 名称都在冻结等价能力组允许集合内，不计错加载。调用成功不等于所有未调用路径无缺陷，只能排除这些轨迹中的实际调用失败解释。

## 60 次未加载的答案与条件

| 冻结诊断类别 | Before（29） | After（31） |
|---|---:|---:|
| 严格 JSON 与字段全部通过 | 17 | 19 |
| 有额外文字，但唯一 JSON 对象精确匹配 | 9 | 8 |
| 纯 JSON 的 C02 未公开类型问题 | 1 | 1 |
| JSON 解析失败且抽取对象也不完全匹配 | 1 | 2 |
| 合法 JSON 的字段精确验收失败 | 1 | 1 |

这些任务本身仍可合理通过普通证据读取完成；“可以不用 Skill”不等于“实际答案一定正确”。除 C01-before-C-r2 使用完整 grep 输出外，每次都成功读到了冻结阶段列出的全部证据文件。C01-before-C-r2 先在第 1 步 grep 出 ci.json 全部 JSON 行，再第 2 步 grep tests.json，已取得所需事实。

逐项复核后的重要例外：

- **C02 四次类型约定不足**：before-r1/r3、after-r1/r2 的 provider_followup 是说明字符串或对象，题面没有要求布尔；其中 before-r3 和 after-r1 还带额外文字，所以冻结互斥诊断将它们归为 parse_failure。原分数保留，不能将四次都描述为事实错误。
- **C04 两次精确字符串不匹配**：before-r3 和 after-r2 的 failure_reason 包含正确的 registry token expired 加额外解释。原精确值验收失败；实际 registry 状态、条件分支及原因事实一致。
- **C03-after-r2 有契约字段差异**：输出 ack_after_commit=false，与所要求的契约结论 true 相反，并另有 JSON 之外文字。最终说明混入现有实现描述；源码没有显式 ack 操作。这是答案/语义解释问题，没有发现调用失败证据。
- **公开条件分支**：C01/C02/C04 共 18 次都先观察条件证据，再在后续模型步骤读取正确分支；C04 没有读取 tests.json 或加载 test-isolation。上述计数包含 C01-before-r2 的 grep 证据。
- **X02 顺序边界**：before-r1 与 after-r1/r2/r3 同一步安排条件证据与源码读取，不能确认先观察并比较条件、再决定读源码。before-r1 和 after-r3 还将源码调用列在前。其余 X02 两次跨模型步骤有序；四次同批样本均非发现/API 失败。

## 负例边界

48 次负例全部没有成功加载、普通文件工具正文暴露或实际模型输入正文曝光。N03/N08 元信息查询与 N05 查找不存在目录属于任务允许的观察。N05 的 5 次未知 phantom 目录返回是正确不存在响应，不是现有目录机制故障。

**N05-after-C-r1** 未先搜索而连续两次 load_skill("phantom/quantum-flux")，两次都被 model-catalog 策略拒绝，随后返回正确 unavailable；没有加载替代能力、没有正文泄露。应保留这 2 次多余尝试及其成本，但单次 after 记录不能证明由提示修改诱导。

## 各题无加载分布（每格三次重复）

| 题目 | 历史 C | Fresh before | Fresh after |
|---|---:|---:|---:|
| C01 | 2/3 | 3/3 | 3/3 |
| C02 | 3/3 | 3/3 | 3/3 |
| C03 | 1/3 | 2/3 | 3/3 |
| C04 | 3/3 | 3/3 | 3/3 |
| R01 | 0/3 | 0/3 | 2/3 |
| R02 | 3/3 | 3/3 | 2/3 |
| R03 | 1/3 | 1/3 | 2/3 |
| R04 | 3/3 | 3/3 | 3/3 |
| X01 | 2/3 | 3/3 | 3/3 |
| X02 | 1/3 | 3/3 | 3/3 |
| X03 | 3/3 | 2/3 | 2/3 |
| X04 | 2/3 | 3/3 | 2/3 |

## 全部无加载样本索引

字段结果按原冻结 scorer 保留；详细字段值、读取路径、每次 wire 可见性与原始 run SHA 均在 new-trace-review.json。

| Trial | 冻结结果 | 条件读取 |
|---|---|---|
| [C01-before-C-r1](trials/C01-before-C-r1/run.json) | 额外文字；对象匹配 | 先证据后续读 |
| [C01-before-C-r2](trials/C01-before-C-r2/run.json) | 通过 | 先条件后分支（grep） |
| [C01-before-C-r3](trials/C01-before-C-r3/run.json) | 通过 | 先证据后续读 |
| [C01-after-C-r1](trials/C01-after-C-r1/run.json) | 通过 | 先证据后续读 |
| [C01-after-C-r2](trials/C01-after-C-r2/run.json) | 通过 | 先证据后续读 |
| [C01-after-C-r3](trials/C01-after-C-r3/run.json) | 通过 | 先证据后续读 |
| [C02-before-C-r1](trials/C02-before-C-r1/run.json) | 未公开布尔类型 | 先证据后续读 |
| [C02-before-C-r2](trials/C02-before-C-r2/run.json) | 额外文字；对象匹配 | 先证据后续读 |
| [C02-before-C-r3](trials/C02-before-C-r3/run.json) | 额外文字及字段不匹配 | 先证据后续读 |
| [C02-after-C-r1](trials/C02-after-C-r1/run.json) | 额外文字及字段不匹配 | 先证据后续读 |
| [C02-after-C-r2](trials/C02-after-C-r2/run.json) | 未公开布尔类型 | 先证据后续读 |
| [C02-after-C-r3](trials/C02-after-C-r3/run.json) | 额外文字；对象匹配 | 先证据后续读 |
| [C03-before-C-r2](trials/C03-before-C-r2/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [C03-before-C-r3](trials/C03-before-C-r3/run.json) | 通过 | 无阶段条件 |
| [C03-after-C-r1](trials/C03-after-C-r1/run.json) | 通过 | 无阶段条件 |
| [C03-after-C-r2](trials/C03-after-C-r2/run.json) | 额外文字及字段不匹配 | 无阶段条件 |
| [C03-after-C-r3](trials/C03-after-C-r3/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [C04-before-C-r1](trials/C04-before-C-r1/run.json) | 通过 | 先证据后续读 |
| [C04-before-C-r2](trials/C04-before-C-r2/run.json) | 通过 | 先证据后续读 |
| [C04-before-C-r3](trials/C04-before-C-r3/run.json) | 精确字符串不匹配 | 先证据后续读 |
| [C04-after-C-r1](trials/C04-after-C-r1/run.json) | 通过 | 先证据后续读 |
| [C04-after-C-r2](trials/C04-after-C-r2/run.json) | 精确字符串不匹配 | 先证据后续读 |
| [C04-after-C-r3](trials/C04-after-C-r3/run.json) | 通过 | 先证据后续读 |
| [R01-after-C-r2](trials/R01-after-C-r2/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [R01-after-C-r3](trials/R01-after-C-r3/run.json) | 通过 | 无阶段条件 |
| [R02-before-C-r1](trials/R02-before-C-r1/run.json) | 通过 | 无阶段条件 |
| [R02-before-C-r2](trials/R02-before-C-r2/run.json) | 通过 | 无阶段条件 |
| [R02-before-C-r3](trials/R02-before-C-r3/run.json) | 通过 | 无阶段条件 |
| [R02-after-C-r1](trials/R02-after-C-r1/run.json) | 通过 | 无阶段条件 |
| [R02-after-C-r2](trials/R02-after-C-r2/run.json) | 通过 | 无阶段条件 |
| [R03-before-C-r3](trials/R03-before-C-r3/run.json) | 通过 | 无阶段条件 |
| [R03-after-C-r2](trials/R03-after-C-r2/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [R03-after-C-r3](trials/R03-after-C-r3/run.json) | 通过 | 无阶段条件 |
| [R04-before-C-r1](trials/R04-before-C-r1/run.json) | 通过 | 无阶段条件 |
| [R04-before-C-r2](trials/R04-before-C-r2/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [R04-before-C-r3](trials/R04-before-C-r3/run.json) | 通过 | 无阶段条件 |
| [R04-after-C-r1](trials/R04-after-C-r1/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [R04-after-C-r2](trials/R04-after-C-r2/run.json) | 通过 | 无阶段条件 |
| [R04-after-C-r3](trials/R04-after-C-r3/run.json) | 通过 | 无阶段条件 |
| [X01-before-C-r1](trials/X01-before-C-r1/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [X01-before-C-r2](trials/X01-before-C-r2/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [X01-before-C-r3](trials/X01-before-C-r3/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [X01-after-C-r1](trials/X01-after-C-r1/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [X01-after-C-r2](trials/X01-after-C-r2/run.json) | 通过 | 无阶段条件 |
| [X01-after-C-r3](trials/X01-after-C-r3/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [X02-before-C-r1](trials/X02-before-C-r1/run.json) | 通过 | 同批，先观察再读未证成 |
| [X02-before-C-r2](trials/X02-before-C-r2/run.json) | 额外文字；对象匹配 | 先证据后续读 |
| [X02-before-C-r3](trials/X02-before-C-r3/run.json) | 通过 | 先证据后续读 |
| [X02-after-C-r1](trials/X02-after-C-r1/run.json) | 通过 | 同批，先观察再读未证成 |
| [X02-after-C-r2](trials/X02-after-C-r2/run.json) | 额外文字；对象匹配 | 同批，先观察再读未证成 |
| [X02-after-C-r3](trials/X02-after-C-r3/run.json) | 通过 | 同批，先观察再读未证成 |
| [X03-before-C-r2](trials/X03-before-C-r2/run.json) | 额外文字；对象匹配 | 无阶段条件 |
| [X03-before-C-r3](trials/X03-before-C-r3/run.json) | 通过 | 无阶段条件 |
| [X03-after-C-r1](trials/X03-after-C-r1/run.json) | 通过 | 无阶段条件 |
| [X03-after-C-r2](trials/X03-after-C-r2/run.json) | 通过 | 无阶段条件 |
| [X04-before-C-r1](trials/X04-before-C-r1/run.json) | 通过 | 无阶段条件 |
| [X04-before-C-r2](trials/X04-before-C-r2/run.json) | 通过 | 无阶段条件 |
| [X04-before-C-r3](trials/X04-before-C-r3/run.json) | 通过 | 无阶段条件 |
| [X04-after-C-r1](trials/X04-after-C-r1/run.json) | 通过 | 无阶段条件 |
| [X04-after-C-r3](trials/X04-after-C-r3/run.json) | 通过 | 无阶段条件 |

与正式 analysis/trial-scores.json 的 120 条 primary/task/load/wrong-load/negative-exposure 字段逐条交叉核对一致。此报告只描述可见轨迹，不推断私有推理；共同 task 工具声明或总结文字未修改，也没有将其归因为这些未采用或格式问题。
