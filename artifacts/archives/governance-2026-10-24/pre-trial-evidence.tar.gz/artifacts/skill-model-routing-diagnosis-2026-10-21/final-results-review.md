# 120 次 fresh paired 复测：独立结果审查

结论：本次五条层级发现指引的澄清没有得到“增加发现或采用”的实验支持。正例发现、任意采用和原冻结严格采用/正文交接均为 before 7/36、after 5/36；差 −5.556 个百分点，按 12 个 case 保留各 3 次重复的配对 bootstrap 95% 描述区间为 [−22.222, +8.333] 个百分点。不能据此宣称改善，也不能将区间跨零解释为两版等价。停止针对同题继续调参，保留该负结果。

## 完整性与独立核验

- 冻结 `paired_analysis.py` 正式运行 exit 0，120/120 终态记录完整，缺失、无效、仍在运行和 provenance errors 均为 0。未排除失败或替换 trial。
- 全部 120 条任务输出由另一个不导入冻结 scorer/analysis 的脚本独立进行严格 JSON 解析与带类型字段比较；发现事件、成功加载和完整正文在后续成功 HTTP 请求中的交接也从 raw run/wire 独立核对。与冻结结果零差异。
- 独立脚本复算 12 正例 case 的发现、采用、strict 配对区间及 20 case 的任务 JSON 区间，均在 1e−12 内一致。三个重复始终留在同一 case 内。
- 14 次成功加载事件（before 9、after 5）均逐字匹配各 trial 本地目录中的完整 Skill 文件，且在成功返回的后续 HTTP 请求内出现。没有错误加载、完整加载但未交接，或普通 `read_file` 读取 Skill 正文。
- 负例完整正文/请求曝光扫描由原冻结 scorer 执行；两臂均 24/24 完整观测，0 次曝光。这里是 8 个独立题目簇，而非 24 个独立任务。零事件、退化区间不证明一般风险为零。
- 所有 394 个 HTTP 请求均为 chat，provider usage 完整；本轮没有 embedding HTTP 调用。旧共享 catalog 索引未重新收费记入本轮，不推算货币成本。
- 两张正式 PNG 已目视检查，计数、轴、误差线与标签可读且无裁切；数值与 `figure-data.json` 一致。

独立可复核文件：`independent_result_review.py`（本目录）、产物目录 `independent-result-review.json`；正式统计为产物目录 `analysis/metrics.json`、`analysis/trial-scores.json`、`analysis/stats-appendix.md`。原始 20 题与标签保持不变。

## 主要结果

| 指标 | before | after | after − before | 描述性 95% 区间 |
|---|---:|---:|---:|---:|
| 正例发现启动 | 7/36 | 5/36 | −5.556 pp | [−22.222, +8.333] pp |
| 正例任意成功采用 | 7/36 | 5/36 | −5.556 pp | [−22.222, +8.333] pp |
| 原 strict 集合与正文交接 | 7/36 | 5/36 | −5.556 pp | [−22.222, +8.333] pp |
| 正例未加载 | 29/36 | 31/36 | +2 次 | 非缺失记录 |
| 负例正文曝光 | 0/24 | 0/24 | 0 | 8 case；不外推零风险 |
| 全题 strict JSON | 45/60 | 46/60 | +1.667 pp | [−5.000, +8.333] pp |

Skill 在这些公开题面中是适用的可选方法，不能把未采用自动标为任务能力失败。当前试验仅支持“该文案澄清没有可观测的采用收益”，不支持“所有不调用都是故障”或“目录工具有运行时缺陷”。

## 12 个正例的分项

每格是 3 次中的次数。发现、任意采用和 strict 在本次每个 case 内恰好一致，不代表三个定义可以互换。

| case | before 发现/采用/strict | after 发现/采用/strict | before strict JSON | after strict JSON |
|---|---:|---:|---:|---:|
| R01 | 3 | 1 | 2 | 1 |
| R02 | 0 | 1 | 3 | 3 |
| R03 | 2 | 1 | 2 | 2 |
| R04 | 0 | 0 | 2 | 2 |
| X01 | 0 | 0 | 0 | 1 |
| X02 | 0 | 0 | 2 | 2 |
| X03 | 1 | 1 | 2 | 3 |
| X04 | 0 | 1 | 3 | 3 |
| C01 | 0 | 0 | 2 | 3 |
| C02 | 0 | 0 | 0 | 0 |
| C03 | 1 | 0 | 1 | 1 |
| C04 | 0 | 0 | 2 | 2 |

before C03 的 3 个加载名为 `api/error-contract`、`queue/idempotency`、`queue/idempotent-consumer-template`；后两者均在原 required alternative group 的允许集合内，不能事后把第二个替代方法加标为错载。

## 任务 JSON：原评分与详细诊断分开

冻结分析分类：before 为 45 pass、12 extra_text_with_matching_object、1 C02_public_type_underspecified、1 parse_failure、1 field_or_completion_failure；after 为 46、10、1、2、1。原 strict 分数不变。

独立读取原输出后，7 条非单纯格式失败的更细说明如下。此为事后诊断，不新增“语义正确率”，不修改任何标签。

| trial | 原冻结分类 | 可观察原因与边界 |
|---|---|---|
| C02-before-C-r1 | C02_public_type_underspecified | 唯一不匹配字段 `provider_followup` 为描述性字符串；题面未公开要求 boolean。其他冻结字段匹配。 |
| C02-before-C-r3 | parse_failure | JSON 外有说明，且内部 `provider_followup` 为描述性字符串；同时存在格式问题与相同类型欠规定。 |
| C04-before-C-r3 | field_or_completion_failure | `failure_reason` 正确包含 registry token expired，并附加注册表 401/前序关卡通过解释；不等于冻结 literal。题面未要求逐字复制，不能当作事实错误。 |
| C02-after-C-r1 | parse_failure | JSON 外有说明，且 `provider_followup` 为详细对象；同时存在格式问题与类型欠规定。 |
| C02-after-C-r2 | C02_public_type_underspecified | `provider_followup` 为描述性字符串；其余字段匹配，公开 boolean 类型仍未规定。 |
| C03-after-C-r2 | parse_failure | JSON 外有说明；抽出的唯一 JSON 中 `ack_after_commit:false`，与题目“契约结论”及 evidence 的 true 不符。文字将实现当前情况混入目标契约；这是可定位的字段语义偏差，不是单纯格式失败。 |
| C04-after-C-r2 | field_or_completion_failure | 原因写 registry token expired 后附加正确说明，仍是 literal 不等而非明显事实错误。 |

before 的 12 条、after 的 10 条 `extra_text_with_matching_object` 均只有一个完整候选 JSON，且候选全部冻结字段匹配。这仅诊断额外说明造成的输出格式违约，不能据此宣布整体推理或事实准确率。

## 资源

| 原始 provider 指标 | before | after |
|---|---:|---:|
| chat HTTP 请求 | 196 | 198 |
| 全部 chat input tokens | 1,241,515 | 1,260,860 |
| 全部 chat output tokens | 40,277 | 46,205 |
| 其中 cache read tokens（不重复相加） | 940,224 | 958,656 |
| 首轮 input 均值（60/60 已知） | 5,540.75 | 5,588.45 |
| 整轮 input 均值（60/60 已知） | 20,691.9167 | 21,014.3333 |
| 整轮 wall seconds 均值 | 30.1668 | 30.9161 |

首轮输入增量 +47.7 tokens，20-case 描述区间 [39.75, 53.0]；整轮输入增量 +322.4167 tokens，区间 [−2,325.6496, +3,290.9437]。整轮输出增量 +98.8 tokens，区间 [−23.0004, +303.47]。这些结果不支持整轮节省或收益等价的成本声明。供应商缓存与时间变化仍属于本次观测条件。

## 结论边界与可交付声明

可以写：澄清了“目录卡只是导航摘要、专门流程先展开描述、普通任务可零 Skill”的层级发现契约；对同一冻结千级合成目录和 20 题完成 120 次 fresh paired 复测，完整保留原始轨迹、失败与费用计量；本次发现/采用没有改善证据，负例未观察到正文曝光。

不能写：修复使检索率、能力或成本提高；保住了等价质量；0/24 证明不会误触发；先前 180 轮的 C60 是本轮 before；既往首轮输入约 79% 的平铺对照收益来自本次文案修改。旧三臂压缩结果与本次 before/after 负结果应分开陈述。

冻结文件复核仍为：analysis `91f488a4f6a8a36c1b4c946c2f2fac425178095901a0bda83db2bb8f53ef1c82`；helpers `7372a446e66693739478b1503319ea3b6e903e2edeed6a4a076185cdcc381c1c`；protocol `5705531e51434affa18391901373435c2d608df340af3cfe3c1e1d4328f075f7`；tests `c9e1a585ee9bef9dfcdef2f9bc6601787a3619d2a8a49d44f5f7f55c49a10d38`。本次正式运行及独立审查均未改变冻结源码、题集、scorer 或统计口径。
