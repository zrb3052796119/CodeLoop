# Figure catalog

- 01-outcomes.png/svg: Discovery, strict adoption/handoff, negative clean and task JSON use separate all-assigned denominators. Intervals resample 12, 8 or 20 cases and preserve all three repeats. Boundary intervals do not establish zero general risk. Compare adoption with the task/safety guardrails; do not equate adoption with ability.
- 02-input-resources.png/svg: Provider wire input means across all assigned trials, with known counts. Missing measurements remain missing. Changes may accompany changes in adoption; this is not a monetary or equivalent-quality savings claim.
