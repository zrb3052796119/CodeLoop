# Statistical appendix

For each case and variant, average all three repeats, then form the after-minus-before case difference. Resample complete paired cases 10,000 times with fixed seed family 20261021. Rates retain all assigned denominators; missing runs count as unsuccessful observations, not exclusions. Continuous metrics use complete three-repeat pairs and list missing pairs in metrics.json. No trial-level independence or confirmatory significance claim is used.

Primary positive outcomes are discovery initiation and original strict adoption/body handoff (12 cases). Negative exposure/cleanliness uses eight cases; all-task JSON and resources use 20. There is one contrast only. Intervals describe these authored cases, not a random user-task population.

Frozen scorer SHA: `b04ce5505b3f60ed7c3bbd3fe9ec441a2197b344b3e68fac46333d081552c611`.
Frozen cases SHA: `069fa872b01a501738a95c93c7a6ca06cbf785a99958b076039ad2402654e308`.
Unchanged helpers SHA: `7372a446e66693739478b1503319ea3b6e903e2edeed6a4a076185cdcc381c1c`.
Analysis SHA: `91f488a4f6a8a36c1b4c946c2f2fac425178095901a0bda83db2bb8f53ef1c82`.

Raw assignment provenance, per-trial scores, provider counter completeness and diagnostic classifications are retained in trial-scores.json. No output post-processing changes the original final response or scorer result.
