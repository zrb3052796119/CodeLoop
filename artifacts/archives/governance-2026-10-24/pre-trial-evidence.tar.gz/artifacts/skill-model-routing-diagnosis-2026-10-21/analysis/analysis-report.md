# Fresh paired hierarchical-discovery experiment

Assigned 120; complete terminal live matrix: True.

The comparison is after minus before on fresh trials. Skill adoption is optional for these public tasks; discovery and frozen strict adoption/body handoff are not general ability or factual correctness.

| Metric | Before | After | After minus before (pp) | Descriptive 95% interval (pp) | Cases |
|---|---:|---:|---:|---:|---:|
| positive_discovery | 7/36 | 5/36 | -5.556 | -22.222, 8.333 | 12 |
| positive_adoption | 7/36 | 5/36 | -5.556 | -22.222, 8.333 | 12 |
| positive_strict | 7/36 | 5/36 | -5.556 | -22.222, 8.333 | 12 |
| positive_wrong_load | 0/36 | 0/36 | 0.000 | 0.000, 0.000 | 12 |
| negative_exposure | 0/24 | 0/24 | 0.000 | 0.000, 0.000 | 8 |
| negative_clean | 24/24 | 24/24 | 0.000 | 0.000, 0.000 | 8 |
| task_pass | 45/60 | 46/60 | 1.667 | -5.000, 8.333 | 20 |
| observation_complete | 60/60 | 60/60 | 0.000 | 0.000, 0.000 | 20 |
| completed | 60/60 | 60/60 | 0.000 | 0.000, 0.000 | 20 |

Negative exposure counts are observed detections, not clean-run success. Missing observations never establish safety; eight case clusters are not 24 independent tasks. A zero or degenerate interval does not prove zero general risk.

| All-assigned resource | Before mean (known/60) | After mean (known/60) | After minus before |
|---|---:|---:|---:|
| first_input | 5,540.750 (60/60) | 5,588.450 (60/60) | 47.700 |
| chat.input_tokens | 20,691.917 (60/60) | 21,014.333 (60/60) | 322.417 |
| chat.output_tokens | 671.283 (60/60) | 770.083 (60/60) | 98.800 |
| chat.cache_read_tokens | 15,670.400 (60/60) | 15,977.600 (60/60) | 307.200 |
| embedding.input_tokens | 0.000 (60/60) | 0.000 (60/60) | 0.000 |
| physical_calls | 3.267 (60/60) | 3.300 (60/60) | 0.033 |
| wall_seconds | 30.167 (60/60) | 30.916 (60/60) | 0.749 |
| task_phase_seconds | 27.928 (60/60) | 28.582 (60/60) | 0.654 |

Wire usage only; partial/missing usage remains unknown, cache inputs are not counted twice, and monetary cost is not inferred. All assignments are retained. Lower resource use may accompany omitted Skill adoption; higher adoption alone is not a quality improvement.

## Task diagnostics and failures

Frozen strict scores remain unchanged. A single extractable JSON object with matching fields is a formatting diagnostic, not general semantic accuracy. C02's provider_followup boolean requirement is insufficiently specified publicly.
- before task diagnostics: `{"C02_public_type_underspecified": 1, "extra_text_with_matching_object": 12, "field_or_completion_failure": 1, "parse_failure": 1, "pass": 45}`.
- before stop reasons: `{"completed": 60}`.
- before negative observations: `{"cases": 8, "exposed_case_ids": [], "fully_observed": 24, "trials": 24, "unfinished": 0}`.
- after task diagnostics: `{"C02_public_type_underspecified": 1, "extra_text_with_matching_object": 10, "field_or_completion_failure": 1, "parse_failure": 2, "pass": 46}`.
- after stop reasons: `{"completed": 60}`.
- after negative observations: `{"cases": 8, "exposed_case_ids": [], "fully_observed": 24, "trials": 24, "unfinished": 0}`.

The previous 180-run pilot is historical context, not this comparison's before arm. The shared frozen embedding cache was reused; no new setup cost is invented or silently charged per turn.
