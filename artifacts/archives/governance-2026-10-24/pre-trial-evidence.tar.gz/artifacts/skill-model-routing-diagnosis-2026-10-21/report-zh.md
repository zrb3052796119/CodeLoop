# 默认 model 未采用 Skill：诊断与冻结集复测

结论：原来的 24 次未加载，均存在合理的直接完成路径；没有证据把它们认定为目录发现或加载故障。分层提示确有“目录摘要如何进入能力适用判断”的表述缺口，已做范围很小的澄清，但 120 次新对照没有显示采用率、任务验收或成本改善。不能把这次改动宣传为路由准确率提升。

## 原 24 次如何分类

| 观测类别 | 次数 | 判断 |
|---|---:|---|
| 不使用 Skill，严格任务 JSON 验收通过 | 14 | 有效直接完成；不能记为任务失败 |
| JSON 外附说明等格式拒绝，但唯一 JSON 对象满足原字段检查 | 8 | 输出格式问题；未证明由 Skill 未采用造成 |
| C02 的 provider_followup 类型未充分公开 | 2 | 评测契约欠规定；冻结分数保留，不能当作事实错误 |
| 目录缺失、工具不可用、已发起发现后失败、预算耗尽 | 0 条有支持证据 | 24 次都是根本未发起 browse/search/load |

这里是可观察结果与任务必要性分类，不是对模型私有决策原因的逐条推断。12 道正例都没有明确要求调用 Skill，题面直接给出证据路径；答案必需信息均能从普通文件取得。正文主要提供工作方法，存在适用 Skill 不等于必须加载。

所有目标目录均在真实请求中；36 个历史 C 正例的全部请求都带有 66 张目录卡及 browse/search/load 三个工具。12 个已发起发现的正例都成功取得所需描述、正确加载并完成正文交接。相同题目的三次首请求在归一工作区后完全一致，仍出现采用与不采用并存。R04 在平铺 B 组也三次没有加载，因此全部归咎于目录层级是不成立的。

8 次 C01/C02/C04 的未加载轨迹都先检查条件证据、再读取后续分支。X02-C-r3 的证据与源码同批读取，不能证明严格的“先比较再读”顺序；这项顺序歧义不等于 Skill 发现故障。

逐题、逐轮的证据路径与 SHA 在 [必要性审查](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/necessity-review.md>)、[目录发现审查](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/discovery-review.md>)、[原因分类](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/cause-classification.md>) 和对应 JSON 中。

## 实际修改

仅修改 minicode/prompt.py 的 _hierarchical_skill_lines：

- 明确目录卡是导航摘要，不是完整技能描述。
- 当前阶段需要专门流程、且目录看起来相关时，先 browse/search 检查实际描述，再决定是否采用。
- 允许先读项目文件澄清事实和条件；这不等于查看了尚未展开的技能描述。
- 普通简单任务、没有适用能力时仍可零 Skill；选择后才加载最小充分集合。

保留该修改是为了让指令含义一致，而不是因为实验已经证明行为改善。没有改模型配置、目录元数据、搜索算法、权限策略或加载器。旁支发现的通用 task 工具声明、最终总结与 JSON 输出的张力没有作为本轮原因，也没有混入这次单一提示改动。

新增 tests/test_skill_directory_discovery_prompt.py 的 8 个真实 route→prompt 契约测试。同样测试字节在旧代码上 4 失败/4 通过，修复后全部通过；连同原提示/路由用例 53 通过，更广相关路由、发现、授权、加载屏障和 agent-loop 回归 244 通过（两组有重叠，不相加为独立用例数）。Ruff 与 git diff --check 通过。契约测试不能证明随机模型会采用技能。重型逐行追踪曾在旧/新隔离环境各超时 60 秒，未取得覆盖结果；没有把它算作成功验证，正常 pytest 红绿证据完整。

## 新的冻结对照：120 次完整 Agent Loop

原 20 道题×3 次重复×修复前/后两版本，各 60 次。每一对顺序随机且平衡为 30 对 before→after、30 对 after→before；四对并发、对内顺序运行。使用相同 glm-5.3-flash、1000 技能/66 目录、七个只读工具、16 步/16 次模型调用等原预算，关闭 hints/prefetch。测试集、评分器、目录和预算均不变；两个 327 文件源码快照仅 prompt.py 不同。历史 C60 只作背景，不混入新对照分母。

| 指标 | 新跑的旧版本 | 修复版本 |
|---|---:|---:|
| 正例发起发现 | 7/36（19.4%） | 5/36（13.9%） |
| 目标技能采用且完整正文交接 | 7/36 | 5/36 |
| 正例没有加载 | 29/36 | 31/36 |
| 错误或额外加载 | 0/36 | 0/36 |
| 负例正文曝光 | 0/24 | 0/24 |
| 严格任务 JSON 验收 | 45/60 | 46/60 |
| 正常完成 | 60/60 | 60/60 |

采用/交接差值 −5.56 个百分点，按 12 道题成组重采样的描述性 95% 区间为 [−22.22, +8.33]；任务验收差值 +1.67 个百分点，20 题区间 [−5.00, +8.33]。都不足以支持改善结论。60 次重复不是 60 道独立题；8 道负例重复得到零曝光不能证明一般场景风险为零。

新观察中，N05-after-r1 对不存在的技能有两次加载尝试，均被策略拒绝且没有正文曝光；不能把零曝光写成零无效调用。C03-after-r2 把当前实现的 ack_after_commit=false 当作要求的契约值，原期望为 true，存在字段语义差异。C02 的类型欠规定在新批次共影响 4 次（每组 2 次，其中每组 1 次还伴随 JSON 外说明），C04 两条拒绝则是正确原因附加解释而未匹配固定字符串。原评分完全保留，细节另列，不事后放宽通过条件。

按每类 12 次正例看，采用/交接：常规 5→3、新能力 1→2、组合 1→0。不存在可以概括为整体改善的分项结果。原批次同源码有 12/36 采用，这次旧版本为 7/36，也说明不能只拿新批次与历史分数比。

## 上下文与整轮资源

| 指标 | 旧版本（60 次） | 修复版本（60 次） |
|---|---:|---:|
| 平均首请求输入 token | 5,540.75 | 5,588.45 |
| 整组输入 token | 1,241,515 | 1,260,860 |
| 平均整轮输入 token | 20,691.92 | 21,014.33 |
| 整组输出 token | 40,277 | 46,205 |
| 缓存命中输入 token（输入的子集） | 940,224 | 958,656 |
| HTTP 请求数 | 196 | 198 |
| 平均完整隔离运行时间 | 30.167 秒 | 30.916 秒 |

平均首请求 +47.7 token，整轮输入 +1.56%，输入+输出总量 +1.97%。整轮输入均值差的描述性 95% 区间为 [−2325.65, +3290.94] token，没有节省证据。缓存 token 没有重复相加。两边没有新的 embedding 请求或预热；复用旧缓存。端点属于 coding 订阅，记录没有金额账单，不能将 token 数换算为已支付金额。

整批实际运行 05:00:02–05:17:00 UTC（约 17 分钟）。所有 120 个分配样本保留，没有自动替换重跑。394 个 HTTP 请求的使用量均有记录。

## 审计与可复查材料

审计通过：689 个本轮冻结文件、131,640 个测试夹具文件、394 个真实请求及 31 条正文交接关系核验无错误或警告。所有 60 对首请求除系统提示外完全一致，差异仅在层级 Skill 指引；suppressed 提示完全一致。原实验 345 个冻结输入、之前 9 个已修改文件均保持原样。私密 runtime 在结束后校验摘要并删除，没有归档凭据。

- [完整统计](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/analysis/analysis-report.md>)、[统计口径](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/analysis/stats-appendix.md>)、[逐轮分数](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/analysis/trial-scores.json>)
- [结果图](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/analysis/01-outcomes.png>)、[输入开销图](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/analysis/02-input-resources.png>)
- [审计](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/audit-report.md>)、[冻结协议](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/paired-protocol.json>)、[回归证据](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/verification.json>)
- [分项结果](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/category-summary.json>)、[新的轨迹审查](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-model-routing-diagnosis-2026-10-21/new-trace-review.md>)

这轮最需要纠正的是评测解释：原“检索成功率”实际上把可选能力的采用与交接作为成功条件，不能代表任务必须使用 Skill，也不能直接称为任务正确率。当前测试适合观察采用行为，不足以证明 Skill 路由带来任务收益；若另做收益测试，应预先登记正文提供独有项目流程/约束的任务，同时保留合理零 Skill 控制，不能改写本轮题面追分。
