# Notes

Baseline is the current workspace after R1/R2 acceptance. New changes are tracked against before/ copies, not mixed Git HEAD diffs. No paid/model evaluation is authorized for this display-only task.

- Top-level budget feedback consumers allow the additive field. Authenticated negative equality in completion_repair_decision remains exact; no ignored-field or validator changes.
- Only the existing budget-exhaustion event and budget_exhausted receipt/decision_event receive reviewLegs. Other interrupted decisions keep their native fields; the pure helper can explain them without altering stored decisions.
- Inspection completion derives from retained independent result. Same-candidate history supports entered evidence when reentry stops before selecting a phase; another candidate cannot inherit it. Existing approved/rejected leg states take precedence over subsequent budget exhaustion.
- View prepends human-readable status while keeping JSON parsing boundaries and _completion_evidence_original intact. Reprojection and restoration do not duplicate the sentence. An untransformed small receipt uses the existing evidence reference store, not a new persistence mechanism.
- First new-test run: 2 passed, 1 fixture assertion error (reviews contains result objects directly, not nested decision). Corrected the test structure; production acceptance semantics were unchanged. Both subsequent 34-case runs pass; final log is final-regression.txt.
