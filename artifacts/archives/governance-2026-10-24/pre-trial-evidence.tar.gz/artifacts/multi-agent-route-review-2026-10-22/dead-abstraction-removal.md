# 根包死抽象清理核对

日期：2026-10-22。依据已授权的 v1.1 第 3.1/3.2 项执行；没有创建 Git 提交。

删除根包 `minicode/agent_protocol.py`（422 行）与 `minicode/context_isolation.py`（206 行）。两者删除前无未提交修改。此项只清理当前根包内部零调用抽象，不改变路由或预算策略；不能解释为整个仓库所有历史副本均无调用。

删除前及删除后检查范围均为 `minicode/`、`tests/`、`scripts/` 与根 `pyproject.toml`：

```sh
rg -n 'agent_protocol|context_isolation|AgentIdentity|TeamRegistry|ContextSandbox|create_subagent_context|release_subagent_context|get_team_registry' minicode tests scripts pyproject.toml --glob '*.py' --glob '*.toml'
```

删除前命中仅位于待删模块自身；删除后为 0 命中（`rg` 返回 1）。

旧 `py-src/` 副本保留且没有修改。以下旧入口仍引用其旧抽象：

- `py-src/minicode/agent_protocol.py:23`
- `py-src/minicode/multi_agent/orchestrator.py:296`
- `py-src/minicode/multi_agent_agent.py:10`

删除后使用当前系统 Python 3.12 执行导入检查，确认实际加载的是当前根包 `minicode/__init__.py`；`minicode.main`、`minicode.agent_loop`、`minicode.tools.task`、`minicode.workflow_runner` 均导入成功。`importlib.util.find_spec` 对两个删除模块均返回 `None`，不存在旧 `__pycache__` 意外掩盖删除的问题。

同时复跑当前正文文件通道与入口回归：

```sh
python3 -m pytest -q --tb=short tests/test_workflow_brief.py tests/test_task_workflow_simplified_entry.py tests/test_workflow_prompt_criteria.py
```

结果：**54 passed in 4.48s**。包括实际 Task → 快照 → 子 Agent Loop 读取完整正文 → 修改文件 → 执行 pytest → 正式 Verifier → RunJournal 审计 → 父工作区回写；仅模型响应和测试沙箱启动器使用本地 fixture，不涉及远程模型调用。另测了快照正文 digest 不匹配拒绝，以及恢复 source cwd 后沿用原父 `PermissionManager` 写入持久正文，快照关闭后文件仍存在。

`git diff --check` 通过。全仓库回归由主任务统一执行，本记录不把这组局部测试冒称全套测试通过。
