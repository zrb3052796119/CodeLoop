# 审阅证据

- HEAD: e092a9af；工作区有现存 memory/agent_loop 等修改，不应称为干净 HEAD。
- docs/multi-agent-effectiveness.md：历史正式 48 次三组完整交付均为 0；explicit 的 Plan/Analyst 占 279/406 次调用；直接 Executor 的工程 v4 仍 0/3。
- 当前既定工程六格是三题 × single/explicit，共 6 次，每组 3 次；门要求至少 4/6、每组至少 2/3、每题至少 1/2，以及完整终态、清理、用量与送达证据。

- 两个指定测试在当前工作区复现：2 failed in 0.71s；未运行全量测试。
- scoped_change 自 policy v4 带 Reviewer；verified_change 才是现有 E→V。
- Verifier 为宿主确定性验证，不是第二个模型角色。
- 未配置 timeout 时解析直接返回 None，常量未接入。
- 宿主完整 diff 已有 digest/byteCount 校验后的 20KB 豁免，受 4MiB 总预算约束。
- 父 handoff floor 是上下文估算＋回执估算＋2048，不是按比例。
- Assignment 不含 context_risks；可复用 AnalystHandoff/inputRefs。
- 进度 checkpoint 已有建议 coordinator 直接委派 workflow 的措辞。
- SmartRouter 有生产调用；Cybernetic 控制输出会改变实际执行，不能视为死代码清理。
- 根 minicode/agent_protocol.py 与 context_isolation.py 无生产引用；旧 py-src 副本有使用，删除范围须限定。
- 历史 role-diagnostics.md 在当前磁盘缺失；历史数字只按 effectiveness 文档引用。
