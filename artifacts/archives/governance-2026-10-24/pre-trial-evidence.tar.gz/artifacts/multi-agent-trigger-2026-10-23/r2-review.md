# R2 经济边界设计核查（只读，非冻结材料）

核查对象：`docs/2026-10-23--native-review-economics-repair.md`。下述代码引用为当前工作区源码；本次没有实现生产改动、修改冻结包或发起评测。

结论：可以复用现有共享准入视图与绝对 deadline 实现有界原生审查，但**不能只把三处 max_steps=None 改成 8/8/4**。另一个必须先解决的问题是 bounded 耗尽后的交付语义：目前只增加 `completionReview=incomplete` 元数据不会使原生 final 获接受；把审查状态改成 approved 则会伪造 `requirementsAccepted`。这部分是产品授权语义变化，不是纯性能修复。

## 1. max_steps、预算准入和物理请求是三个口径

- `minicode/agent_loop.py:3888` 检查当前循环 step 上限，`:3942` 增加 step；`:4379` 另做共享预算准入。max_steps 限制本次 `run_agent_turn` 的循环，不能覆盖它的工具内部再次调用模型。
- 真实例子：`minicode/implementation_completion_review.py:1515` 的 `ProbeFailureAdjudicator.assess` 在 review_test 的失败归因处理中再次使用 `host._agent_budget`。八格中的 limit-clamp 请求 10–17 就属于此类。给外层 reviewer max_steps=8，不等于它连同裁决只花 8 个请求。
- `AttributedBudgetView`（`minicode/agent_budget.py:812`）只做归因与转发，不自带本地 request cap。已有 `_WorkerCallBudget`（`minicode/workflow_runner.py:607`）才有本地 admitted counter、cap、父收尾 floor；`:652` 的 reserve 最终只向共享账本准入一次。可直接复用这个实现，或最小地把这个已有 helper 移到共享预算模块供双方引用，不需要新控制器。
- `_WorkerCallBudget` 约束的是 budget admission。生产 OpenAI adapter 在 `minicode/openai_adapter.py:978–1034` 内有 `max_retries+1` 次 HTTP 尝试（默认最多 5 次），内部没有再次调用 `reserve_model_call`；因此不禁 adapter retry 时，一个 admission 仍可能有多个 HTTP。
- 已有 hook 是 `max_retries_override=0`（OpenAI `:785`；Anthropic `:857`），经 `minicode/model_call_control.py:160` 的 `call_model_next` 传给支持该参数的 adapter。当前普通原生调用禁用了 implementation phases，其 `request_options` 通常只有 tools_override（`agent_loop.py:4272–4289`），不能假定已经禁用内部重试。bounded 链和其嵌套裁决应沿已有 request_options 通道显式设置 0；宿主的 transient retry（`:4623`）会重新进入准入，正常占用本地 cap。
- **通用 adapter 还有边界**：`minicode/anthropic_adapter.py:1043–1067` 在非流式 400 cache_control 错误后有一次独立 marker-free 重发，绕过 max_retries=0。已有 `promptCache=False` 可以禁用该路径（`:830`），但这会改变缓存策略，且只改 host 的 runtime 副本不保证共享 model.runtime 跟着改变。ModelAdapter 协议也没有要求所有第三方实现接受 retry override（`minicode/types.py:62`；不支持的参数会被 `_accepted_model_kwargs` 过滤）。故“OpenAI 路由 + override0 + 共享准入”可以对齐当前 provider-attempt 计数；不能无条件承诺所有 adapter、HTTP redirect/底层连接尝试都等于 budget 次数。没有发现现成的通用每次 HTTP attempt 准入 hook。

## 2. 最小的、不重复扣账的预算接线

建议把“只算一次”定义为**同一父 turn 首次进入原生完成门时冻结一次**，之后重复 final、修补候选、格式重试或保留上下文继续使用同一个链预算，不重新获得 50% 窗口或 8/8/4 配额。同一链内的阶段恢复也不能重建 admitted=0 的新 view。若产品想按每个新候选重新给配额，应明确写成另一种策略，不能称为同一链总上限。

可用结构为：原父 budget → 一个链 view → 三个阶段 view。

- 链 view 只在这里附加 `preserve_calls=2` 和一个父收尾 token floor。已有祖先 floor 若保护另一个父节点则继续保留；这是不同收尾，不是重复。
- 三个阶段 view 的 `preserve_calls=0`、`preserve_tokens=0`，本地 max_calls 分别 8/8/4；阶段内部的模型嵌套必须传同一阶段 view。它们对链总额的消费自然累积，不能重回原始 root budget。
- 不调用 `reserve_subprocess_lease` 来“预扣”这两个 calls：这里是同进程共享锁，无需 RPC lease。不创建第二份 AgentTurnBudget、不在结束时手工再汇总 usage、不额外发一张 grant。
- 共享根在 `agent_budget.py:493–526` 原子检查 `used + reserved + 1 + preserve`，实际仅增加一个 used_model_calls；本地/链 counter 都记录这次 admission，但不是额外账单。底层拒绝时本地 counter 不增加。
- `_WorkerCallBudget.snapshot`（`:629–647`）会隐藏受保护的余额；不要先把根 max_model_calls 减 2，再在 view preserve_calls 又减 2。若同时给链 max_calls，它应只是入口可用次数扣 2 的等价上限，不再次扣除。
- 现有全局预算的已用 calls、`reserved_model_calls`（包括尚未结算 subprocess lease）仍须参与入口可用量；不能仅按 max-used 算剩余。

两个 calls 是一个**政策预留量**，并非当前 final 必需的物理下界：现有父模型已经生成完成候选，审查通过后可直接接受原输出；宿主 partial 回执也不需要再请求模型（`agent_loop.py:6597–6621`）。预留 2 可以作为起点，但不应称为代码已证明的“所需下界”。

## 3. token floor 不能遗漏，也不能把同一收尾相加两遍

- 只留 calls 和秒数，仍允许审查吃完有限 token，父收尾无法发出。根账本支持 `preserve_total_tokens`（`agent_budget.py:469–515`），应与 calls floor 一起挂在唯一链 view。
- `_parent_handoff_token_floor`（`agent_loop.py:796–854`）目前专门给 workflow task 工具交接估价，没有 workflow call 时返回 0；不能直接拿它给原生完成链使用并认为已经保护父 final。
- 它的两段原则可复用：原父已存在的上下文/工具 schema + 将交付的审查反馈 + 收尾 output allowance。若政策预留两个真实模型请求，token 报价必须与这两个请求的实际上下文和输出上限相配，不能用现有“一次父 hand-back + 2048”当作两次保证。
- `agent_loop.py:4303–4316` 的 native floor 保护的是当前嵌套 reviewer 自己的结论，若该能力被接入，它与父最终回复是不同消费，应与父 floor 叠加；但同一个父 final 同时由 phase/completion 保护时，已有代码用 `max`（`:4362–4383`），不可再次相加。
- 当前 `host_native_result_tool` 只允许绑定 `review_submit`（`:2180–2185`），三个 completion 工具没有接入这个原生 closing 能力，不能假定它们自动享有该 floor 或最后一次强制 submit。
- 这些 floor 是估计输入的准入保护，不是 provider 实际 token、未来工具正文增长、未知失败 usage 或美元上限的绝对保证。原账本 docstring（`agent_budget.py:475–480`）已说明这一点。R2 可以承诺“不准许审查侵占已定义的准入余量”，不能承诺“必定得到两个成功 final 响应”。

## 4. 一次绝对时间预算足以表达 90/150/60 与链 50%

设第一次进入完成门时刻为 t0，原祖先截止为 D，T=max(0,D-t0)，按文档原式：

```
R = max(60, 0.15*T)
chain_seconds = max(0, min(0.50*T, T-R))
chain_deadline = min(D, t0+chain_seconds)
phase_deadline = min(chain_deadline, phase_first_start+phase_cap)
phase_cap = 90 / 150 / 60
```

同一阶段恢复保留 phase_first_start，不从恢复时刻重新加 90 秒。三阶段的 300 秒是各自上限总和，**不是**三个保底窗口；例如 T=508 时链只有 254 秒，T=136 时链只有 68 秒。父余量不足 60 秒时审查时间为 0，不能为了“保留 60 秒”延长祖先 deadline。

已有代码支持传绝对 deadline：`task_deadline.raise_task_deadline`（`:64`）、`model_call_control.bounded_request_timeout`（`:36`）以及 `tools/task.py:2262–2275` 的 min(own,ancestor) 是同一约束模式。原生链可以用 replace 后的 ToolContext/现有函数参数传递；不需要另开计时控制器。

必须同时传入真正供 probe、快照/验证和嵌套裁决使用的 context，不能只改 `run_agent_turn(deadline_monotonic=...)`：`implementation_completion_review.py:1034` 的 checkpoint 和 `:1517` 的裁决都读闭包里的 host。各阶段是共享 chain 祖先的兄弟阶段，下阶段应从 chain context 推导；不能把第一个阶段的 90 秒 deadline 当成永久 host，导致下一阶段继承已过期的 deadline，也不能把阶段 90 秒限制留在模型参数而让工具继续消费链全部时间。

阶段/链耗尽在完成门边界处理；真正祖先 deadline、用户 cancellation、已确认 product_gap、权限拒绝和普通实现异常不能一并当作“审查经济上限”降级。现有 `budget_exhausted_policy="raise"` 可以保留给内层，在所属链边界区分本地耗尽；只改为 summary 不能制造原生批准。

没有有限父 deadline 时，“剩余时间的 50%”没有定义。可落地的默认解释是保留阶段 90/150/60、链最多 300 秒，比例条件仅对有限祖先生效；这属于应在方案中显式写明的边界，而不是创建无限大的新父期限。

## 5. bounded 耗尽的接受语义必须先由用户决定

当前 `agent_loop.py:3794` 仅凭审查 decision.status==approved 设置 `direct_completion_accepted`。`:6597–6621` 在它为 false 时强制追加 partial 回执，将 turn 标为 failed，并写 `requirementsAccepted=false`。因此：

- 只添 `completionReview=incomplete`：仍然 partial，达不到文档所说 accepted final。
- 把 budget exhaustion 改写为 approved：会把没有完成的独立覆盖变成 requirementsAccepted=true，既不真实，也违反“不放宽验收”表述。
- 保留 requirementsAccepted=false 但允许候选送出：这是**新增一种较弱的交付接受政策**，必须明确它与“需求覆盖已接受”的区别，调整原 finally 分支以及用户可见文字；不是只追加字段。不能用名字不同的事件或元数据掩盖语义变更。

主代理已向用户确认这个选择；在答复前不能决定实现为哪一支。建议选择“有界结束并交付如实 partial”作为不改变现有验收语义的版本；若用户选择较弱 accepted，验收门应相应写成“允许发送但 coverage 未接受”，且 requirementsAccepted 保持 false。已确认缺陷或失败检查绝不能由耗尽兜底覆盖。

## 6. full 应保持什么

按文档“full=现状行为”的明确含义：三个原生调用 `max_steps=None`，不挂新的 8/8/4 cap，不设置新的 90/150/60 或 50% chain deadline，不额外扣本轮新增 2 calls / token floor；仍继承原共享 budget、祖先 deadline、取消、现有 adapter/宿主重试策略以及 `budget_exhausted_policy="raise"`。不自动放行、不把 partial 改成 accepted，保留真实 requirementsAccepted 语义。

如果希望 full 也有新经济上限但“耗尽不放行”，那是不同于“现状”的策略，应重新明确，不能暗中同时修改。R1 的说明/报错改进可两种模式共同使用，因为不改变 runtime 验收。

## 7. 方案中的两处依据需要订正

- stock 在约 92 秒时是父候选及公开/新增回归检查通过；独立 acceptance probe 到原生请求 9 才通过，不是 92 秒已具备。旧 reviewer 实耗约 184 秒，给新 reviewer 90 秒上限不能靠旧轨迹相加证明它会 approved。离线算式只能验证预算配置，不证明模型在减少的时间内做完决定。
- R2 能减轻 config 在父工作完成之后的审查滞留，并不能降低其此前约 464 秒的长输出与网络耗时。“不解决父侧延迟”准确；“对 config 形态完全无帮助”比证据支持的结论更强。

最低验证应使用离线真实准入/adapter seam：阶段内重试和嵌套裁决都占 cap、失败仍占 call、拒绝不扣账、父 floor 只扣一次、实际 HTTP retry override 生效、短祖先期限不被延长、阶段恢复不刷新额度、known product_gap 不被 bounded 耗尽覆盖，以及最终 receipt 的 policy 选择保持一致。本次只提出这些验证点，没有执行生产修改或新评测。
