# Initial LimitedBudgetView extraction validation

- Before snapshots: `agent_budget.py`, `workflow_runner.py`, SHA-256 in `snapshot.json`.
- Extracted class body is byte-identical after renaming `_WorkerCallBudget` to `LimitedBudgetView`.
- Production files were compared against these snapshots: only the class move, required import/export, and compatibility alias changed.
- Added `tests/test_limited_budget_view.py`: 12 cases including parameterizations.
- No provider calls, commits, or remote operations.

Command:

```text
python -m pytest -q tests/test_limited_budget_view.py tests/test_workflow_executor_budget.py tests/test_unlimited_agent_budget.py tests/test_workflow_completion_budget_estimated.py tests/test_workflow_scoped_budget_delivery.py tests/test_reviewer_budget_handoff.py
```

Result: `100 passed in 11.95s`.

`git diff --check -- minicode/agent_budget.py minicode/workflow_runner.py tests/test_limited_budget_view.py` passed.

Coverage includes one shared preserve-2 chain with 8/8/4 stage caps, usage and cost charged once, failures consuming admission once, unchanged local counters on upstream rejection, nested read-only views, token floor excluded from planning snapshots without ledger reservation/charge, relative token allowances, and unlimited root budgets with finite stage caps.

## Subsequent authorized correction

The final class is no longer byte-identical to the extracted class: after reproduction of sibling-stage interference, `snapshot()` now projects its local call ceiling as `shared.used_model_calls + max(0, self._max_calls - self._admitted_calls)`, still taking the minimum with the ancestor ceiling/floor. Admission, token allowance policy, errors, and accounting remain unchanged. The three new interleaving tests failed on the extracted implementation before this one-line correction. Final validation is recorded separately in `completion-review-validation.md`.
