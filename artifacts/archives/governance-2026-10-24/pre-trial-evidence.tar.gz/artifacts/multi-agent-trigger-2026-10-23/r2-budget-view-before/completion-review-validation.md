# Completion review limits and snapshot validation

Scope: `minicode/completion_review_limits.py`, `tests/test_completion_review_limits.py`, and the separately authorized one-line `LimitedBudgetView.snapshot()` correction with regressions in `tests/test_limited_budget_view.py`. No loop, review runner, adapter, provider call, commit, or remote operation was performed by this subtask.

The new review-limit module initially produced **5 failed, 21 passed** with the same behavioral tests: expired ancestor deadline extended to now; cancellation masked by local timeout; ordinary errors masked at two elapsed-time boundaries; full mode adding a new cancellation/deadline checkpoint. The module now preserves the ancestor deadline, classifies only budget/task-deadline exceptions, and leaves no-limits helpers inert.

Additional coverage checks ancestor shared budget exhaustion (calls/tokens/cost, including live subprocess cost reservation) before local call/time exhaustion, old duck contexts, first-entry phase deadlines, sibling 90/150/60 windows, unbounded-parent 300s chain, short remaining time, 8/8/4 admission limits, one shared preserve-2/token floor, failed-attempt accounting, and phase reentry.

The extracted budget view also reproduced a distinct prior bug: after review3 then inspection2, review snapshot showed 3 calls remaining although actual admission allowed 5; after inspection8 it showed none, still allowing 5. **All 3 new interleaving regression cases failed before repair.** The authorized fix changes only its call snapshot ceiling to current shared usage plus remaining local admissions, still bounded by the upstream ceiling/floor. Local token policy, admission locking, and accounting are unchanged. The final extracted class is therefore no longer byte-identical to the initial source, intentionally.

Final command:

```text
python -m pytest -q tests/test_completion_review_limits.py tests/test_limited_budget_view.py tests/test_workflow_executor_budget.py tests/test_workflow_completion_budget_estimated.py tests/test_workflow_scoped_budget_delivery.py tests/test_reviewer_budget_handoff.py tests/test_workflow_analysis_budget.py tests/test_workflow_typed_handoff_budget.py
```

Result: **109 passed in 55.63s**.

`git diff --check -- minicode/agent_budget.py minicode/completion_review_limits.py tests/test_limited_budget_view.py tests/test_completion_review_limits.py` passed.

Integration note: `review_exhaustion` intentionally does not import `agent_loop`. The caller must normalize its known `AgentTurnDeadlineExceeded` to `TaskDeadlineExceeded` for classification, then re-raise the original exception if not local. Creation-once ownership remains in the parent loop.
