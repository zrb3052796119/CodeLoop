# Trigger synthetic task package

Goal: eight independently judgeable synthetic maintenance tasks, public baseline compatibility green and hidden behavior red-to-green offline; no model calls.

- [x] Confirm common-judge case/proof interfaces and eight fixed IDs with root, runner, auditor.
- [x] Build six naturally separable maintenance cases plus two known-location single-function cases.
- [x] Prove every public baseline/reference pass and explicit JSON oracle failure/pass.
- [x] Validate material isolation, counterexample evidence and deterministic task construction.
- [x] Deliver package, contracts and proof summary for preregistration review.

The first six have investigation or isolated implementation opportunities, not mandatory delegation. The last two explicitly identify a local function. Public prompts contain neither delegation instructions nor positive/negative labels. All tasks require a new tests/test_eval_regression.py. No gen-2 source, oracle or frozen output changes.

Status: pack-v3 ready for independent freeze review. No model calls and no Git commit.

Review corrections: pack-v1 checks retained mutable values, so v2 captures deepcopy snapshots and rejects inconsistent passed/actual/expected receipts. Root requested clearer None behavior in newly introduced dictionaries and direct cursor/pricing interface checks; v3 incorporates those refinements. All three offline drafts are preserved; only pack-v3 is the final candidate.
