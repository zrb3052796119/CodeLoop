# Synthetic trigger package ready for review

Final input: `pack-v3/tasks.json`. Hidden reference fixes: `pack-v3/reference-fixes.json`. Offline receipts: `pack-v3/offline-proof.json`. Binding hashes: `pack-v3/source-manifest.json`. Earlier pack-v1/v2 are preserved offline drafts and must not be included as additional evaluation inputs.

| Case | Natural boundaries | Expectation | Checks | Baseline errors | Reference errors |
| --- | --- | --- | ---: | ---: | ---: |
| trigger-record-pagination | total ordering, cursor position, continuation | positive | 19 | 9 | 0 |
| trigger-import-retry | persistent event identity, batch counts, retry payload | positive | 9 | 8 | 0 |
| trigger-cart-discounts | eligibility, line rounding/shared cap, receipt totals | positive | 12 | 6 | 0 |
| trigger-stock-allocation | bin aggregation, sequential allocation, SKU summary | positive | 7 | 5 | 0 |
| trigger-report-timezones | local date to UTC interval, event selection | positive | 10 | 5 | 0 |
| trigger-config-overlay | recursive merge, environment decoding/precedence | positive | 8 | 6 | 0 |
| trigger-limit-clamp | explicitly named clamp function | negative | 8 | 3 | 0 |
| trigger-extension-case | explicitly named suffix function | negative | 10 | 3 | 0 |

All eight baseline and reference public checks exited 0. Each identical hidden oracle exited 1 with named target failures on its baseline and 0 with no failures on its reference. Total: 83 behavior checks, 45 baseline target failures, zero reference failures. Public prompts disclose all tested rules and do not mention subagents or expectation labels. Positive means a reasonable independent investigation/implementation opportunity, not a mandate to delegate or a superiority claim. All cases permit direct completion and require a newly authored tests/test_eval_regression.py.

The generator's 10 tests passed in 2.17 seconds, including an actual import-error false-red probe, mutable-receipt snapshot probe, full eight-case subprocess proof, and public/reference scope separation. Python source compilation and diff whitespace checks passed. No production files, gen-2 frozen materials, real model calls or Git commits were changed by this task.
