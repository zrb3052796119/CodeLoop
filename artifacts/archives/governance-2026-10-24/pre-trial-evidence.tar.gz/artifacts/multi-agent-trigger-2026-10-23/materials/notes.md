# Package interfaces

Synthetic generation trigger-v1; no Git-history provenance claim. Public shared files: empty minicode/__init__.py and pytest.ini. Cases use the existing common-judge id/category/prompt/files/authorized_paths/verification_argv/sourcePaths/oracle_source fields. triggerExpectation is host-only positive/negative metadata. Reference fixes and oracle proof remain host materials.

Private oracle subprocess imports only the task workspace and asserts module origin. Import/setup errors do not emit a valid behavior receipt. Proof requires baseline exit 1 with passed=false and named failed checks, reference exit 0 with passed=true and no failed checks; both public checks exit 0.

Final candidate is pack-v3 only. Source/reference/oracle/prompt maps are deterministic; offline proof includes temporary subprocess paths and elapsed pytest summaries, so its hash freezes the actual observed execution rather than claiming reproducible proof bytes.

Checks capture deepcopy values at comparison time. The proof validator checks passed against actual==expected and requires matching ordered base/reference check identities. New dictionary values apply recursive None-as-unset semantics, stated publicly and tested; returned override-origin nested lists are checked for aliasing. Cursor and pricing interfaces are checked directly as well as through service outputs.
