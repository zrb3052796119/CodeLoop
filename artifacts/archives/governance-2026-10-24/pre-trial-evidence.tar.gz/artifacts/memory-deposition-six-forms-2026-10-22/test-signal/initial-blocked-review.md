# 沉淀层测试信号复核

结果：**BLOCKED**（隔离环境不可创建），不是测试失败，也没有证明变异被杀死。

- 最终未修改基线：三个相关测试模块 **122 passed**；命令和输出见 `baseline.json`。
- 独立审查：strict 用真实管线与技术 trace 检查 USER 偏好零产出；声明式依赖通过真实 read_file、trace recorder、ReflectionEngine、MemoryPipeline 检查 pending；pending 时限测试固定时钟检查恰好 7 天和 6/8 天配置，完整模块另检查实际注入与条目不变。未发现阻塞级测试设计问题。
- 三个拟定故障：绕过 strict 总开关、错误自动批准声明依赖、绕过 pending 年龄阈值。补丁只保存到本目录，未应用到共享源码。
- 第一项调用技能原生 run_fault_probe.py 后，在创建临时 worktree 时被文件系统沙箱阻止：`.git/worktrees/repo: Operation not permitted`。另外两项按相同隔离前提跳过。
- Git HEAD 不含已有但未提交的实验模块，因此不能用 HEAD 的导入失败冒充修复前的行为证据。
- 运行前后四个相关生产文件 SHA-256 相同。未请求额外权限，未留下生产故障修改。

`test-signal.json` 是规范结果，`probe-plan.json` 和三个 `.diff` 可供之后在允许创建 worktree 的环境重跑。当前结论仅为基线绿、守卫用例设计合理；尚未获得有效故障探针证据。
