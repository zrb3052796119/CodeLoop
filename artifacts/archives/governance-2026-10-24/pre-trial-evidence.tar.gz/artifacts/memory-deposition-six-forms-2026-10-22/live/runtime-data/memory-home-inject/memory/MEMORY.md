# User Memory

*Last updated: 2026-10-22 19:22*

## User_Preference

- 我叫王跑跑，以后这个项目里的回答都用中文，注释也用中文写 `user-preference user-statement`
