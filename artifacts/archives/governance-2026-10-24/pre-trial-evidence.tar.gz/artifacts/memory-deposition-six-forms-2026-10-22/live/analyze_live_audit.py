"""Read the five live captures and verify aged rendering only on a copy.

No model or tool execution. Source authority hashes prove the live evidence is
unchanged. The copied pending records are compared in full before/after prompt
rendering with a clock advanced by eight days; no timestamp is edited.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
sys.path.insert(0, str(REPO))
from minicode.memory import MemoryManager
from scripts.memory_deposition_yield_audit import (
    FORMS, _audit_environment, _entries, _entry_form, _render_at,
)

RESULTS = ROOT / 'results'
WORKSPACE = ROOT / 'workspaces/yieldtest'
DATA = ROOT / 'runtime-data/memory-home-inject'


def _write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def _authority_hashes():
    paths = []
    for base in (WORKSPACE / '.mini-code-memory', DATA / 'memory'):
        if base.exists():
            paths.extend(path for path in base.rglob('*') if path.is_file())
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}


def _evidence():
    sessions = []
    for number in range(1, 6):
        data = json.loads((RESULTS / f'session-{number}.json').read_text())
        path = RESULTS / f'session-{number}-traces.json'
        traces = json.loads(path.read_text()) if path.exists() else []
        run = data.get('run', {})
        events_path = ROOT / 'runtime-data/journal-home/dashboard/workspaces' / run['workspaceId'] / 'runs' / run['id'] / 'events.ndjson'
        events = [json.loads(line) for line in events_path.read_text().splitlines() if line.strip()]
        model_calls = sum(event.get('type') == 'model.completed' for event in events)
        errors = []
        reads = []
        for capture in traces:
            for event in capture['execution_trace']:
                if event.get('type') == 'error':
                    errors.append({'error_type': event.get('error_type'), 'message': event.get('message')})
                if event.get('type') == 'tool_call' and event.get('tool_name') == 'read_file':
                    reads.append(event.get('input', {}).get('path'))
        sessions.append({
            'session': number, 'prompt': data['originalPrompt'],
            'run_id': data.get('run', {}).get('id'), 'run_status': data.get('run', {}).get('status'),
            'model_calls': model_calls, 'bounded_capture_model_calls': data.get('modelCalls'),
            'journal_event_count': len(events), 'elapsed_seconds': data.get('elapsedSeconds'),
            'trace_count': len(traces), 'funnel_logs': data.get('funnelLogs', []),
            'task_outcome': data.get('taskOutcome', []), 'errors': errors, 'files_read': reads,
            'response': data.get('response'), 'fixture_isolation': data.get('fixtureIsolation'),
        })
    return sessions


def analyze():
    sessions = _evidence()
    source_before = _authority_hashes()
    with tempfile.TemporaryDirectory(prefix='minicode-live-yield-analysis-') as temporary:
        copy_root = Path(temporary)
        workspace = copy_root / 'workspace'
        data_root = copy_root / 'memory-data'
        shutil.copytree(WORKSPACE, workspace)
        shutil.copytree(DATA, data_root)
        with _audit_environment('inject'):
            manager = MemoryManager(project_root=workspace, data_root=data_root)
            entries = _entries(manager)
            pending_before = {
                entry.id: deepcopy(entry.to_dict()) for entry in entries
                if entry.approval_status == 'pending'
            }
            now = max([time.time(), *(entry.updated_at for entry in entries)]) + 1
            fresh = _render_at(manager, workspace, now)
            aged = _render_at(manager, workspace, now + 8 * 86400)
            mode_controls = {}
            for control_mode in ('strict', 'capture'):
                with _audit_environment(control_mode):
                    mode_controls[control_mode] = _render_at(manager, workspace, now + 8 * 86400)
            pending_after = {
                entry.id: entry.to_dict() for entry in _entries(manager)
                if entry.id in pending_before
            }
            full_entries = [deepcopy(entry.to_dict()) for entry in _entries(manager)]
            forms = {}
            for form in FORMS:
                matching = [entry for entry in entries if _entry_form(entry) == form]
                ids = {entry.id for entry in matching}
                durable = [entry.id for entry in matching if entry.approval_status == 'approved' and not entry.metadata.get('deposition_draft')]
                stored_drafts = [entry.id for entry in matching if entry.metadata.get('deposition_draft')]
                fresh_drafts = sorted(ids.intersection(fresh['draft_ids']))
                aged_drafts = sorted(ids.intersection(aged['draft_ids']))
                forms[form] = {
                    'stored': bool(matching), 'entry_ids': sorted(ids), 'durable_ids': durable,
                    'stored_draft_ids': stored_drafts, 'fresh_prompt_draft_ids': fresh_drafts,
                    'eight_day_prompt_draft_ids': aged_drafts,
                    'fresh_canonical_ids': sorted(ids.intersection(fresh['canonical_ids'])),
                    'eight_day_canonical_ids': sorted(ids.intersection(aged['canonical_ids'])),
                    'captured_immediately': bool(durable or stored_drafts),
                    'captured_after_eight_days': bool(durable or stored_drafts or aged_drafts),
                    'entry_approval': {entry.id: entry.approval_status for entry in matching},
                }
    source_after = _authority_hashes()
    declared_ids = set(forms['declared_dependency']['entry_ids'])
    declaration_checks = [entry for entry in full_entries if entry['id'] in declared_ids]
    declared_pending = bool(declaration_checks) and all(entry['approval_status'] == 'pending' for entry in declaration_checks)
    discipline_checks = {
        'declared_dependencies_remain_pending': declared_pending,
        'declared_dependencies_never_canonical': not forms['declared_dependency']['fresh_canonical_ids'],
        'strict_and_capture_have_no_draft_render': all(not item['draft_ids'] for item in mode_controls.values()),
        'user_scope_preference_captured': bool(forms['user_preference']['entry_ids']),
    }
    report = {
        'kind': 'actual_live_model_five_sessions_plus_copy_only_clock_advance',
        'session_count': len(sessions), 'model_calls': sum(s['model_calls'] or 0 for s in sessions),
        'captured_immediately': sum(form['captured_immediately'] for form in forms.values()),
        'captured_after_eight_days': sum(form['captured_after_eight_days'] for form in forms.values()),
        'total_target_forms': len(FORMS), 'forms': forms, 'sessions': sessions,
        'discipline_checks': discipline_checks,
        'full_acceptance_passed': all(discipline_checks.values()) and pending_before == pending_after and source_before == source_after,
        'pending_entries_checked': len(pending_before),
        'pending_records_unchanged': pending_before == pending_after,
        'source_authority_unchanged': source_before == source_after,
        'source_authority_hashes': source_before,
        'pending_before': pending_before, 'pending_after': pending_after,
        'entries': full_entries, 'fresh_render': fresh, 'eight_day_render': aged,
        'mode_controls': mode_controls,
        'limitations': [
            'Five live sessions do not guarantee all six failure shapes occur; no missing outcome is fabricated.',
            'Aged rendering is a local clock advance on a temporary copy, not a second live conversation eight days later.',
            'Redis is disabled to verify disk fallback; no Redis service or global configuration is changed.',
            'Session 4 also wrote AGENTS.md, so Session 5 replying in Chinese is not causal evidence for memory alone.',
        ],
    }
    _write(RESULTS / 'analysis.json', report)
    labels = {
        'policy':'规范约束', 'single_tool_failure':'单次工具失败',
        'permission_denied':'权限拒绝', 'syntax_repair':'语法错误修复',
        'user_preference':'用户偏好', 'declared_dependency':'声明依赖',
    }
    lines = [
        '# 五会话真实模型审计', '',
        f"完成 {len(sessions)} 个真实会话，记录 {report['model_calls']} 次模型调用。",
        ('**尚未完全通过验收：声明依赖在第三次读取后被 recurrence_promoted 自动批准，违反必须保留人工审批的要求。**' if not declared_pending else '**审批纪律检查通过。**'),
        f"六类目标经验：即时 durable + draft 捕获 {report['captured_immediately']}/6；"
        f"在副本上将读取时钟推进 8 天后为 {report['captured_after_eight_days']}/6。", '',
        '| 经验形态 | 实际存储状态 | 即时 常规检索 / Recent draft notes | 8 天后 常规检索 / Recent draft notes |',
        '|---|---|---|---|',
    ]
    for name, form in forms.items():
        approval = ', '.join(sorted(set(form['entry_approval'].values()))) or '未捕获'
        if form['stored_draft_ids']:
            approval += ' / deposition draft'
        if form['durable_ids']:
            approval += ' / durable'
        lines.append(f"| {labels[name]} | {approval} | {len(form['fresh_canonical_ids'])} / {len(form['fresh_prompt_draft_ids'])} | {len(form['eight_day_canonical_ids'])} / {len(form['eight_day_prompt_draft_ids'])} |")
    lines.extend(['',
        'approved 的 TTL 草稿可走常规检索通道；Recent draft notes 为单独草稿块，因此该列为 0 不代表未被检索。表格是六个相关查询的 ID 并集，不代表每个提示词同时命中所有条目。6/6 指 durable + draft 捕获及读侧资格。',
        'USER 偏好与项目条目分开统计；声明依赖的 epistemic_status、limitations、审批状态保留在 analysis.json。',
        f"对 {len(pending_before)} 条 pending 完整条目进行前后比较：{report['pending_records_unchanged']}；"
        f"真实审计源记忆文件哈希保持不变：{report['source_authority_unchanged']}。", '',
        '8 天后结果只来自临时副本上的读取时钟推进，没有修改条目时间戳、审批或生命周期，也没有追加模型调用。',
        '同一副本切换到 strict / capture 的读取对照也记录于 analysis.json；pending draft 不应渲染。', '',
        '| 会话 | 模型调用 | 状态 | reflection trace |', '|---|---:|---|---:|',
    ])
    for session in sessions:
        lines.append(f"| S{session['session']} | {session['model_calls']} | {session['run_status']} | {session['trace_count']} |")
    lines.extend(['', 'S4 还创建了 AGENTS.md，故不能把 S5 中文回复当作仅由记忆引起的证明。',
        '原始响应、工具事件、反思输入和逐会话漏斗日志均在同目录 JSON 中保留；修复后的离线真实 trace 重放单独报告，不能替代这里的原始模型运行结果。', ''])
    (RESULTS / 'report.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({key:report[key] for key in ('session_count','model_calls','captured_immediately','captured_after_eight_days','pending_records_unchanged','source_authority_unchanged','full_acceptance_passed')},ensure_ascii=False))


if __name__ == '__main__':
    analyze()
