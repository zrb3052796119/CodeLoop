def main() -> str:
    return "app ok"
