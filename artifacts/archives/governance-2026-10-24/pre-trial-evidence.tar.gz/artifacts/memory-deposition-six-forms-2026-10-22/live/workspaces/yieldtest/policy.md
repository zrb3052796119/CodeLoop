# 项目验证规范

本项目唯一支持的质量检查方式是 `./tools/check.sh`。
禁止使用 pytest 作为验证手段。
