# Project Memory

*Last updated: 2026-10-22 19:22*

## Task_Context

- Project verification rule: 本项目唯一支持的质量检查方式是 `./tools/check.sh`。 禁止使用 pytest 作为验证手段。
Applies when: When changing ./tools/check.sh. `self-reflection success list_files grep_files read_file run_command`
- Project declared dependencies: httpx.
Limitations: Declared in manifest; not yet exercised in this trace. `self-reflection success list_files read_file file_tree run_command`
- Observed error pattern for run_command / SyntaxError: SyntaxError: expected ':'
Applies when: When run_command fails with SyntaxError.
Limitations: Observed in one task trace; broader recurrence is not yet established. `self-reflection success run_command read_file edit_file`
