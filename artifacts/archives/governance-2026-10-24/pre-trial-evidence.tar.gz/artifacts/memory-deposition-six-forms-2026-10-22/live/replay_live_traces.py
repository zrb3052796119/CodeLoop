"""Replay the five captured live reflection traces without model/tool calls.

This verifies current code against the exact traces that exposed the live
recurrence-promotion bug. It writes fresh temporary memory authorities only;
original live captures and memory records remain immutable. This is an offline
regression result, never a claim that the live model sessions were rerun.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
sys.path.insert(0, str(REPO))
from scripts import memory_deposition_yield_audit as audit

RESULTS = ROOT / 'results'


def write_markdown(report: dict, out: Path) -> None:
    result = report['modes']['inject']
    lines = [
        '# 修复后的真实 trace 离线重放', '',
        '沿用真实五会话已经捕获的反思输入，使用当前代码在全新临时记忆库中重放。新增模型调用为 0；这不是修复后重新跑了一遍模型。', '',
        f"验收结果：{'通过' if report['passed'] else '未通过'}；{sum(report['checks'].values())}/{len(report['checks'])} 项检查通过。",
        f"inject 即时 durable + draft 捕获 {result['captured_immediately']}/6；模拟读取时钟推进 8 天后 {result['captured_forms']}/6。", '',
        '| 模式 | 声明依赖审批 | 重复观测次数 | 即时草稿块渲染 |',
        '|---|---|---:|---:|',
    ]
    for mode in ('strict', 'capture', 'inject'):
        form = report['modes'][mode]['forms']['declared_dependency']
        states = ', '.join(sorted({entry['approval_status'] for entry in form['entries']})) or '无声明泳道条目'
        recurrence = max([0, *(entry['metadata'].get('recurrence', 0) for entry in form['entries'])])
        lines.append(f"| {mode} | {states} | {recurrence} | {len(form['fresh_prompt_draft_ids'])} |")
    lines.extend(['',
        '- 声明依赖第三次观测后仍须人工审批，保留 inferred 与未实际使用的 limitation，不进入常规检索通道。',
        '- USER 偏好在伴随技术工作时仍进入 USER scope；capture 保持 pending。',
        '- 单次失败与权限拒绝保持 pending，新鲜条目不注入，8 天后仅按 draft 渲染。',
        '- 三模式读取前后 pending 完整记录不变；原五份 trace 的 SHA256 不变。',
        '- strict / capture 的 Recent draft notes 为空。', '',
        '原始真实模型运行共 29 次调用，在第三次声明观测时曾触发错误自动批准。原始 report.md / analysis.json 保留该失败；本离线结果证明修复，不覆盖历史。',
        '6/6 是经验捕获及读侧资格；渲染 ID 来自六个相关查询的并集，不意味着每个提示词同时包含所有记忆。S4 同时写入 AGENTS.md，后续中文回答不能单独归因于记忆。', '',
    ])
    out.with_suffix('.md').write_text('\n'.join(lines), encoding='utf-8')


def replay(out: Path):
    captures = []
    hashes = {}
    for number in range(1, 6):
        path = RESULTS / f'session-{number}-traces.json'
        raw = path.read_bytes()
        hashes[path.name] = hashlib.sha256(raw).hexdigest()
        traces = json.loads(raw)
        if len(traces) != 1:
            raise ValueError(f'Expected one root reflection in session {number}; found {len(traces)}')
        capture = traces[0]
        captures.append({'session': number, 'prompt': capture['task_description'], 'trace': capture['execution_trace']})
    # Replace only the audit harness's fixture provider. ReflectionEngine,
    # MemoryPipeline, MemoryManager, persistence, and rendering are all real.
    with tempfile.TemporaryDirectory(prefix='minicode-captured-trace-replay-') as directory:
        with patch.object(audit, 'reconstructed_sessions', return_value=captures):
            report = audit.run_audit(Path(directory) / 'fresh')
    report['audit_kind'] = 'exact_captured_live_trace_offline_replay'
    report['original_reference'] = str(RESULTS.relative_to(REPO))
    report['captured_sessions'] = report.pop('reconstructed_sessions')
    report['source_trace_hashes'] = hashes
    report['source_traces_unchanged'] = all(
        hashlib.sha256((RESULTS / name).read_bytes()).hexdigest() == digest
        for name, digest in hashes.items()
    )
    report['additional_live_model_calls'] = 0
    report['limitations'] = [
        'The actual model sessions were run before the recurrence fix; this is an offline replay of their exact reflection inputs against current code.',
        'No tool or model is called. Source traces are hash checked and untouched; each mode uses a fresh temporary authority.',
        'The eight-day result advances the read clock without editing entry timestamps, approval status or lifecycle.',
        'Session 4 also wrote AGENTS.md; later Chinese output does not isolate a memory-only behavior effect.',
    ]
    inject = report['modes']['inject']
    declared = inject['forms']['declared_dependency']
    declared_ids = {entry['id'] for entry in declared['entries']}
    preference = inject['forms']['user_preference']
    capture_declared = report['modes']['capture']['forms']['declared_dependency']['entries']
    capture_preferences = report['modes']['capture']['forms']['user_preference']['entries']
    checks = {
        'all_six_forms_captured': inject['captured_forms'] == 6,
        'pending_authority_unchanged_in_all_modes': all(result['pending_entries_unchanged'] for result in report['modes'].values()),
        'declared_remains_pending_after_recurrence': bool(declared['entries']) and all(entry['approval_status'] == 'pending' for entry in declared['entries']),
        'capture_declared_remains_pending_after_recurrence': bool(capture_declared) and all(entry['approval_status'] == 'pending' for entry in capture_declared),
        'capture_user_preference_remains_pending': bool(capture_preferences) and all(entry['approval_status'] == 'pending' for entry in capture_preferences),
        'declared_recurrence_threshold_exercised': bool(declared['entries']) and all(entry['metadata'].get('recurrence', 0) >= 3 for entry in declared['entries']),
        'declared_never_enters_canonical_prompt': not declared_ids.intersection(inject['fresh_render']['canonical_ids'] + inject['eight_day_render']['canonical_ids']),
        'declared_draft_renders_immediately': bool(declared['fresh_prompt_draft_ids']),
        'declared_evidence_still_inferred': bool(declared['entries']) and all(
            claim['epistemic_status'] == 'inferred' and any('not yet exercised' in item for item in claim['limitations'])
            for entry in declared['entries'] for claim in entry['metadata']['structured_reflection']['claims']
        ),
        'user_preference_in_user_scope': bool(preference['entries']) and all(entry['scope'] == 'user' for entry in preference['entries']),
        'fresh_failures_not_rendered': all(not inject['forms'][form]['fresh_prompt_draft_ids'] for form in ('single_tool_failure', 'permission_denied')),
        'aged_failures_render_as_drafts': all(inject['forms'][form]['aged_prompt_draft_ids'] for form in ('single_tool_failure', 'permission_denied')),
        'strict_and_capture_no_pending_draft_render': all(
            not report['modes'][mode]['fresh_render']['draft_ids'] and not report['modes'][mode]['eight_day_render']['draft_ids']
            for mode in ('strict', 'capture')
        ),
        'strict_no_new_user_preference_lane': not report['modes']['strict']['forms']['user_preference']['stored'],
        'source_traces_unchanged': report['source_traces_unchanged'],
    }
    report['checks'] = {key: bool(value) for key, value in checks.items()}
    report['passed'] = all(checks.values())
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    write_markdown(report, out)
    print(json.dumps({'kind': report['audit_kind'], 'passed': report['passed'],
        'captured_immediately': inject['captured_immediately'], 'captured_after_eight_days': inject['captured_forms'],
        'failed_checks': [key for key,value in checks.items() if not value], 'additional_live_model_calls': 0},ensure_ascii=False))
    return 0 if report['passed'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=RESULTS / 'fixed-code-trace-replay.json')
    args = parser.parse_args()
    return replay(args.out)


if __name__ == '__main__':
    raise SystemExit(main())
