# Task Plan: Six-form memory deposition

## Goal
Implement the pasted v1 proposal: preferences, declared dependencies, aged pending read-side drafts, and funnel telemetry. Preserve strict mode and all existing user edits.

## Phases
- [x] Read request and inspect workspace instructions/status.
- [x] Inspect current deposition, reflection, storage, and audit paths.
- [x] Implement independently gated experimental behavior and regression coverage.
- [x] Run targeted and broader checks; audit all six experience forms with reconstructed traces.
- [x] Run five live model sessions after explicit user authorization.
- [x] Fix the live-discovered declared-dependency recurrence promotion and verify captured-trace replay.
- [x] Review diff and deliver evidence with limitations.

## Decisions
- Use a dedicated artifact directory because root task_plan.md belongs to earlier work.
- Garbled pasted text is resolved against existing code; default mode remains strict/unset.
- Do not reset user workspaces until the existing audit and its ownership are understood.

## Status
Complete. Five authorized live model sessions finished (29 model calls, no timeouts), exposing a recurrence approval bug. Fixed that defect plus declaration-only retry TTL conflict. Exact captured-trace replay passes all 15 checks with no additional model calls; final focused/authority/audit suite 235 passed. Original live failure evidence remains unchanged.

## Errors Encountered
- Test dependency missing: installed in /private/tmp with bundled CA trust.
- Sandbox blocked local HTTP bind: broad test run repeated with loopback permission.
- Earlier live auto-review rejection resolved by explicit user authorization; retaining historical rejection artifact.

## Final validation
- 127 targeted/audit tests passed; 178 integration tests passed.
- 3/3 isolated semantic faults killed.
- Broad suite: 2899 passed, 20 failed (14 frozen source certification; 4 compaction baseline failures; 2 pre-existing hot-store 200ms timing bounds, repeatable under current scheduling).
- Reconstructed audit: inject immediate 4/6, aged 8 days 6/6; pending authority unchanged.
- Live provider execution completed after explicit approval; original data preserved. Initial live result is not full acceptance because of the declared-dependency recurrence defect.
- Fixed-code replay of all five captured real traces: 15/15 checks passed, immediate 4/6 and simulated day 8 6/6; pending records unchanged. Original live run and fixed offline replay reported separately.
- Final relevant tests: 235 passed. Actual before/fixed regression proofs: recurrence 11 fail/3 pass → 14 pass; retry 3 fail/1 pass → 4 pass.
