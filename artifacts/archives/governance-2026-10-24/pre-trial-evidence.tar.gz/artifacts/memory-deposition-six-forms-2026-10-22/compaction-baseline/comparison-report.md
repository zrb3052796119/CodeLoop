# Compaction regression attribution

Both isolated source snapshots produced **4 failed, 32 passed**, with the same failure node IDs and assertion locations.

- `test_agent_in_loop_guard_rejection_keeps_live_context_memory_free`: both reach `tests/test_memory_compaction_feedback.py:1083` and report the same extra final assistant `done` message.
- Two parameterizations of `test_pre_request_compaction_event_and_provenance_share_operation_id` plus `test_in_loop_compaction_event_and_provenance_share_operation_id`: both fail at unchanged `minicode/agent_loop.py:3389` because the test double `_ControlledCompactor` has no `tool_budget` attribute.

The baseline replaces only `minicode/memory_pipeline.py`, `minicode/reflection_evidence.py`, and `minicode/reflection_synthesis.py` with Git HEAD (`e092a9af973360e3239d4d49aeb1adf18e56146d`). Current `agent_loop.py`, tests, and every other source are preserved. HEAD also removes earlier uncommitted memory experiment code, so this is a counterfactual source baseline rather than a pristine pre-task checkout. These failures persist with the present task's changes to all three files removed.

The common harness redirects only the supervisor diagnostic file to a writable directory within each snapshot. It does not change `HOME`, production behavior, or any assertion. This avoids unrelated sandbox write errors that masked the desired assertion in the initial run. No import errors occurred.

Evidence: `snapshot-identity.json`, `run_isolated.py`, `current-compaction-isolated.log`, `head-memory-compaction-isolated.log`, and `comparison-report.json` in this directory. The shared worktree was not edited by this investigation.
