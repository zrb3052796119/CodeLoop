from pathlib import Path
import sys
import minicode.cybernetic_supervisor as supervisor
import minicode.agent_loop as agent_loop
import minicode.memory_pipeline as pipeline
import pytest

snapshot = Path.cwd()
assert Path(agent_loop.__file__).resolve().is_relative_to(snapshot)
assert Path(pipeline.__file__).resolve().is_relative_to(snapshot)
# Redirect diagnostics only; preserve all test and production behavior.
supervisor.SUPERVISOR_STATE_PATH = snapshot / "isolated-state" / "cybernetic_supervisor.json"
print(f"snapshot={snapshot}", flush=True)
print(f"pipeline={pipeline.__file__}", flush=True)
print(f"agent_loop={agent_loop.__file__}", flush=True)
raise SystemExit(pytest.main(sys.argv[1:] or ["tests/test_memory_compaction_feedback.py", "-q", "--tb=short"]))
