# Broad regression classification

Result: **2899 passed, 20 failed**.

| Failures | Classification | Evidence |
| --- | --- | --- |
| 4 | Existing compaction failures | Same assertions in current and HEAD-memory snapshots; see comparison-report.md. |
| 14 | Historical source certification | 2 v40 exact hash mismatches; 12 v41 failures blocked by changed-source closure before their intended branch. |
| 2 | Redis timing boundary | Independent pair still reaches ~0.2004s against strict <0.2s. Both interpreters load 0.190s budget; direct calls range 0.1974–0.2003s. |

The v41 changed-file set has 25 paths where 23 are allowed. The two extra paths are `minicode/memory_curator_agent.py` and `minicode/run_events.py`; neither was edited for this task. `memory_curator_agent.py` equals HEAD and already differs from v40. HEAD `run_events.py` also differs from v40, with additional pre-existing worktree edits. Therefore the v41 source closure blocker predates the deposition change.

The new `memory_pipeline.py` changes alter its digest, so they also diverge from byte-pinned v40, but HEAD `memory_pipeline.py` already differs from v40. `reflection_evidence.py` and `reflection_synthesis.py` are not tracked by v40. No frozen manifests or hybrid release evidence were regenerated.

The Redis timeout tests invoke the pre-existing `memory_hot_store.py` directly. The 190ms timeout can complete slightly above 200ms in this environment; direct system-Python calls reproduced that boundary without pipeline or reflection modules. This is timing sensitivity outside the deposition changes, not evidence of a new deposition behavior regression. No production files were modified by this investigation.

All 20 failures are classified. Machine-readable details and exact failed node IDs are in regression-classification.json; runtime inspection is in redis-runtime-inspection.json.
