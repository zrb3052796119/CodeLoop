# R2 完成门集成回归

仅新增 `tests/test_native_review_economics.py`，本子任务未修改生产源码。测试使用实际父 `run_agent_turn`、实际文件编辑、隔离公开 pytest、真实 review_test 执行与持久回执、原生 inspection / reconciliation 工具及 checkpoint。模型决策为进程内脚本，无远端调用。只有异常传播测试替换 `assess` 入口抛出确定异常，其余完成门和阶段流程运行生产实现。

覆盖：

- 通过真实独立 probe 后，review 累计 8 次请求耗尽；候选、编辑结果、probe 源和 receipt 在快照清理后仍保留。父仅 edit + final 两次模型请求，不追加模型；最终 `requirementsAccepted=false`、`completionReview=budget_exhausted`、partial，不指导修复未证实缺陷。
- 三阶段分别 2 / 2 / 2 次请求，经过原有真实验证路径批准；原生请求传递 adapter retry override 0。
- full 模式 review 运行 11 次后仍可完成批准，不施加本地配额，未加 retry override。
- 普通原生 inspection inconclusive 不附预算耗尽分类，不触发预算耗尽事件。
- 同一父重复 final 只创建一次链，review 两次进入累计仍限 8 次。
- 全局只余父收尾 2 次时，不发 review 请求、不消耗这 2 次。
- full 预算异常、非预算证据异常、祖先 cost 异常不被完成门包装成审查预算耗尽。
- review 90 秒阶段截止已到但父 600 秒截止仍有效时，保留已完成 probe，并返回未接受 partial。
- 入口父剩余 30 秒时审查时间余额为 0：实际公开检查通过后不发 review 请求，仍保留候选并返回 budget_exhausted partial，父截止尚未到。

首轮聚焦 10 项通过。相邻联合 54 项首轮 53 通过 / 1 失败，揭示本轮新实现的跨阶段 `LimitedBudgetView.snapshot` 问题：review 用 1 次、inspection 用 2 次后回 review，原快照把剩余次数显示为 5 而非 7。该问题由负责预算模块的同事修复；这是本轮开发中发现并修复的问题，**不是 HEAD 既有失败**。初次证据保留在 `initial-cross-phase-failure.txt`。

最终联合命令：

```sh
.venv-acceptance/bin/python -m pytest -q tests/test_native_review_economics.py tests/test_completion_review_limits.py tests/test_direct_completion_unavailable.py tests/test_requirement_completion_delivery.py
```

结果 **54 passed in 23.95s**。此时 economics 文件包含 10 项；随后仅追加零时间入口用例并单独运行：

```sh
.venv-acceptance/bin/python -m pytest -q tests/test_native_review_economics.py::test_no_review_time_left_preserves_live_parent_and_candidate
```

结果 **1 passed in 1.45s**。最终文件共 11 项。准确表述为“联合 54 项通过 + 新增 1 项通过”，不称一次运行 55 项，也不累加重叠的首轮聚焦结果。入口零时间的生产 try/catch 接线在追加测试前已由主任务修复，本次只验证当前行为，未制造或声称旧版反例。

最终测试 SHA：`e08a9ad245389a87a6acd615fcac38882ee33fc576320e8cf597d03152ee35a0`。日志为 `related-regression.txt`、`zero-time-entry.txt`；机器记录为 `verification-receipt.json`。`git diff --check` 通过，未提交 Git、未修改冻结评测、远端模型调用数 0。
