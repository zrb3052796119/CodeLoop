# 原生完成审查经济边界：本地实现结果

R1、R2 已实现，R3 按用户决定暂缓。新增 97 项回归全部通过，独立审阅未发现新的阻断问题。完整回归门仍有 4 项修前失败，不能宣称全绿；本轮没有启动新的远端模型评测。

## 实现

- R1 仅补充 `review_test` 三个字段共同出现的描述、具体缺字段报错，以及 inspection ready 状态必须为空 findings 的描述；接受条件不变。
- 默认 `MINI_CODE_COMPLETION_REVIEW_MODE=bounded`。三阶段分别限制 8/90s、8/150s、4/60s；嵌套探针归因共用所属阶段预算，内置适配器的内部重试也受限制。
- 同一父 turn 只冻结一次收尾预留（2 请求及对应 token 估计，时间 max(60s, 剩余 15%)）；链不超过入口剩余时间的一半。各阶段首次截止和额度不因重入刷新。没有有限父截止时链至多 300 秒。修复了原预算视图在交错阶段下错误显示余量的问题，实际账本仍只记一次消费。
- 耗尽返回候选与证据，最终回执 `delivery=partial`、`requirementsAccepted=false`、`completionReview=budget_exhausted`。已经提交且仍绑定当前候选的负裁决优先保留。普通 inconclusive 不冒充预算耗尽，祖先期限、全局预算和取消继续保留原错误。
- `full` 保留原本地无限审查及严格接受语义。认证续审状态仍保留；没有新增跳过首次独立 inspection 的路径。

## 验证与未过项

26 文件、389 用例合并运行：384 passed / 5 failed，耗时 153.42s；其中新增 97 项全部通过。第五项旧续审测试需要读取超过四页证据，默认 bounded 按新限额停止。已证实该测试在真实修前 HEAD 和当前 full 均通过，因此只明确其 full 模式，不改断言；修正后两个参数均通过（2 passed / 8.11s）。没有再次运行整个合并集合，不能把分批复核写成一次全绿运行。

仍保留的四项修前失败，均在真实提交 `89288e8741cb4d87f8d3b094597a4c995d9ea5ca` 复现：

- `test_completion_failure_adjudication.py::test_true_product_gap_is_the_only_assertion_feedback_sent_to_executor`
- `test_completion_failure_adjudication.py::test_classified_product_gap_cannot_restore_without_each_exact_independent_authority`
- `test_completion_failure_adjudication.py::test_corrected_expectation_exposes_real_gap_and_returns_it_in_same_assessment`
- `test_completion_probe_purposes.py::test_confirmed_product_gap_preserves_acceptance_and_diagnostic_history`

R1 同字节修前反例为 8 failed / 2 passed，修后 10 passed；重试边界反例为 6 failed / 9 passed，修后 15 passed。新增测试实际覆盖 parent/review/inspection/reconciliation 循环、本地 pytest 探针、阶段耗尽与续审状态、物理重试、父预留及负裁决提交后中断，不涉及远端模型效果证明。

## 证据与交付范围

`final-regression.txt` 保存合并结果；`strict-resume-final.txt` 保存模式明确后的复核；`r1/`、`r2/`、`r2-retries/`、`r2-integration/` 保存反例、修前失败复现和集成证据。`r2-independent-review.md` 保存最终只读审阅。早期 R1 及子任务的源哈希对应当时快照，最终源码以 `implementation-receipt.json` 为准。

`implementation.patch` 只汇总本次源代码和测试变更，其基线是保存的实际工作区修前快照（含此前已存在的工作），不是干净 HEAD。来源及哈希见 `patch-provenance.json`；配置示例追加、用户方案修订和诊断文件另保留在工作区。未提交或推送，未覆盖原有无关修改。

冻结的 trigger-gen2 manifest 与预注册提交逐字节相同，已有 gen-2/trigger-gen2 跟踪材料无 diff，见 `evaluation-preservation.json`。真实效果验证仍需遵守原方案的 TLS 前置与另行预注册。离线预算公式不能证明 stock 模型在 90 秒 review 窗口内必定完成；修前约 92 秒仅公开检查和新增回归通过，独立 probe 约 230 秒才通过，方案已订正。
