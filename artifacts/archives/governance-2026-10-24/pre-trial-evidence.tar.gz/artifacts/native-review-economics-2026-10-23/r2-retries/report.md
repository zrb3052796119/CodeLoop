# R2 物理重试边界子任务

`run_agent_turn` 新增可选 `max_retries_override: int | None = None`。正常请求和收尾请求通过已有 `model_call_control` 接口传递非 None 值，与请求本来已有的重试上限取 min，因此 phase / native handoff 的既有 0 不会被放宽。默认不传新限制，适配不接受 optional kwargs 的旧 model 仍由原接口投影兼容。

Anthropic 的非流式 HTTP 400 `cache_control` 兼容回退现在受显式上限约束：显式 0 只发一次；显式正数只有尚余重试额度才允许去掉 cache markers 后重发。此前已消费的 429 / 网络重试计入同一 adapter allowance。未传 override 时保留原兼容行为，包括 runtime `modelMaxRetries=0` 时仍允许一次 cache fallback。

本任务只改 `minicode/agent_loop.py` 的签名和两个 request-options 构造位置，以及 `minicode/anthropic_adapter.py` 的 cache fallback 条件。没有修改宿主外层 timeout / network continuation：其后续逻辑调用仍分别消耗现有 step / budget 准入；本参数限制单次 adapter 调用内的物理重发，不承诺停止整个 turn 的后续调用。原生 review / audit runner 由主任务接线，本子任务未修改。

修前两文件完整快照及 SHA 在 `before/`、`before-snapshot.json`。`agent_loop.py` 修前已有用户及其他阶段改动，基线明确为真实工作区快照，不能称纯 HEAD。反例使用当前依赖的隔离副本加这两份逐字节真实 before 源码；没有合成缺陷。本次精确源码增量见 `retry-boundary.patch`。

```sh
.venv-acceptance/bin/python -m pytest -q tests/test_native_review_retry_limits.py
```

最终 **15 passed**。test-counterexample bundled verifier 的同字节真实修前反例 **6 failed, 9 passed**，状态 **PROVEN**。四项旧循环失败直接体现 OpenAI / Anthropic 实际发送次数超出 caller 的 0 / 1 上限；测试在旧签名不支持该参数时调用原公开 loop API，因此不是 TypeError 反例。另两项体现 Anthropic 显式 0 和已耗尽显式 1 后仍进行 cache fallback。其余测试证明默认兼容回退、正数余额、phase / reserved closing 的更严格 0、旧模型适配均保留。详情在 `counterexample.json`、`counterexample-run.txt`。

```sh
.venv-acceptance/bin/python -m pytest -q tests/test_native_review_retry_limits.py tests/test_model_adapter_call_controls.py tests/test_anthropic_adapter.py tests/test_implementation_phases.py tests/test_model_transport_continuation.py
```

联合回归 **131 passed in 3.79s**；此数字含新测试，不与聚焦结果累加。`git diff --check` 通过。完整日志与机器收据在 `related-regression.txt`、`verification-receipt.json`。所有网络边界均为本地模拟响应，远端模型调用 0。未提交 Git、未触碰冻结评测。临时基线已清理，持久 before 与证据保留。
