# Native completion review economics repair

## Goal
Review the new native-review-economics proposal against actual contracts, implement safe authorized changes, and verify offline without changing frozen evaluation evidence or launching paid trials.

## Phases
- [x] Read proposal and current workspace status.
- [x] R1 descriptions and actionable validation errors, preserving acceptance semantics.
- [x] Review R2 physical request/deadline/closing reserve semantics and bounded delivery status.
- [x] Review R3 evidence independence, digest binding, and offline acceptance claims.
- [x] Implement R2 economic boundaries without weakening acceptance; R3 deferred by the user.
- [x] Focused integration/counterexample verification and independent review.

## Constraints
Preserve existing user changes, prior Phase0/1/2 work, and all frozen gen-2/trigger-gen2 materials. No TLS bypass, model switching, remote reruns, new audit probes or controllers. R1 must not relax runtime validation. Proposal conflicts about accepted vs incomplete delivery must be resolved before dependent behavior changes.

## Status
R1/R2 implementation and focused verification complete; independent reviews found no new blocking issue. All 97 new regressions passed in the 389-case combined run. That run had 384 passes and 5 failures: four reproduced at real HEAD 89288e87, plus one old strict-resume test that now needs explicit full mode. The latter passed on real HEAD and current full; after the mode-only fixture clarification both parameters passed (2/2). No assertions were weakened. The four unrelated preexisting adjudication/migration failures remain, so the full green-suite gate is not claimed. R3 is deferred by the user. No paid calls or frozen-input changes.
