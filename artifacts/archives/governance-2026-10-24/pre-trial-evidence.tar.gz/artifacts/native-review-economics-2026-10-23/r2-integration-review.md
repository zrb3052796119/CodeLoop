# R2 集成边界只读审查

日期：2026-10-23。核对更新后的提案、完成门、原生审查、失败归因及恢复路径。未改生产或文档，未运行模型或测试。以下行号对应审阅时源码，R2 正在实现，后续可能移动。

**结论：真实预算耗尽可以返回 partial，但必须把“已有语义裁决”和“本轮停止原因”分开处理。负结论优先于通用 budget_exhausted；原有非预算 inconclusive 不能强行纳入三值分类。`completionReview` 最适合作为有证据时才附加的外层终态字段，不改原生裁决内容。**

## 1. 已确认 negative 的保留与优先级

目前已有可直接复用的负结论：

| 来源 | 持久化/验证路径 | 预算耗尽时应保留的事实 |
|---|---|---|
| 普通 reviewer 提交源码支持的 missing | `implementation_completion_review.py:1374–1403` 在发布 decision 前调用 `_retain_repair_decision(origin=validated_review)` | 已确认具体缺失；不能降格为“尚无裁决” |
| 独立 inspection 的 missing | `completion_coverage_audit.py:902–924` 先持久化原生 decision，再调用 `accepted_negative_sink` | 独立源码缺失裁决已成立；未知 probe 不抹去它 |
| reconciliation 提交 missing / missingBehaviorEvidence | `completion_coverage_audit.py:666–675` 同样在发布 decision 前调用 negative sink | 覆盖否定已有原生依据；不等于所有未知 probe 都是产品缺陷 |
| 独立归因的 product_gap | `implementation_completion_review.py:1517–1528` 验证并保留 `failureAdjudications`；`:256–264` 按当前 candidate、probe source、receiptRef、objective 精确查询 | 只有绑定当前失败收据的已确认 product_gap 才是修复依据；不能仅看到 failed probe 就推断 |

前三类通过 `retain_negative_audit`（`implementation_completion_review.py:1778–1795`）或普通 submit 汇入 `acceptedRepairDecision`。现有 `_accepted_repair_for_candidate`（`:781–806`）不仅检查 candidate/spec/objective/原生来源，还重新核对当前源码 anchors；正常 `assess` 已在重新执行 probe 之前优先恢复该结论（`:822–829`）。应复用该路径，而不是只检查某个 dict 存在或从模型文本猜 negative。

**最小集成顺序：**

1. 只捕获审查阶段有明确来源的预算/时间上限异常；父级 cancellation、全局 deadline、权限/传输/存储错误仍保留原分类及传播语义。
2. 在父级仍有效的 context 下核对当前候选与当前公开检查绑定。子阶段期限过期不能让这个只读恢复查询继续使用已过期的子 deadline，也不能解除父级期限或取消信号。
3. 优先取当前候选有效的 accepted repair，再取已经验证保存的当前 product_gap。复用原 result / findings / requirements / repairProbes / receipts / authority refs；记录 budget stop 事件，但语义裁决仍是 changes_required，对应外层 `completionReview=rejected`。
4. 只有缺少上述已确认结论、且本次停止确属预算限制时，才记录 `completionReview=budget_exhausted`，保持 requirementsAccepted=false，并停止本轮工作而保留续审状态。

不要在外层 catch 再调用完整 `assess` 获取旧结论：它会重跑 probe、刷新收据或触发模型，也可能立即再次遇到过期的期限。可将现有内嵌 `confirmed_product_gap_result`（`:1422–1436`）提取为只读宿主查询，与正常路径共用同一绑定规则；不要另写一套宽松判断。仅有 `probe_error`、待审 replacement 或普通失败 probe 均不能升级为 product_gap。

### 一个外层 catch 无法自行补救的提交窗口

`ProbeFailureAdjudicator._review` 在 `probe_failure_adjudication.py:289` 已持久化 native decision，但在 `:357` 又检查 deadline；其 `assess` 在 `:202` 再检查 deadline。只有完整返回后，父 review 才在 `implementation_completion_review.py:1523–1526` 验证并登记到 `_failure_adjudications`。

若阶段期限恰在 native product_gap 提交后触发，父 review state 尚无这条结论；只扫描父 state 会把真实已提交 negative 表述成未裁决。裁决 owner 边界需要保留已提交且验证通过的结果：可用宿主内部的已提交结果返回/回调，将其送入现有 adjudication ledger；不新增模型 schema 或回执类型。恢复时仍须通过现有 `validate_adjudication_record` 和当前 candidate/receipt 绑定，不能扫描任意临时文件或将旧 digest 的 negative 用于新候选。现有普通 review / inspection / coverage 的 negative sink 已提供这一类提交优先模式。

## 2. 三值分类应是可选投影，不覆盖所有 inconclusive

以下既有状态没有“被拒”或“预算耗尽”的充分证据：

- 普通 reviewer 正常结束但没有合法原生提交：`implementation_completion_review.py:1896–1899`。
- provider partial / 普通 final 导致 coverage audit 没有原生 verdict：`completion_coverage_audit.py:458–467` 的 `coverage_audit_interrupted` 本身并不等于预算耗尽。
- 未归因失败、待审核替代关系：`implementation_completion_review.py:1547–1560,1852–1858`。
- 当前候选变化、检查不可用、没有已授权独立 pytest target：`:818–841,848–855`；以及 `agent_loop.py:3786–3790` 的最终候选变化保护。
- inspection 明确提交 inconclusive：`completion_coverage_audit.py:918–920`，并由 `implementation_completion_review.py:1827–1830` 保留。

因此可使用“字段存在时只允许 approved / rejected / budget_exhausted”的三值闭集，但不要要求每个终态都必须有该字段：

| 真实事实 | `completionReview` | requirementsAccepted |
|---|---|---|
| 当前候选经过现有完整门得到有效 approved | approved | true |
| 当前候选有已验证原生负结论/已确认产品缺陷 | rejected | false |
| 尚无裁决，宿主明确观察到审查预算上限耗尽 | budget_exhausted | false |
| 其他 inconclusive、未开始审查、候选失效或无已分类结论 | 省略；保留原 status/reason 和证据 | false |

不能将所有 `status=changes_required` 自动标成“独立审查 rejected”：公开检查未通过/不可用可在审查前由 `agent_loop.py:3722–3726` 产生该 status。分类要保留来源，不能靠 status 或异常字符串泛化。

## 必须保持的回执和恢复路径

- `agent_loop.py:3798–3804` 的原生 completion decision 仍由真实 decision 驱动；`requirementsAccepted` 只能来自当前有效批准。预算耗尽没有批准时不可从普通 reviewer proposal 或绿 probe 补出批准。
- `:3829–3854` 已区分 audit pending / attribution unresolved 的反馈与同一 owner 路由。预算终止不应落入默认“修复已证缺陷”的提示；没有缺陷依据时，只能说明审查暂停。已证 negative 保留原修复事实，但本轮因预算停止是单独控制流，不必重写认证 decision 的 `canContinue` 或 findings。
- `:6603–6628` 的 `IMPLEMENTATION DELIVERY RECEIPT v1` 已是最终 partial 外层：保留 executionEnded、lastPublicChecks、requirementsAccepted=false、continuesAfterResponse=false，以及 `_partial` 和 `_host_implementation_receipt` 标记。这里适合附可选分类。
- `completion_repair_decision.py:59–70` 的 `delivered_repair_matches` 对除指定 envelope/storage 外的全部字段做精确比较。**只给 feedback receipt 增加 completionReview、却不改变原认证 decision，会导致续审去重失配。** 最小方案是把新分类留在外层终态回执/独立事件，不改 native decision、原始 feedback 和绑定 bytes；不要扩大忽略字段集合来吞掉任意新增语义。
- `completion_coverage_audit.py:1045–1053` 在异常后保留真实 audit context；`agent_loop.py:7323–7347` 最终保存 `HostImplementationContinuation`，含 reviewState、messages、feedback、owner、candidate/spec digest。预算 partial 必须经过这些 finally 路径，不清空 pending audit、unaccepted draft、失败归因、supersessions 或已有负结论。

## 建议的局部反例

仅需针对这些集成边界补本地行为反例，无需广泛重跑：source-negative / inspection-negative / coverage-negative 提交后立即耗尽仍保留 rejected 与原证据；product_gap 在父登记前的截止窗口不丢失；同样输入没有 native negative 时仍为 budget_exhausted；正常无 verdict / inconclusive / 传输失败不伪分类；旧候选 negative 不复用；终态 metadata 不破坏同一 owner 续审去重和证据字节。

已有相关测试入口：`test_missing_attribution_order.py`、`test_completion_negative_unknown_probe.py`、`test_completion_repair_priority.py`、`test_completion_failure_adjudication.py`、`test_repair_decision_boundaries.py`、`test_completion_repair_feedback_deduplication.py` 和 `test_completion_coverage_recovery_bridge.py`。

## 后续授权实现记录

上述只读审查后，root 授权实施只读预算结果方法，并自行补充 bounded-only product_gap 提交 sink。相关局部实现、独立 sink 审查和最终 10 项通过记录见 `r2/budget-result-report.md`。提交后 deadline 异常本身仍失败/传播；bounded 仅提前保留已验证负结论，随后由父根据当前完整候选重新绑定。full 保留原异常路径。初审提出的未登记提交窗口在 bounded 路径已获得针对性反例覆盖，不应再把该窗口写为当前尚未修复的问题。
