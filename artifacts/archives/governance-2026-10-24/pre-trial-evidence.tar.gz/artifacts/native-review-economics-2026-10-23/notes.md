# Notes

Source proposal: docs/2026-10-23--native-review-economics-repair.md. Baseline HEAD: 89288e87. Existing working tree contains earlier multi-agent repairs and unrelated memory work.

Initial review flags: 92s stock point had public/new regression checks but independent probe arrived later; max_steps is not necessarily a physical request cap; bounded incomplete accepted delivery differs from strict accepted semantics; R3 must preserve independence of semantic evidence validation. These require source checks, not assumptions.

## Source-confirmed design conflicts

- agent_loop.py marks direct_completion_accepted only when decision.status == approved; its finally receipt explicitly emits partial/requirementsAccepted=false otherwise. A budget exhaustion flag cannot simultaneously retain strict acceptance and create an accepted final. User clarification pending.
- implementation_completion_review.py treats reviewer approval as an author proposal. Independent inspection is intentionally blind before disclosure, and the final decision requires a valid inspection approval. Reviewer-authored passed probes plus unchanged candidate do not supply that independence. User clarification pending: reuse actual completed inspection context only, or defer R3.
- max_steps counts the local loop; nested probe adjudication must share phase budget views to obey a chain cap. Full mode should preserve original unlimited local steps and shared ancestor ceilings.
- Stock 92 seconds refers to public/new regression checks. Independent acceptance probe passed later. A hypothetical 90-second review cannot be claimed to reproduce the observed 184-second review or prove accepted final.

## Search notes

Initial rg queries mentioned nonexistent minicode/runtime.py and minicode/agent_result.py; actual completion receipt lives in agent_loop.py. No source or runtime failure resulted. No AGENTS.md was found in the non-artifact repository scan.

## R2 implementation decisions

The proposal file changed during this turn: R2.3 explicitly rejects accepted-on-exhaustion and requires requirementsAccepted=false. This resolves the first pending design question; R3 first-inspection bypass has not been approved. Implement only the unambiguous economic boundaries.

Reuse the existing WorkerCallBudget as LimitedBudgetView, retaining the workflow alias. Create one parent-turn chain view with preserve_calls=2 and one estimated token floor for the same closing allowance, then persistent 8/8/4 phase views with no repeated floor. Use the same private ToolContext for callbacks so nested probe adjudication inherits the active phase. Full mode keeps existing local unlimited behavior and adapter settings. Without a finite ancestor deadline, stage ceilings remain and the chain is at most 300 seconds.

Physical request attempts require the existing adapter retry override to be set to zero in bounded native calls. Anthropic's explicit-zero cache fallback loophole is fixed, default behavior preserved. Arbitrary third-party adapters that do not support this hook can only promise shared budget admissions; no universal transport-attempt guarantee is asserted.

Only actual approved/rejected/budget-exhausted outcomes get the new optional completionReview terminal classification; unrelated inconclusive results are not misclassified. Keep this field out of authenticated repair decision payloads because continuation equality is exact. Local exhaustion returns retained candidate and evidence without inferred repairs. Already committed native negative decisions keep priority, including a product-gap commit callback before post-submit deadline checks.

The user's asynchronous reply explicitly confirmed incomplete delivery with requirementsAccepted=false and deferral of R3. This matches the updated proposal. No remaining acceptance-policy question blocks R1/R2.

Final regression setup initially named nonexistent tests/test_agent_budget.py, so the file-list validation stopped before pytest ran; the next attempted runner also found no generated list. Replaced it with the discovered tests/test_unlimited_agent_budget.py and validated all 26 paths before starting the actual combined regression. This was a command setup error, not a test failure.

The first frozen-manifest check used a mistyped hash from the compacted summary (missing two characters). Replaced that secondary reference with exact bytes from preregistration commit e85a95803e248e157523e10dd0f1fe5bbed3f9bb; current manifest matches byte-for-byte. The correct SHA is recorded in evaluation-preservation.json. No frozen bytes changed.

Final combined result: 384 passed / 5 failed across 26 files (389 cases, 153.42s), including all 97 new tests passing. Four old failures are separately reproduced at real HEAD. The fifth expects unlimited strict reconciliation and uses more than four requests: real HEAD passed and current full passed. Set only that test's mode to full, retain all assertions, and verify both parameters (2 passed / 8.11s); bounded exhaustion remains covered by the new actual-loop tests. Real-HEAD reproduction initially hit the old unguarded global telemetry write; its temporary test launcher redirected only SUPERVISOR_STATE_PATH into the exported temporary directory, without editing Git source/tests or the user's global files. Original setup failure and valid rerun evidence are both retained. No unrelated adjudication/migration behavior was changed to force the four existing failures green.
