# R3 独立审查：证据短路的语义边界

日期：2026-10-23。非冻结诊断材料；只读审阅当前提案、生产源码和 stock 已有请求元数据。未修改生产或冻结材料，未调用模型，未重跑评测或测试。

**结论：当前 R3 的四个条件不足以跳过首次独立 inspection，同时保持现有批准语义。可行的最小替代是复用已经完成独立观察、通过宿主认证的同一 audit 续审状态；该能力大部分已经存在。stock 的离线时间线只能支持预算可行性分析，不能证明新的路径会形成 accepted final。**

## 必须修正的阻断

### P1：普通 approved 与 passed probe 不是独立覆盖批准

`implementation_completion_review.py:1746–1755` 将普通 reviewer 的 approved 保存成 proposal，随后立即把 decision 清空。这里“测试作者不能自行批准其测试的语义充分性”的作者是**写 review_test 的普通 reviewer**。保留普通 review 这一腿，不等于保留另外的独立覆盖判断。

stock 请求 9 的 probe 是普通 reviewer 编写后由宿主隔离执行；它提供独立于实现者的测试及真实执行证据，但不能单独证明该测试覆盖了原始需求。请求 10 的 approved 仍是同一测试作者的覆盖提案。R3 第 1 条把该设计理由用于支持省略后续独立观察，解释方向相反。

现有协议明确要求 auditor 在看到普通提案前独立读取候选源码，再由**同一 auditor 上下文**核对提案：`completion_coverage_inspection.py:138–146,318–329`。最终批准还硬性要求有效的 inspectionRecord、`phase=reconciliation` 和 `ready_for_evidence`：`implementation_completion_review.py:1864–1871,1900–1911`。只凭四个条件直接进入新建的轻量 reconciliation，会被这些守卫拒绝；绕过或合成 inspectionRecord 则改变验收语义。

### P1：digest 和 source manifest 只能绑定证据，不能补出独立观察

`has_pending_coverage_audit`（`implementation_completion_review.py:232–234`）只判断 pending 状态存在且 candidateDigest 相同，并不是完整复用校验器。不能将它直接升级为“已有证据足够”的判据。

现有强依赖如下：

| 输入 | 当前要求 | 可复用边界 |
|---|---|---|
| 候选内容 | `implementation_execution.py:16–80` 对可读候选输入、公开测试、配置、导入源码和写范围标记统一取 digest | 必须继续复用完整函数；仅“写范围未变”不能代替它 |
| 独立源码观察 | `completion_coverage_inspection.py:206–239,257–278` 要求实际 read_file 送达的范围覆盖引用，并匹配源码 digest | 可恢复同一已认证 audit 的实际 reads；不能把文件清单、哈希或普通 reviewer 的阅读记为独立 auditor 的阅读 |
| 原始任务及权限下的证据 | `completion_coverage_audit.py:165–187` 校验完整 authority，含原始需求、proposal、sourceAnchors、probeEvidence、supersession obligations 和 behaviorContract | 除候选 digest 外，还须保留原始 authority 与当前 authority 的精确一致性 |
| 完整 probe 源码 | `completion_coverage_audit.py:385–419` 要求当前候选的 active passed acceptance、真实执行收据，以及完整 probe source 已向该 audit 上下文送达 | 可以恢复已送达范围；不能把只有路径/摘要/哈希的 manifest 当作已读完整测试 |
| 上下文及阶段 | `coverage_audit_state.py:131–219` 验证认证记录、绑定、真实上下文、原始任务、阶段和证据送达 | inspection 阶段不能提前暴露 ordinary reviewer claims；旧版状态不能冒充已经完成独立观察的新状态 |

因此，可重用文件字节、收据、source manifest 和宿主绑定记录，避免重复采集；这些材料仍须满足当前 auditor 的实际证据送达及语义裁决要求。完整性证据不能替代观察或裁决。

### P1：stock 的“约 350 秒 accepted final”不受离线轨迹支持

证据来自 `run-v1/private/trigger-stock-allocation-r1-auto/transport-summary.json`、`execution-start.json` 及既有 `native-review-diagnostic.md`。以下仅使用请求时间、工具种类和终态，不引用内部推理。

| 真实里程碑 | 从执行开始计时 | 已知事实 |
|---|---:|---|
| 父工作完成 | 约 92 秒 | 公开检查及新增回归已通过；此时还没有请求 9 的独立 acceptance probe |
| 普通 reviewer 入场 | 92.153 秒 | 开始请求 5 |
| 请求 9 返回 | 约 229.632 秒 | acceptance probe 通过 |
| 请求 10 返回 | 约 276.387 秒 | 普通 approved proposal；没有独立 coverage approval |
| 独立 inspection 提交成功 | 约 538.662 秒 | 请求 17；之后才可披露 ordinary proposal |
| 首次 reconciliation 请求返回 | 约 596.836 秒 | 请求 18 用时 58.123 秒，只完成证据读取；未形成最终批准 |
| 请求 19 | 596.882 秒开始，600 秒截止 | 没有终态，不能推定最终裁决 |

据此，提案 §0 的“92 秒即通过独立 probe”需要改为“92 秒公开检查和新增回归通过；独立 acceptance probe 在约 230 秒通过”。review 真实耗时约 184 秒。若从第 92 秒设 90 秒上限，会在约第 182 秒、请求 8 尚未完成时截止，尚不满足 R3 的 probe passed 和普通 approved 两项条件。

将 review 改写成 90 秒、reconciliation 改写成 30 秒是在假设新行为，不是重放既有行为。R1 可能减少格式返工，但请求 8 同时包含测试编写，不能直接扣除整次耗时；实际唯一完成的 reconciliation 请求本身已有 58 秒，且没有提交批准。

离线脚本可以证明“给定合法响应与规定时长，宿主正确计费、保留预留并在有效批准后形成 accepted final”；它不能证明 stock 模型会在新上限内生成这些合法响应。生产门仍在 `agent_loop.py:3776–3799` 检查 deadline、当前 digest、当前检查，且仅 `status=approved` 接受完成。没有真实批准时，时间加法不能补出它。

## 最小可行替代：保留首次独立观察，复用认证续审

1. 将 R3 限定为“已完成独立观察的同一 audit 续审复用”。沿用现有 v3 pending state、原始 authority、inspectionRecord、messagesRecord、证据送达记录及其现有验证；不增加 schema、探针、回执类型或新的宽松批准条件。
2. 已处于 reconciliation 的有效 continuation 走 `completion_coverage_audit.py:942–990`：恢复同一上下文、已送达 probe source、部分证据页和未批准 draft，继续缺失部分，不重新付一次 inspection 成本。
3. inspection 已提交但披露时存储中断的情况，现有 `:993–1015` 可跳过重复 inspection 运行，披露后继续；这是有效的短路，已有 `test_disclosure_storage_interrupt_retains_committed_inspection_for_retry` 覆盖。
4. 首次普通 proposal 仍须独立源码观察。现有提示已明确不要求固定数量新测试（`completion_coverage_inspection.py:142`）；观察允许空 probeIds（`:257–275`）。可以让 auditor 在合理预算内核查实际源码，然后沿用已有 acceptance probe 做 reconciliation，无需强制另造 challenge。
5. 候选、原始任务、proposal、替代关系或相关证据绑定失效时，按已有规则拒绝复用。预算耗尽但没有独立 verdict，保留 pending/inconclusive；不能将其包装成原语义下的 approved。

这项替代可以减少**中断后重复审查**，不能宣称消除 stock 在请求 10 后的首次独立 inspection。首次路径的成本改善来自描述修正、明确经济边界和实际模型行为，仍需另行验证。

## 验证范围与现有回归入口

无需新增机械文案断言。后续如实现有效复用，关键反例应验证：只有普通 approved + passed probe 时仍无独立批准；有效同一 audit continuation 不重跑已完成的 inspection；源码/只读依赖/收据/proposal 变化不获复用；未送达材料不能凭 manifest 获得阅读信用；无合法最终裁决仍不 accepted。

现有入口：

- `tests/test_independent_coverage_inspection.py:50,95,138,167`：先独立读再披露、真实上下文续审、披露失败恢复、旧上下文不得冒领独立阅读。
- `tests/test_coverage_audit_resume.py:107,171,217,316,399`：真实续审、篡改拒绝、未送达范围、压缩后证据保留、执行但未送达不获信用。
- `tests/test_completion_candidate_inputs.py:16,54,65,99`：只读依赖、新输入、权限和公开测试/配置变化。
- `tests/test_approved_completion_revalidation.py:44,51,67`：已有 approved 的重新验证及原所有者修复。

另有一项与 R3 验收直接相交的提案冲突：R2.3 的 `incomplete` 放行改变当前“只有 approved 才 accepted”的语义。即便产品决定采用，也不能用它证明 R3 在不放宽验收的前提下达成 accepted final，不能把该结果与现有严格门混为同一成功口径。
