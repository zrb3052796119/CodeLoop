# R1 本地验证

只完成 R1：`review_test` 的三个 optional 字段各自说明 `sourceEvidence / correctsProbeId / correctionReason` 必须一起提供或全部省略；原 invalid-shape 分支的 `message` 列出具体缺失字段。现有 `missingFields`、`unexpectedFields` 和全部校验条件保留。inspection `findings` 的描述说明 `ready_for_evidence` 必须为空数组。没有修改 R2 / R3、运行时验收规则、冻结评测或模型调用。

源码改动：`minicode/implementation_completion_review.py:1084,1662`、`minicode/completion_coverage_inspection.py:29`。新增聚焦测试：`tests/test_native_review_schema_contracts.py`。所有既有 if / while / conditional / assert 条件表达式与修前逐 AST 一致；`git diff --check` 通过。

真实修前快照保存在 `before/minicode/`，两文件逐字节等于提交 `89288e8741cb4d87f8d3b094597a4c995d9ea5ca`，SHA 见 `before-snapshot.json`。反例基线使用该提交的真实 `minicode/`、`tests/`、`pyproject.toml` 导出，并由 test-counterexample 的 bundled verifier 复制最终同字节测试；没有制造缺陷。

最终聚焦命令：

```sh
.venv-acceptance/bin/python -m pytest -q tests/test_native_review_schema_contracts.py
```

修后 **10 passed**；真实修前 **8 failed, 2 passed**。8 个反例仅覆盖新增应见的 schema 描述及具体缺字段错误信息：三个字段只提供其一、各缺其一共六种、review schema 一项、inspection provider schema 一项。修前和修后均通过的两项验证原 shape / correction-authority 检查和合法新 probe / 真实 setup-error 修正；无效源行号仍拒绝，未提交 approval 不会凭 probe 通过而批准。inspection 测试在真实本地 provider-body / loop 路径上验证 ready + 非空 findings 被拒且不提交状态，然后合法空 findings 成功。最终测试 SHA：`d22a98234aa4de8feab32218a9acbe9f8f901dc31d7e942819132098415b4f62`。证据：`counterexample.json`、`counterexample-run.txt`、`verification-receipt.json`。

相关回归命令：

```sh
.venv-acceptance/bin/python -m pytest -q tests/test_native_review_schema_contracts.py tests/test_implementation_completion_review.py tests/test_completion_probe_purposes.py tests/test_inspection_submit_diagnostics.py tests/test_inspection_tool_surface.py tests/test_completion_coverage_gate.py
```

最终结果 **59 passed, 1 failed**（37.56s，不与聚焦结果累加）。唯一失败为 `test_completion_probe_purposes.py::test_confirmed_product_gap_preserves_acceptance_and_diagnostic_history`：期望 `legacy_acceptance_product_gap`，实际 `confirmed_product_gap`。同一旧测试在真实修前提交导出上也以完全相同原因失败（`preexisting-failure-baseline.txt`）；未修改此断言或相关生产路径。完整结果保存在 `related-regression.txt`。因此 R1 反例已证明，但不能声称全部既有审查回归全绿。

未提交 Git，远端模型调用数 0。临时 Git 导出基线已清理，持久 before 快照及所有证据保留。
