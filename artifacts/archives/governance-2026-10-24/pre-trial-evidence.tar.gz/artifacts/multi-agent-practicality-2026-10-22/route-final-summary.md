# Route / admission verification

All runs used local deterministic fixtures and host test commands; no paid model run or Git commit.

- `route-final-v6.txt`: 317 passed across scheduler routing, trace/history, repair audit and workflow integration (13 files).
- `route-followup-fixtures.txt`: 57 passed across checked candidates, role boundaries, analysis convergence and optional-role fixtures (4 files).
- `route-risk-final.txt`: 102 passed across v6/v5 review policy, filesystem risk routing and sealed historical replay (4 files).
- `route-last-independent-review.txt`: 84 passed across full brief transport, admission, structured usage and finalization resilience, before the final lease quote changes.
- `route-budget-followup.txt`: 90 passed across subprocess leases, unlimited budget and Analyst/Executor budget behavior after the lease quote changes.
- `route-last-guard-check.txt`: 45 passed after the final import fix: all admission tests, digest-mismatch no-worker/no-parent-write guard and the public parallel-exploration success path.

Counts overlap and must not be summed. The intermediate `route-admission-lease-final.txt` had 113 passed / 1 failed due to a missing `ToolUsageCounts` import; the failing digest guard was rerun successfully in `route-last-guard-check.txt` after the root agent fixed it.

Independent review found and addressed: dynamic diagnostic Analyst adjudication trace replay; directory scope wrongly treated as an exact-new-file exemption; explicit Analyst/Reviewer instructions present only in the complete brief body; existing subprocess-lease occupancy omitted from preflight. The root agent handled the failed-subprocess prose truncation gap and finalization usage fallback. New admission quotes preserve local caps and downstream floors, charge no resources, and include the optional parallel survey's feasibility minimum (2 calls per facet; 30 seconds shared).

`git diff --check` passed. No remaining issue identified within this reviewed scope; the root agent owns the final combined regression run.
