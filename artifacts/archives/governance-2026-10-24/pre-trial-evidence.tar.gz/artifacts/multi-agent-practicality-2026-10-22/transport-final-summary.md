# Transport、usage 与预算回归交接

本代理最后一轮修改后，共 214 项针对测试通过；未执行付费模型，未创建 Git commit。`git diff --check` 通过。

## 第一组：119 passed in 26.17s

```sh
python3 -m pytest tests/test_subagent_output_transport.py tests/test_subagent_usage_counts.py tests/test_workflow_analysis_budget.py tests/test_workflow_executor_budget.py tests/test_workflow_typed_handoff_budget.py tests/test_workflow_runner_module.py tests/test_workflow_finalization_resilience.py tests/test_workflow_native_handoff_regressions.py tests/test_multi_agent_v2_recovery.py -q --tb=short
```

覆盖 workflow 成功/typed-failure 的 70K、300K 完整正文与 detail；子进程精确文件通道、SHA-256、4001/8000 字符失败正文；文件保存失败显式错误；失败 Analyst、重试、Executor 续修及 Reviewer 修正的真实 usage 累计；typed 父交接保持 8 次父调用、固定总预算及候选保留。

## 第二组：95 passed in 3.96s

```sh
python3 -m pytest tests/test_subagent_subprocess.py tests/test_subagent_context_delivery_regression.py tests/test_subagent_failure_evidence.py tests/test_subagent_soft_landing.py -q --tb=short
```

覆盖普通子进程、上下文送达、失败证据与软收尾兼容。

## 已确认的 HEAD 旧 fixture 漂移

`test_phase_plans_handoff_against_worker_floors_and_admits_both_closing_calls` 在独立解包的干净 HEAD 同样失败：预期 FINALIZE，实际 IMPLEMENT。`ImplementationPhaseController` 默认为 `bounded=False`，该测试却要求有界两轮 closing 调度。修正仅显式传 `bounded=True`，保留原调用数、token 和父 floor 断言。干净 HEAD 解包位置为 `/tmp/minicode-phase-head-vkop08vr`（临时路径，可能被清理）。

```sh
python3 -m pytest tests/test_workflow_analysis_budget.py::test_phase_plans_handoff_against_worker_floors_and_admits_both_closing_calls -q
```

同文件首个测试的真实目标是 Analyst 六次预算不续租；v6 默认路由改变后，将其 prompt 显式设为 `Analyze first`，没有修改生产路由来迎合 fixture。

后续 root/其他代理继续接线和联合回归；以上数字只对应本代理完成时的分组运行，不代表最终全仓测试总数。
