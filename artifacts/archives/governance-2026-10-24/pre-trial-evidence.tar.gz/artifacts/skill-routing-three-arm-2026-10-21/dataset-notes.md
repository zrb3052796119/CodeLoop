# Frozen three-arm Skill discovery dataset

Prepared on 2026-10-21, before any live execution of these cases. This is a local, synthetic diagnosis/explanation benchmark with independently checked JSON answers. It is not a coding-success or real-user workload benchmark.

## Composition and isolation

- 20 cases: R01–R04 routine single capabilities; X01–X04 new capabilities; C01–C04 cross-directory or conditional tasks; N01–N08 negative cases.
- All 20 prompt strings are newly authored. An exact-string comparison against the prior completion and expansion datasets found no reused prompt. This does not make the routine tasks independent of their inherited task concepts.
- The execution module contains a frozen `EXECUTION_CASES` mapping with only `case_id`, `prompt` and `fixture`. `execution_case()` does not open `cases.json` or read its expected labels. The evaluator must verify this mapping against the public fields in `cases.json` before freezing.
- `cases.json` contains expected capability-equivalence groups, permitted auxiliary workflows, forbidden workflows, dependency edges and exact JSON-pointer task checks. Expected labels must be read only by offline validation or scoring after the run.
- A correct final answer without any Skill load still passes task correctness. Positive cases mean that relevant Skills exist; they do not assert that the task is impossible without Skills. Selection, body handoff, ordering, and task correctness are separate measurements.
- The requested final response is one JSON object. No output file, source edit, workflow delegation, remote service, or code change is required. Initial source hashes allow the runner to check that the task stayed read-only.

## Reused and new material

The local shop source and 15 existing Skill capability definitions are reused from `.repair-work/skill-chain-completion-2026-09-08/eval/fixture_builder.py`. An exact copy is frozen beside this bundle as `legacy_fixture_builder.py`; the execution module imports that copy, whose dependencies are standard-library modules only. The previous expansion's four added capabilities are **not** counted as new capabilities in this dataset.

The inherited Skill descriptions and procedures are rendered into a uniform complete body. The old exact report-label requirement is removed, because method-name reproduction is not task evidence and conflicts with the public JSON response contract. The existing procedures still contain workflow guidance, including conditional next-stage discovery.

Routine observations are changed before freezing: HTTP has two retries, a 180 ms per-attempt timeout and backoffs of 40/80 ms; SQL scans 63,000 rows and returns 9; the environment port is 9407. The precomputed HTTP maximum-attempts field is removed. Other inherited observations and source files are disclosed as reused synthetic evidence.

Four new capabilities are supplied only as catalog metadata and Skill bodies:

1. `text/canonical-identifiers`: canonical Unicode normalization under a declared case policy.
2. `storage/conditional-write`: ETag/If-Match stale-write preconditions.
3. `data/spreadsheet-export-safety`: CSV spreadsheet-formula escaping with numeric exceptions.
4. `timezone/repeated-local-hour`: repeated local-time resolution during a daylight-saving overlap.

Their evidence records and two supporting source files are newly created. No production parser, router, semantic alias, tool, or routing rule is added for these capabilities. Newness refers to these fixture capabilities, not an assertion that the model has never encountered the underlying topics.

## Catalog construction

Every case, arm and repetition receives exactly the same 1,000 Skill bodies and directory metadata:

- 15 reused capability entries, including two equivalent queue workflows;
- 4 newly authored capability entries;
- 32 manually differentiated near-neighbor workflows;
- 949 deterministic synthetic operational workflows, formed from 50 named subsystems and 20 operation templates.

The resulting catalog has 66 directories. Directory names and summaries are fixed independently of experiment arm. No case hides, adds, relocates or rewrites a Skill. The sole per-case fixture change is C04's `evidence/ci.json`, which changes the first failed CI stage to `publish`; the catalog is unchanged.

Near neighbors distinguish actual responsibilities: conditional GET versus conditional write; CSV dialect/number formatting versus formula safety; case folding/decoding versus canonical normalization; a spring gap versus a repeated hour; retry instrumentation versus replay safety; SQL plan formatting/index rollout versus diagnosis. Their bodies explain distinct evidence requirements and failure boundaries.

The remaining 949 entries have materially different operation procedures (leases, checkpoints, quotas, rounding, tombstones, reconciliation, etc.), rather than only a one-sentence scope warning. Nevertheless, they remain a repeated subsystem × operation construction with no matching source for most subsystems. This is a harder synthetic catalog than the prior generic filler but **not** 1,000 independently authored, realistic Skills. Report both relevant-scope near-neighbor performance and aggregate performance, and retain this limitation.

## Case contract

- R01–R04 require computation or source/evidence reconciliation for HTTP, SQL, authorization and configuration.
- X01–X04 exercise the four added capabilities using new evidence and exact structured answers.
- C01 requires CI stage evidence before discovering the isolation stage. C02 requires checkout component evidence before provider follow-up. C03 has independent queue/API stages with no imposed order; either queue-equivalent Skill satisfies its capability group. C04 is the paired false-condition case: test isolation is forbidden when publication fails, while `ci/artifact-publish` is permitted as an auxiliary workflow.
- All eight negatives prohibit Skill body loading in the evaluation contract. Discovery metadata is allowed. They cover explicit disablement with otherwise applicable work, quoted Skill names, metadata-only lookup, unrelated arithmetic, a nonexistent exact name with no substitution, a quoted tool command, task cancellation followed by ordinary file reading, and metadata comparison of two equivalent names.
- Task checks compare typed JSON values using RFC 6901 pointers. A boolean must not compare equal to an integer. Formatting or a method keyword alone cannot establish task correctness.
- Prelive independent review clarified three public output formats without changing labels: X04 UTC strings use `YYYY-MM-DDTHH:MM:SSZ`; N07 directory names omit trailing slashes; N03 returns a directory name rather than its filesystem path. These clarifications preceded live execution.
- Required stage evidence paths are read-after-load checks for the handoff measurement, not prerequisites for the independent task-correctness score.

## Local preflight evidence

Two independent fixtures (R01 and C04) were built locally without model calls. Both discovered exactly 1,000 project Skills, contained clean initial Git snapshots, and passed their one-test standard-library smoke suite. Their only tracked-file difference was `evidence/ci.json`.

- Catalog SHA-256 over sorted catalog-path/content-hash pairs: `f8ac65aabe563a677cb392599c0e945801a9c1344b91d3f54e66cb57b1fe1917`.
- Flat name/description estimate: 133,009 characters, before prompt guide overhead. The flat arm must set the supported flat threshold high enough to avoid silent hierarchical fallback, and the runner must record actual prompt mode.
- Local validation report: `/tmp/skill-three-arm-fixture-validation.json` (ephemeral; the experiment owner should save its final freeze manifest separately).

These are construction checks, not evidence of live routing or answer accuracy. No prompts were selected or rewritten based on live outcomes.
