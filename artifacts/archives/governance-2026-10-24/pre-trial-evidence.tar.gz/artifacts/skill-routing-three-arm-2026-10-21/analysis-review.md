# Independent analysis audit

Reviewer: review_tests. Date: 2026-10-21. Scope: read-only review of the new offline
analysis script plus synthetic checks. No live trial records were inspected for
this pre-completion audit, no remote calls were made, and no frozen source,
scorer, tests, cases or protocol files were changed.

## Pre-completion decision

The main statistical design is valid for the declared descriptive synthetic
pilot. This review does not certify live results, effect sizes or resume claims;
those require the completed 180-assignment matrix and independent table checks.

- `_case_means`, `paired` and `bootstrap` first average the three repeats within
  each case, form C-minus-comparator differences for the same cases, and resample
  whole case differences. They do not treat the repeated trials as independent.
  C versus B is primary, C versus A secondary. The positive primary comparison
  uses 12 clusters and negative cleanliness uses eight.
- `collect` builds the full case x arm x repeat matrix, with failure placeholders
  for absent runs. Primary and task successes cannot arise from fake or absent
  records. Outcome denominators stay at 36 positive, 24 negative, and 60 task
  trials per arm. Later task failure and observed positive handoff are reported
  separately by the frozen scorer.
- `request_usage` and `wire_cost` read raw provider response usage rather than
  adapter estimates. Missing or conflicting counters are unknown. Partial known
  sums and complete totals remain separate. Chat and embedding tokens are not
  pooled, and reported cache counters are not added again to input tokens.
- Resource contrasts omit a case pair only when one of its six repeated-arm
  measurements is unknown, and list those exclusions. Known-only tables show
  sample counts. They must not be described as complete all-assigned cost when
  values are missing.
- The common-success resource subset is explicitly supplemental and selected
  after observing outcomes. It does not replace the assigned outcome/resource
  tables and cannot support a causal saving claim.
- The script warns that bootstrap intervals can degenerate when all eight
  negative cases are clean, that cases were deliberately constructed, and that
  24 negative trials are not 24 independent cases. A zero observed exposure count
  is not proof of zero underlying false-trigger risk.

## Independent synthetic checks

An in-memory 20-case x three-arm x three-repeat matrix was passed to the actual
analysis functions. No official partial results were used.

- A constructed C-minus-B positive difference of 2/3 was recovered from exactly
  12 case means; all three repeats remained together.
- Eight all-clean negative cases produced a difference of zero and a degenerate
  [0, 0] bootstrap interval, confirming why the stated caution is necessary.
- All outcome denominators were 36 / 24 / 60 per arm.
- An absent chat wire surface remained unknown; partial provider usage retained
  its observed lower-bound sum and an unknown complete total; missing trial
  embedding use remained unknown; an observed empty embedding request list was
  zero; conflicting provider counter aliases remained unknown.

## Feedback sent before completion

1. Report actual negative body-exposure observations separately from clean-run
   success, with unknown/incomplete observations and eight distinct cases. A
   failed clean check is not automatically a detected body exposure.
2. The selected successful prewarm record contains 167 requests. The initial
   sandbox URLError is a separate preflight record; retain it visibly and do not
   silently infer zero usage or monetary cost. Scope any "all setup requests"
   statement to the records actually included.
3. Surface measurement warnings in the human report, and compare case, protocol,
   harness and source identities to the frozen manifest before claims. Having
   one observed hash is weaker than matching the intended frozen hash.

The analysis author implemented these reporting distinctions before completion.
Independent follow-up inspection verified separate negative exposure/observation/
completion counts, case counts, visible measurement warnings and source-metadata
hashes. External frozen-hash matching remains the independent audit/completion
gate, rather than a claim based only on internal single-hash consistency.

Synthetic setup records with one observed successful attempt and one failed
attempt confirmed that combined full input usage is unknown while the known
input lower bound, both attempts and elapsed time are retained. Duplicate source
paths are rejected. A synthetic phase breakdown confirmed preparation plus Agent
Loop excludes fixture/registry construction. One related plot issue was returned
to the author: the known setup lower bound must remain visible or explicitly
marked unknown when the complete setup token total is unknown; the plot must not
silently omit setup while claiming that it includes it. Final inspection confirmed
the implemented fallback renders the observed setup amount with the label
"Recorded setup / 60 (lower bound)" and describes the unknown total in its
caption. The pre-completion reviewed analysis.py SHA-256 was
`af4b03b0abda26bfcef030ab501cf228b434afc5026ca3bba876e7c346563d41`.
The final reporting version adjusts plot-label placement and discloses the C02
type ambiguity described below; its SHA-256 is
`7372a446e66693739478b1503319ea3b6e903e2edeed6a4a076185cdcc381c1c`.
After that reporting update, the analysis source hash matches metrics.json and
all independent per-trial primary/task comparisons still agree.

## Completion gate and claim boundaries

After dispatch ends, verify all 180 assigned records and failure classifications,
expected input hashes, the full per-arm tables, actual exposure counts and usage
completeness against raw evidence. Recompute the C-versus-B positive effect from
the 12 three-repeat case means independently. Report the separate 8-case negative
results and avoid interpreting a degenerate bootstrap interval as certainty.

Potential later claim wording must name this 1,000-entry synthetic catalog,
20 authored read-only cases and full Agent Loop measurement. No current claim of
model superiority, production safety, general coding success or monetary saving
is established. Setup-amortized and steady-state resource claims must be distinct;
lower resource use may come from omitted Skill discovery or loading.

## Final independent result check

All 180 assigned live trials settled with completed=true; dispatch exited without
recorded errors. The independent provenance audit reports passed, 180 observed
trials, and no issues. The analysis used the reviewed source hash above and
reports one consistent protocol, harness and snapshot identity with no measurement
warnings. No labels, prompts or frozen scoring code were changed after observing
results.

This reviewer independently traversed the frozen schedule, raw run records,
frozen Skill files and successful physical HTTP payloads. Required loaded bodies
were checked against file SHA-256; later successful requests were checked for
the complete body and canonical payload hash. Every positive primary outcome
and all 180 strict task outcomes agree individually with trial-scores.json.
The independent paired differences were then recomputed from the 12 positive
case means, retaining all three repetitions.

| Frozen outcome | A routed | B model flat | C model directories |
|---|---:|---:|---:|
| Strict required retrieval and body handoff | 3/36 (8.3%) | 25/36 (69.4%) | 12/36 (33.3%) |
| Clean negative trials | 24/24 | 24/24 | 24/24 |
| Detected body exposures in negatives | 0/24 | 0/24 | 0/24 |
| Strict final JSON task pass | 43/60 | 38/60 | 43/60 |
| Positive trials with no successful Skill load | 28/36 | 10/36 | 24/36 |

C minus B on the primary positive outcome is -36.11 percentage points, with the
prespecified descriptive paired case-bootstrap interval [-55.56, -16.67] pp.
C minus A is +25.00 pp with interval [-5.56, +50.00] pp. The latter does not
establish a stable improvement over routed. All negative observations are complete,
but the clean results cover eight constructed cases, each repeated three times;
they do not establish a zero real-user false-trigger rate.

### Failure mechanisms

- C: all 24 positive retrieval failures have no successful Skill load and no
  browse_skill_directory or search_skills call. They proceed directly to task
  files. This is omission of Skill discovery/adoption, not a broken body-handoff
  channel. Fourteen of those no-load trials still pass the strict task check,
  consistent with the deliberate separation of task success and Skill adoption.
- B: ten failures have no successful load; C01-B-r3 loads only ci/test-isolation,
  omitting the required ci/pipeline-diagnosis group.
- A: 28 failures have no successful load. R04-A-r1 and R04-A-r2 incorrectly load
  invoice-pdf/reconciliation. The three C02 trials load checkout/latency-diagnosis
  but omit the required provider-protection stage.
- Across all three arms, zero positive failures have a correct complete required
  load set but missing physical body handoff. No ordinary read_file call reads a
  Skill body in these trials. The full negative scorer and provenance audit also
  report no observed negative body exposure.
- Routed's observed intent classifier labels 27/36 positive trials document/create,
  6/36 code/update and 3/36 refactor/update. In the inspected R04 example, the
  final-output JSON clause supplies the document/create evidence. N03-A's metadata
  tools expose a routed five-directory subset that excludes http; all three
  answers then incorrectly conclude the real catalog lacks http/retry-budget.
  These observations limit claims about A to this configured production mechanism
  and these prompts; they are not evidence that every routed design is inferior.

### Task failures: format, fact and an underspecified type

Strict JSON parse failures are A=14, B=22, C=14, totaling 50. Most include
explanatory prose before or after JSON; only one is a single fenced JSON block.
An explicitly exploratory diagnostic finds a JSON object matching every frozen
field check inside 46 of those 50 strings (A=13, B=19, C=14). This diagnostic is
not substituted for the frozen final-output rule and changes no scores. The
remaining four cannot be described as format-only failures based on that check.

Six other failures are syntactically valid JSON:

- A's three N03 repeats incorrectly report exists=false for a Skill present in
  the full catalog. These are fact errors relative to the task, with the filtered
  routed metadata surface visible in the tool evidence.
- C02-C-r1 and C02-C-r3 return provider_followup as an explanatory object/string.
  Frozen expected requires boolean true, but the public C02 prompt only names
  provider_followup and never specifies its type. The responses describe the
  actual provider follow-up; these two failures must be disclosed as a stricter
  hidden type expectation, not evidence of incorrect underlying factual reasoning.
  The pre-freeze schema review missed this ambiguity. Keep the frozen primary
  and task scores unchanged, and clarify this type in any separately versioned
  future benchmark.
- N08-C-r1 returns both correct names in the reverse of the explicitly requested
  lexical order. This is an output-order violation, not a missing-name finding.

Consequently the task column is exact frozen JSON-contract acceptance and must
not be renamed general answer correctness or coding success.

### Resource cross-check and supported resume wording

Independent raw wire aggregation agrees with the analysis:

| Arm | Chat requests | Chat input tokens | Chat output tokens | Trial embedding requests/input |
|---|---:|---:|---:|---:|
| A | 192 | 921,710 | 47,365 | 48 / 2,892 |
| B | 222 | 6,169,909 | 45,753 | 0 / 0 |
| C | 194 | 1,212,352 | 41,949 | 0 / 0 |

All main-trial chat input/output counters are observed. Setup remains separate,
including the retained failed network preflight with unknown usage. Average first
agent-request input is B=25,988.35 and C=5,536.75 tokens across all 60 assignments
per arm, a 78.6953% reduction. This uses physical provider counters and is not
conditioned on a successful outcome. It supports the following bounded wording:

> 实现默认模型驱动的目录发现与按需正文加载；在同一 1,000 条合成 Skill
> 目录的 180 轮三臂对照中，相比平铺目录将平均首轮模型输入 token 降低 78.7%。

The engineering implementation plus first-request context claim is supported.
Retain the synthetic-catalog and experiment scope, and say average input tokens
rather than monetary cost. The full experiment report must also retain the lower
directory-arm retrieval/handoff result. Do not attach claims of improved accuracy,
unchanged recall, better general coding success, zero production false triggers,
or equivalent-quality whole-turn savings. C's lower all-assigned whole-turn input
also accompanies more omitted Skill loads. Even the ten post-outcome common-success
C/B pairs are a selected descriptive subset, not proof of equivalent-quality
general savings.

Durable independent row evidence: artifacts/skill-routing-three-arm-2026-10-21/
independent-score-review.json. Exploratory format diagnostics remain clearly
separate from the frozen primary and task scores.
