这轮结果支持把简历重点放在**默认模型的目录发现机制，以及首轮上下文开销**。当前结果不支持“路由准确率提高”或“保持召回的降本”。

实验在冻结代码、题目、评分器和顺序后完成了 20 题 × 3 组 × 3 次，共 180 次真实完整 Agent Loop。模型为当前配置的 `glm-5.3-flash`；同一套 1,000 个 Skill 分布在 66 个目录。目录中 949 项由子系统与操作模板组合生成，这是合成目录试点，不是 1,000 个经过生产验证的独立技能。

180 次全部正常结束，批次耗时约 26 分 52 秒。独立审计核验了 345 个冻结文件、180 轮正式试验的 656 次 HTTP 请求和正文交接证据，未发现异常；此前源码、测试和用户计划文件的已有修改保持原样。

**三组对照结果**

A 为现有 `routed` 机制，包含规则、可选 embedding 与模型 fallback；B 为默认模型读取全量平铺技能描述；C 为默认模型使用目录发现。B/C 仅改变目录呈现阈值，实际发送的七个工具定义相同。

| 指标 | A：现有 routed | B：model 平铺 | C：model 目录 |
|---|---:|---:|---:|
| 预期 Skill 严格命中并交接 /36 | 3（8.3%） | 25（69.4%） | 12（33.3%） |
| 正例完全未加载 Skill /36 | 28 | 10 | 24 |
| 负例正文误触发 /24 | 0 | 0 | 0 |
| 严格 JSON 验收 /60 | 43 | 38 | 43 |
| 首轮 chat 输入 token 均值 | 4,175.20 | 25,988.35 | 5,536.75 |
| 整轮 chat 输入 token 均值 | 15,361.83 | 102,831.82 | 20,205.87 |
| 整轮 chat 输出 token 均值 | 789.42 | 762.55 | 699.15 |
| 每轮模型调用均值 | 3.20 | 3.70 | 3.23 |
| 每轮 embedding 调用均值 | 0.80 | 0 | 0 |
| 路由准备＋Agent Loop 均值（秒） | 38.55 | 31.17 | 28.19 |

正例是 12 道题各重复 3 次，负例是 8 道题各重复 3 次。命中必须覆盖每个预期能力组、不额外加载无关或禁止技能，并验证完整正文确实出现在后续成功模型请求中。答案正确但没有加载 Skill，不计为技能命中。

目录组相对平铺组，平均首轮输入减少 **78.7%**，整轮 chat 输入减少 **80.4%**。但目录组正例有 **24/36** 次未浏览、搜索或加载 Skill；其 12 次发生 Skill 加载的正例运行均满足严格命中和交接。差异主要出现在是否启动技能发现，未观察到完整正确加载后丢失正文的情况。

因此，首轮输入是目前最适合放进简历的指标：它直接度量目录呈现的上下文大小。整轮输入也下降，但同时伴随更少的 Skill 采用，不能把 80.4% 写成保持检索效果的优化或实际账单节省。与 A 相比，C 的整轮 chat 输入反而高 31.5%。

按题目保留三重复进行配对 bootstrap，C 相对 B 的正例命中交接差为 −36.11 个百分点，描述性 95% 区间为 [−55.56, −16.67]；C 相对 A 为 +25.00 个百分点，区间为 [−5.56, 50.00]。这些区间只描述所构造题目的差异，不代表真实用户任务的泛化性能。

| 正例类别（各 4 题 × 3 次） | A | B | C |
|---|---:|---:|---:|
| 常规能力 | 3/12 | 7/12 | 5/12 |
| 新增 Skill 能力（未改路由代码） | 0/12 | 9/12 | 4/12 |
| 跨目录／条件组合 | 0/12 | 9/12 | 3/12 |
| 组合组同时满足严格阶段顺序 | 0/12 | 7/12 | 1/12 |

**整轮成本的完整口径**

| 各组 60 轮合计 | A | B | C |
|---|---:|---:|---:|
| Chat 输入 token | 921,710 | 6,169,909 | 1,212,352 |
| Chat 输出 token | 47,365 | 45,753 | 41,949 |
| 已包含在输入中的缓存命中 token | 680,768 | 4,586,496 | 918,144 |
| Chat 请求数 | 192 | 222 | 194 |
| Embedding 请求数 | 48 | 0 | 0 |
| Embedding 输入 token | 2,892 | 0 | 0 |

上表为完整索引预热后的每轮实测，656 次请求均有服务端 usage。缓存命中 token 不重复加到输入中。隔离执行另含夹具构建和 registry 初始化，A/B/C 总耗时均值为 40.41/32.97/30.02 秒；上面的任务阶段耗时已剔除这些测试设施开销。

A 使用的完整 1,000 条目录向量索引单列建索引成本：167 次成功请求、44,014 个 embedding 输入 token、125.311 秒。按 60 次 A 分摊，已知输入为每轮 733.57 token。最初还有 1 次沙箱网络失败，没有响应或 usage；该尝试单独保留，不按零费用处理。当前订阅接口没有可核验的逐次账单，**实际货币费用未知**。

**解释结果时必须保留的限制**

题面直接提供证据文件路径，很多任务不使用 Skill 也可以作答。因此这里的目标 Skill 命中率衡量冻结期望是否被采用，不能直接当作事实回答准确率。目录组低采用也意味着，本轮尚不能证明目录发现能稳定触发。

严格 JSON 验收是另一项独立指标。三个组共 50 次因 JSON 外附说明等格式问题被拒绝，其中 46 次能抽取出满足全部字段检查的 JSON；这不代表这 46 次事实回答错误。C02 的公开题面还没有充分说明 `provider_followup` 必须是布尔类型，C 组 2 次因此被拒绝。冻结分数未修改，该标签约束问题已在独立审查中明确披露。不能把 43/60 写成编码成功率或模型推理准确率。

负例各组均未观察到正文误触发，但只有 8 种题型，不能外推为普遍零误触发。以上全部任务为只读诊断／解释，没有测试实际修改代码与交付。

**建议替换的简历条目**

> 为默认模型实现“目录发现 → 候选检索 → 正文加载”的 Skill 调用链；在千级合成技能目录的 180 轮对照中，平均首轮输入较全量平铺减少约 79%。

面试时可补充：目录方案减少了初始上下文，但本轮也发现模型经常直接作答、跳过技能发现。这个限制已经通过逐次工具调用和完整正文交接记录定位，后续应先解决触发与任务设计问题，再验证检索率和多技能顺序。

本条只声明已实现的调用机制与本轮可复核的首轮输入结果，不声明准确率提高、无损召回或实际费用下降。

**复核材料**

- [冻结协议](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/protocol.json>)、[题目与评分约定](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/cases.json>)、[目录构造说明](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/dataset-notes.md>)、[完整调度](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/schedule.json>)。
- [详细分析](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/analysis-report.md>)、[统计附录](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/stats-appendix.md>)、[指标 JSON](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/metrics.json>)、[逐轮评分](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/trial-scores.json>)。
- [图表目录](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/figure-catalog.md>)、[结果图](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/01-outcomes.png>)、[资源图](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis/03-resources.png>)。
- [独立审计](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/audit-report.md>)、[独立评分审查](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/analysis-review.md>)、[原始数据独立复算](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/independent-score-review.json>)、[格式问题诊断](</Users/zhourunbo/code/coding agent/MiniCode-Python-main/artifacts/skill-routing-three-arm-2026-10-21/independent-format-diagnosis.json>)。
- 源码快照 SHA-256：`a6a2c1ed66f1e6cbec1fbf4e28c413ffb955f2334b21339933dd7bc1fa3434e4`。
- 题目 SHA-256：`069fa872b01a501738a95c93c7a6ca06cbf785a99958b076039ad2402654e308`。
