# Independent protocol and scorer review

Reviewer: review_tests. Scope: new experiment artifacts only. No production edits,
no remote calls by this reviewer, and no changes to old experiment evidence.

## Freeze decision

Ready to freeze on 2026-10-21. The scorer and its tests are stable; no unresolved
protocol blocker was found. This is a pre-execution review, not a statement about
live model performance. The dispatcher must run only after freeze.py successfully
seals the source, cases, catalog, cache, harness, protocol and schedule.

Scorer SHA-256: `b04ce5505b3f60ed7c3bbd3fe9ec441a2197b344b3e68fac46333d081552c611`.
Test SHA-256: `8c124a34191dc1e12943ef920c11d571e5639cea7984384d45e987582b612b1e`.

## Accepted design

- Twenty newly authored prompts, three arms, three repetitions: 180 assigned
  trials. The independent task unit is the case, not the repeated trial.
- All arms receive the same 1,000-entry catalog, fixture, seven read-only tools,
  model, context limit, call/output/token limits, and whole-turn deadline. A uses
  routed selection; B changes model's flat-description threshold only; C uses
  the default adaptive model presentation. Hints and prefetch stay disabled.
- Every trial executes the production Agent Loop until final output or its real
  limit. Do not stop at the first non-Skill call or the first successful load.
  Every assigned trial, timeout, budget exhaustion, and infrastructure failure
  remains in the assigned denominator. A recovery is a new recorded call, not a
  replacement for an earlier failed call.
- The task is read-only evidence analysis with a public final JSON schema.
  Expected JSON values remain offline. Task acceptance is independent of Skill
  loading: answering correctly without loading can pass the task check.
- The primary positive measurement requires a member of every required
  capability group, no disallowed extra successful load, matching frozen body
  digests, and a later completed model request containing each required body.
  Loader success alone is insufficient. A later task failure does not erase an
  already observed handoff; task/termination outcomes are reported separately.
- Negative false-trigger observations include successful loads, ordinary
  SKILL.md reads, and complete frozen body matches in recorded tool outputs.
  Metadata browsing and body-free failed loads are not body exposure. An
  incomplete/failed run without observed exposure is not a successful abstention.
- Conditional workflow order is secondary: a dependent Skill must be selected
  after prerequisite evidence has returned in an earlier model exchange.
  Independent stages may run together. Loading and reading in the same batch do
  not prove that the model considered the evidence before deciding to load.

## Baseline and cost controls

Production `skill_semantics.py` limits new cached document vectors to 24 per
route and permits 2,000 cache entries. Fresh cold workspaces would therefore
change both routed recall coverage and cost. Prewarming all unique frozen
catalog document digests is an appropriate steady-state control, provided:

1. Warm-up receives no case prompts, expected names, or expected answers.
2. All 1,000 entries' unique nonempty document texts are covered, not just the
   expected targets. The coverage inventory, model/endpoint identity and cache
   SHA are frozen and verified when copied into every arm's fresh workspace.
3. Document batches and any neutral query calls made while exercising the
   production warm-up path are recorded as setup calls/tokens/time.
4. Main-trial A query embedding is measured normally. B/C should make no
   embedding requests. Warm setup cost is reported separately and amortized
   explicitly; results must not be called cold-start costs.
5. Partial prewarm is a disclosed protocol failure/limitation, not silently
   treated as full warm coverage. No mutable cache is shared between trials.

Raw provider accounting must include every physical chat and embedding attempt,
including retries and failures. Missing usage is unknown, never zero. Adapter
usage and HTTP usage are alternative views of the same request and must not be
added together. Cached tokens must follow the provider's actual inclusion rules.
No monetary claim follows from token counters without matching verified pricing.
Preparation, first request, discovery/handoff and full-turn timing are distinct.

## Pre-freeze issues and resolutions

- Raised: execution_case initially read the complete cases.json before projecting
  three fields. Resolved: an execution-only EXECUTION_CASES constant contains
  case_id/prompt/fixture, and agrees with the offline case manifest. The worker
  does not read expected; freeze.py checks projection equality for all 20 cases.
- Raised: a cold routed arm embeds only a 24-item prefix. Resolution agreed:
  fully warmed frozen catalog cache, with setup accounting as above.
- Verified: index-setup-network/run.json records 1,000/1,000 coverage, 167
  embedding HTTP attempts, 44,014 observed input tokens and 125.311 seconds.
  Every attempt reports usage. Cache bytes independently match SHA-256
  `3a1661fcaf8c1288874015168709f21263e17500cb149e018c93c76add1948b7`.
  The failed sandbox preflight remains separate. Warm-up is setup cost, not
  repeated steady-state trial cost. Provider cache-read counters are absent for
  embeddings and are not inferred to be zero.
- Verified: full-loop fake smoke presents A as routed (9,647 system characters),
  B as flat model (138,643), C as hierarchical (18,854), with three model calls
  and normal completion each. B fits the 200,000-character ceiling. The common
  explicit deny-all case legitimately produces suppressed mode in B.
- Verified: all 20 task labels, JSON values, alternatives and dependencies were
  checked against fixture evidence and Skill bodies. Before live execution,
  prompts clarified UTC Z formatting and directory-name formatting; expected
  facts and catalog contents did not change. Task success remains independent
  of Skill use, including when a correct answer is obtained without a load.
- Verified: offline scorer cross-check of the four retained fake runs reports
  observation_complete=true and no evidence errors. B/C successfully load the
  smoke target customer-support/reconciliation with verified frozen body and
  subsequent completed request handoffs at indices 2 and 3. A denies that
  arbitrary smoke target under routed-selection, demonstrating its denial path
  and full loop; this is not evidence of successful A body handoff. B-N01 denies
  the load with no body false trigger. All four correctly remain live=false and
  primary_success=false. Fake smoke does not establish live HTTP delivery;
  the separate scorer counterexamples check the required wire evidence.
- Verified: the schedule contains 180 unique trial IDs and exactly every
  case x arm x repeat combination. The six ABC permutations each occur in ten
  paired blocks. Each trial creates an independent workspace/cache copy and
  subprocess; source and private-runtime hashes are checked before and after.
  The dispatcher refuses existing trial outputs and records external deadlines
  and worker crashes. freeze.py validates the complete assignment set and all
  source/cache digests before sealing inputs. All assignments remain the
  reporting denominator, including an interrupted or failed worker.

## Scorer test scope

`scoring.py` is a new standard-library-only offline module; it does not import the
runner, model adapter, production routing or case authoring code. Tests use
retained-request-style files and counterexample runs. The final narrow run was
`python3 -m pytest -q .repair-work/skill-routing-three-arm-2026-10-21/test_scoring.py`:
32 passed. Cases cover missing required stages, extra wrong loads, missing or
failed follow-up, tampered requests, wrong frozen body, conditional order,
ordinary/failed-loader body leaks, incomplete negatives, fake runs, JSON types,
duplicate keys and source changes. Five isolated semantic fault probes were
KILLED: admitting an extra wrong load, treating loading as handoff, ignoring body
exposure, counting timed-out negatives as clean, and coupling task correctness
to Skill loading. Each had a green baseline and assertion failures after the
fault; no production or shared working-tree files were changed by the probes.
Probe JSON evidence is under the temporary directory prefix
`/var/folders/f4/9n10ft0d23v18qrjy2_l_wy40000gn/T/three-arm-scorer-probes-4f8_5ixc-`.
This is new-module behavioral evidence, not proof against a historical
production regression or a general mutation score. The parent also reports the
combined harness/scorer suite passing (41 tests).

Retained smoke records, relative to artifacts/skill-routing-three-arm-2026-10-21:
offline-smoke-v2/A-R01/run.json; offline-smoke-v1/B/run.json;
offline-smoke-v1/C/run.json; offline-smoke-v2/B-N01/run.json. The earlier failed
offline-smoke-v1/A is retained and is not one of the successful full-loop checks.

## Scope of claims

The catalog and read-only task fixture are authored benchmark material. The
1,000 entries are not 1,000 production-proven independent capabilities. Repeated
results on 20 prompts support a paired pilot comparison, not a natural-user
success guarantee. Exact final JSON checks measure the frozen requested facts;
they do not establish unrestricted semantic quality or real coding delivery.
