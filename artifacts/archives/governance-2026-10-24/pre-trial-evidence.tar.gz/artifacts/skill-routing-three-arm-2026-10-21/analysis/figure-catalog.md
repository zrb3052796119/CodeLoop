# Figure catalog

All figures use retained real trial values from figure-data.json. SVG is editable; PNG is a 180 dpi preview. Missing measurements remain missing.

- [01-outcomes.svg](01-outcomes.svg) / [01-outcomes.png](01-outcomes.png): Positive strict retrieval/body handoff, negative cleanliness, and independent typed-JSON acceptance. All assigned denominators retained; error bars resample 12, 8 or 20 cases, preserving three repeats. A 100% negative rate with degenerate bootstrap limits does not establish zero underlying false-trigger risk.

- [02-paired-differences.svg](02-paired-differences.svg) / [02-paired-differences.png](02-paired-differences.png): C minus B primary and C minus A secondary contrasts. Percentage-point case-cluster bootstrap intervals are descriptive pilot uncertainty, not generalized effectiveness claims.

- [03-resources.svg](03-resources.svg) / [03-resources.png](03-resources.png): Known per-trial first-chat input, whole-turn chat input, physical requests and total isolated execution seconds (including fixture construction and registry). Labels state observed sample sizes; missing usage is not zero. Task phase decomposition appears separately in the report.

- [04-token-accounting.svg](04-token-accounting.svg) / [04-token-accounting.png](04-token-accounting.png): Chat input, chat output and embedding input are separate provider wire counters. A's embedding panel separately adds setup / 60: labeled as an observed lower bound if any setup request lacks usage. Cached inputs are not added twice.

- [05-case-repeat-matrix.svg](05-case-repeat-matrix.svg) / [05-case-repeat-matrix.png](05-case-repeat-matrix.png): Each cell is success count across three repeats. Positive rows use strict retrieval/handoff; negative rows use clean body exposure. These are different outcomes and are labeled accordingly.
