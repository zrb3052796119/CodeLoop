# Three-arm Skill discovery pilot

Matrix: 180/180 retained assigned records; complete terminal live matrix: True.

The primary outcome is correct required Skill retrieval with no disallowed extra/forbidden loads and independently verified complete-body handoff, measured on 36 positive trials per arm. Negative cleanliness and task acceptance are separate outcomes.

| Arm | Positive retrieval + handoff /36 | Negative clean /24 | Typed JSON task pass /60 |
|---|---:|---:|---:|
| A: Existing routed mechanism | 3/36 (8.3%) | 24/24 (100.0%) | 43/60 (71.7%) |
| B: Model flat | 25/36 (69.4%) | 24/24 (100.0%) | 38/60 (63.3%) |
| C: Model directories | 12/36 (33.3%) | 24/24 (100.0%) | 43/60 (71.7%) |

Negative trials are eight constructed cases repeated three times. Detected body-exposure counts (and distinct cases with any exposure) are:

- A: 0/24 trials; 0/8 cases; 24/24 fully observed, 0 unobserved, 0 unfinished.
- B: 0/24 trials; 0/8 cases; 24/24 fully observed, 0 unobserved, 0 unfinished.
- C: 0/24 trials; 0/8 cases; 24/24 fully observed, 0 unobserved, 0 unfinished.

Zero observed exposure does not establish a zero false-trigger rate beyond these cases. A boundary/degenerate case-bootstrap interval adds no information about unobserved case types.

Primary and secondary paired contrasts (percentage points; case-cluster bootstrap):

| Contrast | Positive primary difference | Descriptive 95% interval | Cases |
|---|---:|---:|---:|
| C-vs-B | -36.11 pp | [-55.56, -16.67] pp | 12 |
| C-vs-A | 25.00 pp | [-5.56, 50.00] pp | 12 |

A is the existing routed mechanism (rules, optional embeddings, and model-facing fallback); its embedding calls are measured rather than assumed. B and C are model modes with flat and directory catalog presentation respectively.

| Positive cohort | A strict retrieval/handoff | B strict retrieval/handoff | C strict retrieval/handoff |
|---|---:|---:|---:|
| routine | 3/12 | 7/12 | 5/12 |
| new-capability | 0/12 | 9/12 | 4/12 |
| composition | 0/12 | 9/12 | 3/12 |

Each positive subtype contains four cases with three repetitions (12 trials per arm).

## Discovery and omission

| Arm | Positive trials with no successful Skill load /36 | Load observation unknown | Task pass without a Skill load /36 | Discovery calls, positive mean |
|---|---:|---:|---:|---:|
| A | 28/36 | 0 | 20/36 | 0.00 |
| B | 10/36 | 0 | 5/36 | 0.00 |
| C | 24/36 | 0 | 14/36 | 0.33 |

Discovery calls are browse_skill_directory and search_skills attempts. Per-trial loaded Skill names, discovery calls and load attempts are retained in trial-scores.json. Lower context or cost can reflect skipping discovery/loading; it is not automatically a successful-retrieval optimization.

## Resource accounting

| Arm | First chat input mean (known/60) | Whole-turn chat input mean (known/60) | Embedding input mean (known/60) | Physical calls mean | Isolated execution seconds mean |
|---|---:|---:|---:|---:|---:|
| A | 4,175.20 (60/60) | 15,361.83 (60/60) | 48.20 (60/60) | 4.00 | 40.41 |
| B | 25,988.35 (60/60) | 102,831.82 (60/60) | 0.00 (60/60) | 3.70 | 32.97 |
| C | 5,536.75 (60/60) | 20,205.87 (60/60) | 0.00 (60/60) | 3.23 | 30.02 |

Isolated execution time includes fixture construction and registry initialization. The following measured phase breakdown separates test infrastructure from routing preparation plus Agent Loop; absent phase measurements remain unknown.

| Arm | Fixture s | Registry s | Preparation s | Agent Loop s | Preparation + Agent Loop s |
|---|---:|---:|---:|---:|---:|
| A | 1.24 (60/60) | 0.62 (60/60) | 15.04 (60/60) | 23.51 (60/60) | 38.55 (60/60) |
| B | 1.22 (60/60) | 0.57 (60/60) | 7.43 (60/60) | 23.74 (60/60) | 31.17 (60/60) |
| C | 1.23 (60/60) | 0.59 (60/60) | 7.15 (60/60) | 21.04 (60/60) | 28.19 (60/60) |

Embedding-index setup: completed=True, coverage=1000; physical requests=168.00, elapsed seconds=126.84.

| Supplied setup record | Completed | Physical calls | Embedding input observed / complete | Requests missing embedding input usage |
|---|---:|---:|---:|---:|
| index-setup-network/run.json | True | 167.00 | 44,014.00 / 44,014.00 | 0 |
| index-setup/run.json | False | 1.00 | 0.00 / unknown | 1 |

Across supplied setup records: recorded embedding input lower bound 44,014.00; complete input total unknown; 1 physical requests lack input usage. Failed network attempts are retained without inferring that a charge occurred.
Declared setup amortization over 60 A trials: 2.80 physical requests and 2.11 seconds per A trial; detailed chat/embedding token amortization is in metrics.json.
Cache-read tokens are reported separately in metrics.json and already belong to provider-reported input tokens. Missing usage is unknown, including failed HTTP attempts; observed sums are lower-bound recorded amounts, not a substitute for complete totals. Cache-field availability is relevant to chat; embedding cache fields are marked inapplicable, not imputed. Monetary cost is unavailable.

### Common-success descriptive supplement

The all-assigned resource table above is the main view. The following subset keeps a case/repeat only when both compared arms achieved positive strict retrieval/handoff. Selection depends on outcomes; these figures cannot establish causal savings or replace the full comparison.

| Contrast | Common-success pairs /36 | First input C / comparator (known pairs) | Whole-turn chat input C / comparator (known pairs) |
|---|---:|---:|---:|
| C-vs-A | 0/36 | unknown / unknown (0) | unknown / unknown (0) |
| C-vs-B | 10/36 | 5,817.90 / 28,541.90 (10) | 41,454.80 / 164,430.90 (10) |

## Failures and measurement limits

- Final interpretation requires matching the retained protocol, harness, case and source digests against the frozen experiment records. Internal single-hash consistency alone does not establish that external match.
- Task-score contract limitation: two C trials fail an insufficiently specified public type contract for C02 `provider_followup`. The original frozen score is retained; typed JSON acceptance is not factual accuracy. See the [independent analysis review](../analysis-review.md).
- A stop reasons: `{"completed": 60}`.
- B stop reasons: `{"completed": 60}`.
- C stop reasons: `{"completed": 60}`.

- This is a 20-case synthetic diagnosis/explanation pilot, not a coding-success or real-user benchmark.
- Cases were deliberately constructed rather than randomly sampled from users. Bootstrap intervals describe variability across these frozen cases and do not establish population generalization.
- The independent resampling unit is case. All three repeats and both contrasted arms stay together; 180 trials are not 180 independent tasks.
- Primary comparison: C minus B on the 12 positive cases (36 trials per arm). C minus A is secondary; other comparisons are descriptive and no confirmatory significance claims are made.
- Eight negative cases produce 24 trials per arm. Zero observed body exposure does not prove a zero underlying false-trigger rate; a degenerate bootstrap interval at 100% does not remove this uncertainty.
- Task acceptance is the frozen typed JSON checks plus successful completion and unchanged source. It is independent of Skill adoption and is not general semantic answer quality.
- Independent post-run review found that two C trials fail an insufficiently specified public type contract for C02 provider_followup. Original frozen scores are retained. Typed JSON acceptance is not factual accuracy; this ambiguity limits task-score interpretation.
- All assigned trials remain in denominators. Missing or unverified Skill evidence cannot become primary successes. Positive retrieval/handoff may succeed even if the later task fails; task completion is reported independently. Missing token accounting remains unknown rather than zero.
- Provider cache counters are reported as subsets or separate accounting fields, never added a second time to prompt/input tokens. No monetary cost is inferred from token counts or subscription pricing.
- The 1000-entry catalog contains reused capabilities, four new capabilities, substantive nearby workflows and repeated synthetic subsystem-operation templates; it is not 1000 independently authored realistic Skills.
- A shared catalog embedding index was built before trials. Its physical calls, tokens and elapsed time are shown separately, plus a declared amortization over the 60 A trials. Steady-state trial comparisons do not hide setup cost.
- Load/body handoff is measured from retained tool results, adapter inputs and serialized HTTP requests. A complete body is stronger evidence than a tool-call name, but fragmented, encoded or unrecorded exposure remains outside scope.
- Lower all-assigned context or cost can arise from skipping Skill discovery/loading. Common-success resource summaries select on the observed outcome and are descriptive only; they cannot establish a causal optimization or replace the all-assigned comparison.

Exact body-exposure observation scope:

Successful SKILL.md file reads and exact complete frozen body matches in recorded tool outputs and model inputs; successful load_skill results. Fragmented, encoded, or unrecorded exposure is outside this measurement. Directory metadata alone is not body exposure.
