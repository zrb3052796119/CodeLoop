# Statistical appendix

## Estimand and resampling

For each case and arm, average the three frozen repetitions. For a C-versus-comparator contrast, subtract the comparator's case mean from C's case mean. Resample these paired case differences with replacement, keeping all three repetitions together, and report the mean difference and 2.5th/97.5th percentile interval. No trial-level independent-binomial interval or unpaired bootstrap is used.

Bootstrap draws: 10000; seed family: 20261021, with deterministic SHA-256 offsets per metric/contrast. Rates have fixed all-assigned denominators. Continuous resource contrasts require all three repeats for both arms to have observed values and explicitly list incomplete-pair exclusions; no token or latency imputation is performed.

There are 12 positive independent task clusters, 8 negative clusters, and only 4 clusters in each positive subtype. These are descriptive pilot intervals, particularly unstable for subtypes and degenerate outcomes. We do not report confirmatory p-values or a significance-based winner. C-versus-B is the primary contrast, C-versus-A secondary; task and resource contrasts are descriptive.

## Contrast inventory

| Contrast | Metric | Estimate C minus comparator | 95% interval | Complete case pairs |
|---|---|---:|---:|---:|
| C-vs-A | chat.input_tokens | 4,844.03 | [-720.93, 10,367.48] | 20 |
| C-vs-A | chat.output_tokens | -90.27 | [-275.69, 69.39] | 20 |
| C-vs-A | composition_strict_chain | 0.08 | [0.00, 0.25] | 4 |
| C-vs-A | embedding.input_tokens | -48.20 | [-66.30, -30.25] | 20 |
| C-vs-A | first_input_tokens | 1,361.55 | [297.13, 2,195.06] | 20 |
| C-vs-A | negative_clean | 0.00 | [0.00, 0.00] | 8 |
| C-vs-A | physical_calls | -0.77 | [-1.50, -0.05] | 20 |
| C-vs-A | positive_primary | 0.25 | [-0.06, 0.50] | 12 |
| C-vs-A | positive_task_pass | -0.06 | [-0.25, 0.14] | 12 |
| C-vs-A | task_pass | -0.00 | [-0.15, 0.17] | 20 |
| C-vs-A | task_phase_seconds | -10.36 | [-15.90, -5.19] | 20 |
| C-vs-A | wall_seconds | -10.40 | [-15.97, -5.17] | 20 |
| C-vs-B | chat.input_tokens | -82,625.95 | [-107,543.24, -57,877.57] | 20 |
| C-vs-B | chat.output_tokens | -63.40 | [-160.10, 53.88] | 20 |
| C-vs-B | composition_strict_chain | -0.50 | [-0.67, -0.33] | 4 |
| C-vs-B | embedding.input_tokens | 0.00 | [0.00, 0.00] | 20 |
| C-vs-B | first_input_tokens | -20,451.60 | [-22,724.00, -17,043.00] | 20 |
| C-vs-B | negative_clean | 0.00 | [0.00, 0.00] | 8 |
| C-vs-B | physical_calls | -0.47 | [-0.82, -0.17] | 20 |
| C-vs-B | positive_primary | -0.36 | [-0.56, -0.17] | 12 |
| C-vs-B | positive_task_pass | 0.17 | [-0.06, 0.36] | 12 |
| C-vs-B | task_pass | 0.08 | [-0.05, 0.22] | 20 |
| C-vs-B | task_phase_seconds | -2.98 | [-5.70, -0.07] | 20 |
| C-vs-B | wall_seconds | -2.95 | [-5.68, 0.05] | 20 |

## Incomplete resource pairs


## Retained data and reproducibility

Cases SHA-256: `069fa872b01a501738a95c93c7a6ca06cbf785a99958b076039ad2402654e308`.
Analysis source SHA-256: `7372a446e66693739478b1503319ea3b6e903e2edeed6a4a076185cdcc381c1c`.
Retained protocol hashes: `["3e53473c9fadc02aa59dbcc94df9202c57f65b8274fe3bb064479320c54d53f5"]`.
Retained harness hashes: `["bd163ac1a749aa98ef6703e349a638aaa906e21048ba5fe62b1f84d67a472c51"]`.
Canonical code-snapshot metadata hashes: `["53eef97d5abbed3b49d672abecad1d56c23df5dbbae2365882d1d3559f81361f"]`.
Analysis revisions: After the first completed real-data analysis, moved plot labels to avoid title/error-bar overlap. Display only; scoring, estimands, bootstrap, frozen inputs and raw trial records were unchanged. Added the independent post-run C02 public-type-contract limitation. Original frozen task scores and every statistical result were retained; this is a measurement caveat, not relabeling.
`trial-scores.json` contains every assigned identity, retained scoring evidence and wire counter completeness. `metrics.json` contains cohort denominators, per-case paired differences, complete and partial accounting, and separate setup amortization. `figure-data.json` is the exact numeric input to the rendered figures.
