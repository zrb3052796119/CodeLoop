# Three-arm experiment audit

Status: **passed**. Assigned 180; observed 180.

Errors: 0; warnings: 0; pending: 0.

Frozen files verified: 345/345. Private runtime/credential file read: **no**.
Verified original fixture files: 197460. Verified physical body handoff links: 204.

Observed token sums below are lower bounds whenever requests or individual token fields are unknown.

| Provider kind | Attempts | Usage object unknown | Input tokens observed | Input fields unknown | Output tokens observed | Output fields unknown | Cache read observed | Cache fields unknown |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| chat | 608 | 0 | 8303971 | 0 | 135067 | 0 | 6185408 | 0 |
| embedding | 48 | 0 | 2892 | 0 | 0 | 0 | 0 | 48 |

Separate index setup: 1000 skill vectors; 167 physical requests; 44014 observed input tokens; 0 requests with unknown usage. Observed setup input tokens amortized over all 60 A assignments: 733.5666666666667.

Separate earlier setup record `index-setup/run.json`: completed=False; 1 attempts; 0 responses; 1 requests with unknown usage. No monetary charge is inferred.

## Findings

No provenance, treatment-fidelity, wire-schema, or body-handoff inconsistency was found.

## Scope limits

- Private runtime contents and secrets were deliberately not read.
- Recorded wire payloads prove supplied request bodies; endpoint execution beyond successful responses is not independently observable.
- Unknown provider usage is preserved and is not reported as zero or converted into monetary charges.
- Audit validates provenance and treatment fidelity, not task correctness or real-world generalization.
