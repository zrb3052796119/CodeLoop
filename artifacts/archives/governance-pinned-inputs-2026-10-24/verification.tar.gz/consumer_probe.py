"""One-off offline calls into existing consumers, without executing a replay."""
import hashlib
import json
from pathlib import Path
import socket
import sys
from types import SimpleNamespace

ROOT=Path('/private/tmp/codeloop-governance-20261024/pinned-inputs-archive/clean-source')
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'scripts'))
socket.socket.connect=lambda *_: (_ for _ in ()).throw(AssertionError('No network permitted'))
from scripts import memory_retrieval_hybrid_evaluator as hybrid
from scripts import analyze_memory_retrieval_quality_v3 as quality
from scripts import audit_multi_agent_gen2 as gen2
from minicode.skill_semantics import EmbeddingSemanticMatcher
import minicode

assert Path(minicode.__file__).resolve().is_relative_to(ROOT)
assert Path(hybrid.__file__).resolve().is_relative_to(ROOT)
config=hybrid.load_frozen_config(ROOT/'artifacts/memory-retrieval-hybrid-config.json')
baseline=hybrid.load_frozen_baseline(ROOT/'artifacts/memory-retrieval-semantic-gap-baseline.json')
report=quality._load_report(ROOT/'artifacts/memory-retrieval-semantic-gap-baseline-v2.json')

directory=ROOT/'artifacts/multi-agent-gen2-2026-10-23/run-v2'
manifest=json.loads((directory/'manifest.json').read_text())
tasks=json.loads((directory/'tasks.json').read_text())
audit=gen2.Audit(directory,allow_partial=True)
audit.archived_hashes(manifest)
audit.provenance(manifest,tasks)
assert not audit.issues, audit.issues

cache=ROOT/'artifacts/skill-selection-model-vs-routed-2026-09-08/live-paired/skill-embeddings.json'
settings=json.loads(cache.with_name('settings.json').read_text())
assert hashlib.sha256(cache.read_bytes()).hexdigest()==settings['embedding_cache_seed_sha256']
cached=json.loads(cache.read_text())
client=SimpleNamespace(_model=cached['model'],_endpoint=cached['endpoint'])
matcher=EmbeddingSemanticMatcher(client,cache,cache_anchor=cache.parent)
vectors=matcher._load_cache()
assert vectors and len(vectors)==len(cached['vectors'])
print(json.dumps({'sourceRoot':str(ROOT),'hybridConfigPayloadValidated':bool(config['payload_sha256']),
    'v1FrozenBaselineLoaded':bool(baseline),'v2DefaultAnalyzerLoaded':bool(report),
    'gen2ExistingArchiveAndProvenanceIssues':audit.issues,'embeddingCachePinnedAndLoadedVectors':len(vectors),
    'networkCalls':0,'historicalReplayExecuted':False},indent=2))
