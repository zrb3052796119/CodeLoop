"""One-off staging of unchanged historical input bytes; not a project tool."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/zhourunbo/.codex/worktrees/governance-pinned-artifacts/MiniCode-Python-main')
OUT = Path('/private/tmp/codeloop-governance-20261024/pinned-inputs-archive')
PAYLOAD = OUT / 'payload'
ARCHIVE = Path('artifacts/archives/governance-pinned-inputs-2026-10-24')
COMMIT = '9f9369421486f018c837f84d21bd727aed6ab326'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*argv):
    return subprocess.check_output(['git', '-C', str(ROOT), *argv])

def put(path, data):
    target = PAYLOAD / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data if isinstance(data, bytes) else data.encode())

def packed(data):
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buffer, compresslevel=9, mtime=0) as stream:
        stream.write(data)
    return buffer.getvalue()

assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
assert not git('status', '--porcelain')
original = json.loads((ROOT / 'artifacts/archives/governance-2026-10-24/manifest.json').read_text())
retained = original['retained_large_json']
assert len(retained) == 8
tracked = [name for name in git('ls-files', '-z').decode().split('\0') if name]
baseline = {name: {'bytes': (ROOT/name).stat().st_size, 'sha256': sha((ROOT/name).read_bytes())}
            for name in tracked}
(OUT/'before-tracked-tree.json').write_text(json.dumps({'commit':COMMIT,'files':baseline}, indent=2)+'\n')
entries = []
for record in retained:
    name = record['path']
    raw = (ROOT / name).read_bytes()
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
    compressed = packed(raw)
    assert compressed == packed(raw) and gzip.decompress(compressed) == raw
    target = ARCHIVE / (record['sha256'] + '.json.gz')
    put(target, compressed)
    entries.append({'original_path':name, 'original_bytes':len(raw), 'original_sha256':sha(raw),
                    'archive_path':target.as_posix(), 'archive_bytes':len(compressed),
                    'archive_sha256':sha(compressed), 'encoding':'gzip',
                    'source_commit':COMMIT, 'source_git_blob':git('rev-parse',f'{COMMIT}:{name}').decode().strip(),
                    'dependency_note':record['dependency_note']})
totals = {'original_bytes':sum(e['original_bytes'] for e in entries),
          'compressed_bytes':sum(e['archive_bytes'] for e in entries)}
totals['payload_bytes_saved'] = totals['original_bytes'] - totals['compressed_bytes']
manifest = {'schema_version':1, 'archived_on':'2026-10-24',
            'scope':'Eight pinned test/evaluation/replay inputs. Restore original paths before consuming; all original bytes and historical pins unchanged.',
            'compression':{'format':'gzip','level':9,'mtime':0,'filename':''},
            'entries':entries,'totals':totals}
put(ARCHIVE/'manifest.json', json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
put(ARCHIVE/'README.md', '''# Archived pinned test and replay inputs

This separate manifest preserves eight complete original JSON inputs. Original
SHA-256 values, accepted failures, source refs and historical evidence manifests
are unchanged. The older four-report archive and its manifest remain unchanged.

Before quality checks, pytest or historical replay, run from the repository root:

```sh
python scripts/restore_archived_artifacts.py --manifest artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json --restore
```

Omit `--restore` to verify without writing. Add `--output-root /tmp/codeloop-input-export`
to restore elsewhere; consumers with fixed repository-relative paths still need
in-place recovery. The existing helper validates packed and original sizes/hashes,
refuses to overwrite differing files, and needs no Git history, network or model.
Recovered originals are ignored local files. No evaluator supports transparent
gzip input: restoration is an explicit prerequisite, also performed by CI.

See [manifest](manifest.json) and [archive documentation](../../../docs/artifact-archive-2026-10-24.md).
This reduces tracked checkout/source-archive content, not Git history. Running the
tests/replays still requires disk space for the original bytes after restoration.
''')

ignore = (ROOT/'.gitignore').read_text()
ignore += '\n# Pinned test/replay inputs: restore exact original bytes before verification.\n'
ignore += '# See artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json.\n'
ignore += ''.join('/'+entry['original_path']+'\n' for entry in entries)
put('.gitignore',ignore)

ci = (ROOT/'.github/workflows/ci.yml').read_text()
needle = '      - name: Run deterministic agent quality gate\n'
assert ci.count(needle) == 1
ci = ci.replace(needle, '      - name: Restore pinned test and replay inputs\n'
    '        run: python scripts/restore_archived_artifacts.py --manifest artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json --restore\n\n'+needle)
put('.github/workflows/ci.yml',ci)

readme = (ROOT/'README.md').read_text()
needle = "python -m pip install -e '.[dev]'\npython -m compileall -q minicode scripts"
assert readme.count(needle) == 1
readme = readme.replace(needle, "python -m pip install -e '.[dev]'\n"
    'python scripts/restore_archived_artifacts.py --manifest artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json --restore\n'
    'python -m compileall -q minicode scripts')
needle = 'Both quality profiles make no remote model calls.'
readme = readme.replace(needle, 'The restore step recovers eight pinned test/replay inputs from committed gzip\n'
    'archives to their original paths and checks their unchanged SHA-256 values. Run\n'
    'it once in every fresh checkout or source export before pytest, quality checks,\n'
    'or historical replay; CI performs the same step. Recovery is offline and refuses\n'
    'to overwrite different local contents. [Archive details and export options](./docs/artifact-archive-2026-10-24.md)\n'
    'cover the separate four-report archive and replay prerequisites.\n\n'+needle)
put('README.md',readme)

doc = (ROOT/'docs/artifact-archive-2026-10-24.md').read_text()
start = doc.index('## Explicit retained exceptions')
end = doc.index('## Validation',start)
table_start = doc.index('| Retained path',start)
table_end = doc.index('\n\nInspection covered',table_start)
table = doc[table_start:table_end].replace('| Retained path |','| Original path (restore before use) |')
section = f'''## Pinned test and replay inputs

The eight inputs previously retained in place have a separate [manifest](../{ARCHIVE.as_posix()}/manifest.json) and complete gzip copies. Their **{totals['original_bytes']:,} original bytes** become **{totals['compressed_bytes']:,} compressed bytes**, saving **{totals['payload_bytes_saved']:,} bytes** before the small manifest/docs. Compression uses level 9, mtime 0 and an empty filename for deterministic bytes. The older archive manifest retains its historical retention decision; this manifest records the subsequent migration.

Before quality checks, pytest, or historical replay, restore the eight originals in each fresh checkout/source export:

```sh
python scripts/restore_archived_artifacts.py --manifest {ARCHIVE.as_posix()}/manifest.json --restore
```

CI performs this step before quality checks and pytest. The existing consumers still read ordinary files at their original paths; they do not read gzip transparently. Recovered originals are ignored, and every historical source/evaluator/input pin remains unchanged. Omit `--restore` for read-only validation; add `--output-root /tmp/codeloop-input-export` for external export. External export alone does not satisfy consumers with fixed repository paths.

{table}

The original semantic/hybrid failures and candidate/accepted distinctions are preserved. Restoration checks compressed and original hashes/sizes, refuses a differing existing file, and needs no Git history, LFS, network or model. Historical replay of the four reports above needs its separate default-manifest restore command as well. Checkout/source archives become smaller; normal test/replay workspaces regain the original disk footprint after recovery, and existing Git history/full-clone cost is unchanged.

'''
doc = doc[:start]+section+doc[end:]
doc = doc.replace('The JSON-report restore helper above applies only to the original four\nreports, not this tar archive:',
                  'The JSON restore helper above handles the four reports and eight pinned inputs\nthrough their separate manifests, not this tar archive:')
put('docs/artifact-archive-2026-10-24.md',doc)
(OUT/'preparation-summary.json').write_text(json.dumps({'commit':COMMIT,'entries':8,'totals':totals,
    'metadataFiles':['.gitignore','.github/workflows/ci.yml','README.md','docs/artifact-archive-2026-10-24.md'],
    'removedIndexPaths':[e['original_path'] for e in entries]},indent=2)+'\n')
print(json.dumps({'payload':str(PAYLOAD),'totals':totals,'entries':8}))
