# Phase 3 pinned-input archive 独立只读审查

结论：未发现需要阻止提交的缺陷。暂存候选完整保留八个输入的原始字节、历史 SHA 和 Git blob 来源，CI 及公开文档明确要求在消费者执行前恢复。未改生产源码、脚本、测试或历史 pin；本次没有运行 pytest，也没有修改候选工作树或 Git 索引。

工作树：`/Users/zhourunbo/.codex/worktrees/governance-pinned-artifacts/MiniCode-Python-main`。基线：`9f9369421486f018c837f84d21bd727aed6ab326`。审查直接读取暂存区中的 manifest/gzip，并验证它们与工作树文件相同；manifest SHA256：`6e6333c7174e3c7ea7413cc6c64f87542c6221d107e16b4524d37d8001e0a167`。审查时有 22 个暂存变更、无未暂存变更。

## 字节与来源

逐项完成：解压归档 → 核对原始长度/SHA256 → 与 manifest 指定的 9f936942 Git blob 做完整字节比较 → 与保留的本地原文件比较。八项全部一致。另核对压缩长度/SHA256、gzip 无 filename/mtime=0，并以 level 9/mtime 0/空文件名重新压缩，压缩字节也完全一致。

| 原始路径 | 原始字节 | 压缩字节 | 与基线及本地原件 |
| --- | ---: | ---: | --- |
| artifacts/memory-retrieval-hybrid-offline.json | 18,058,648 | 565,566 | 一致 |
| artifacts/memory-retrieval-hybrid-config.json | 7,872,717 | 155,270 | 一致 |
| artifacts/multi-agent-gen2-2026-10-23/run-v2/tasks.json | 7,599,345 | 1,565,298 | 一致 |
| artifacts/memory-retrieval-semantic-gap-baseline-v2.json | 3,074,311 | 99,561 | 一致 |
| artifacts/memory-retrieval-semantic-gap-v2-candidate.json | 3,074,017 | 99,418 | 一致 |
| artifacts/memory-retrieval-semantic-gap-baseline.json | 3,033,592 | 96,189 | 一致 |
| artifacts/memory-retrieval-phase2a.json | 2,374,133 | 63,838 | 一致 |
| artifacts/skill-selection-model-vs-routed-2026-09-08/live-paired/skill-embeddings.json | 1,140,270 | 443,202 | 一致 |

合计 46,227,033 → 3,088,342 字节，payload 减少 43,138,691 字节，manifest totals 一致。该变化减少当前 checkout/source export 内容，不减少已有 Git 历史，也不减少恢复后测试工作区的原始输入占用；文档正确披露了这点。

## 恢复、CI 和范围

- 现有恢复脚本以新 manifest 执行只读验证成功：`Verified 8 reports (46,227,033 original bytes).` 脚本本身未改；静态复核确认新清单兼容既有 schema，并使用现有的压缩/原始哈希及长度检查、完整预检和拒绝覆盖逻辑。此轮没有执行写入恢复，避免改变候选工作树。
- `.github/workflows/ci.yml:38` 的离线恢复在质量脚本以及所有 pytest 步骤之前；前面的 compileall/ruff 不消费这些 JSON。命令仅依赖已设置的 Python 标准库，路径用普通 CLI 参数，不依赖 Bash、Git 历史或网络，适用于声明的 Linux/Windows/macOS 与 Python 3.11/3.12 matrix。
- 八个原路径均已从索引移除、原文件仍在本地，`git check-ignore -v` 分别命中新增的根路径精确规则。没有增加通配忽略，也没有误忽略 gzip/manifest。
- 暂存差异仅含 CI、`.gitignore`、README、归档文档、新 manifest/README/8 gzip 和八个原文件删除。`minicode/`、`scripts/`、`tests/` 无变更；历史 evaluator/source/input manifest 等 pin 文件未改。`git diff --cached --check` 通过。

## 公开链接

`docs/artifact-archive-2026-10-24.md:56` 起的八个链接全部指向暂存区真实存在的 gzip，不依赖当前本地仍存在的已退库 JSON。新归档 README 的 manifest 和跨目录文档链接也正确。README 给出的前置恢复命令与 CI 一致。

另外对 Git 跟踪 Markdown 中包含这些输入名称的 9 个文件检查相对链接：未发现仍指向八个退库原路径的 Markdown 链接。纯文本历史路径和 JSON 清单引用保留，以恢复后的原路径继续成立，不应为消除引用而改写 pin。

证据：`/private/tmp/codeloop-governance-20261024/phase3-independent-review/byte-and-static-proof.json` 保存逐文件来源、哈希、ignore 命中、暂存路径清单和链接检查；`public-link-proof.json` 保存额外 Markdown 链接检查。本结论是字节/静态审查，不声称已经执行全量消费者回放或新的 CI matrix。
