# P3 pinned inputs：准备完成，未提交

独立工作树：`/Users/zhourunbo/.codex/worktrees/governance-pinned-artifacts/MiniCode-Python-main`。
基准 commit `9f9369421486f018c837f84d21bd727aed6ab326`；最终暂存树 `724c2ccdbbf5b46b095977a274d78aa99174f1bc`。

22 个暂存路径：4 个现有文件（CI、精确 ignore、README、归档说明），独立归档目录中的 manifest/README/8 gzip，以及8个原件的 index 删除。没有生产、脚本、测试、历史 pin 变更，没有新模块、gate、API 或 commit。原件全部仍在该 worktree 本地，8/8 已忽略；root/P1 工作树未写入。

归档保存原始 46,227,033 bytes，gzip 3,088,342 bytes；含文档/清单等全部变更后跟踪树净减少 43,127,280 bytes（203,566,725 → 160,439,445）。gzip level9/mtime0/空 filename，重复压缩一致，清单同时保存 packed/original SHA、长度和原 Git commit/blob。Git 历史未缩减；恢复后仍需要原始磁盘空间。

真实干净 Git source export 不含 .git 和8个原路径，执行现成 restore 命令恢复8/8并原字节核验，第二次恢复0项。原12,449个跟踪文件中，除4个预期 metadata 外12,445个原文件恢复后全部字节相同，未缺失原逻辑文件。最终暂存树相对已测试导出树只变归档文档的8个下载链接；已独立流式读取最终 Git archive，再验原8文件缺失、gzip8/8及逻辑树字节一致。

验证记录（不拼接为一次全绿）：

- clean export 相关 pytest：**145 passed / 1 failed，222.59s，seed20261024**。唯一失败是 `test_generation_one_still_requires_real_generated_test_receipts` 的 `judge_cleanup_incomplete`；同节点沙箱重现，`ps` 探针被禁止。完全相同代码在允许进程枚举的宿主重跑 **1 passed**。不是归档输入缺失或字节改变；原始负日志保留。
- 既有质量 profile：**current 88/88、a 57/57**，remoteCallCount 均0。
- 实际现成读取函数：hybrid config payload、v1冻结baseline、v2默认analyzer通过；gen2 archive/provenance零issue；缓存 pin 匹配并加载50个向量。未执行历史模型回放。
- public Markdown 链接枚举203份 root README/docs：原来仅归档文档8处指向退库raw，已全部改为跟踪gzip；剩余0处，无其他历史文档修改。检查包含inline/reference形式和relative/external URL。
- `git diff --cached --check` 通过，暂存外无未提交修改。

证据详情与逐日志 SHA：`verification.json`；全树证明：`logical-tree-proof.json`、`final-staged-tree-proof.json`；链接：`public-raw-links-before.json` / `public-raw-links-after.json`。所有材料都在本目录。`review.patch` 仅列可读元数据 diff，完整22路径含数据删除请看 worktree 的 staged diff。

准备完成并不表示最终随机全套通过或可直接合入；由 root 单独提交并决定与 Phase1 的合入/验收顺序。
