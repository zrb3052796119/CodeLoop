"""Regression tests for project Markdown agent profiles (``.mini-code/agents``).

Covers the fail-closed contract of ``minicode.subagent_profiles``: valid
profiles load with a nonempty instruction body, every malformed or
disallowed input is rejected, missing directories yield empty results,
mtime changes invalidate the cache, and built-in agents stay authoritative.
"""

from __future__ import annotations

import os

import pytest

from minicode import subagent_types
from minicode.subagent_profiles import (
    DEFAULT_PROFILE_MAX_TURNS,
    ProjectAgentProfileError,
    clear_profile_cache,
    load_project_agent_profiles,
    load_project_agent_profiles_with_diagnostics,
    merge_agent_types,
    parse_project_agent_profile,
)

VALID_PROFILE = """---
name: doc-reviewer
description: Reviews documentation changes for accuracy.
tools:
  - read_file
  - grep_files
max_turns: 6
---

You review documentation changes. Be concise and cite files.
"""


@pytest.fixture(autouse=True)
def _clean_profile_cache():
    clear_profile_cache()
    yield
    clear_profile_cache()


def _write_profile(root, text, filename="doc-reviewer.md"):
    agents_dir = root / ".mini-code" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    path = agents_dir / filename
    path.write_text(text, encoding="utf-8")
    return path


def _with_frontmatter(**fields):
    lines = ["---"]
    for key, value in fields.items():
        if isinstance(value, (list, tuple, set)):
            lines.append(f"{key}:")
            lines.extend(f"  - {item}" for item in value)
        else:
            lines.append(f"{key}: {value}")
    lines.append("---")
    lines.append("")
    lines.append("Do the reviewed work carefully.")
    return "\n".join(lines) + "\n"


def test_valid_profile_loads(tmp_path):
    _write_profile(tmp_path, VALID_PROFILE)

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert diagnostics == ()
    assert set(profiles) == {"doc-reviewer"}
    entry = profiles["doc-reviewer"]
    assert entry["description"] == "Reviews documentation changes for accuracy."
    assert entry["allowed_tools"] == frozenset({"read_file", "grep_files"})
    assert entry["max_turns"] == 6
    assert entry["system_prompt"].strip() == (
        "You review documentation changes. Be concise and cite files."
    )
    assert entry["project_defined"] is True


def test_missing_directory_yields_empty_profiles(tmp_path):
    assert load_project_agent_profiles(tmp_path) == {}
    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)
    assert profiles == {}
    assert diagnostics == ()


def test_non_markdown_and_hidden_files_are_ignored(tmp_path):
    _write_profile(tmp_path, VALID_PROFILE)
    _write_profile(tmp_path, VALID_PROFILE, filename="notes.txt")
    _write_profile(tmp_path, VALID_PROFILE, filename=".secret.md")

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert set(profiles) == {"doc-reviewer"}
    assert diagnostics == ()


def test_unclosed_frontmatter_is_rejected(tmp_path):
    _write_profile(tmp_path, "---\nname: doc-reviewer\ndescription: x\ntools:\n  - read_file\n")

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "unclosed frontmatter" in diagnostics[0][1]


def test_missing_frontmatter_block_is_rejected(tmp_path):
    _write_profile(tmp_path, "Just some instructions, no frontmatter.\n")

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "must start with a '---' frontmatter block" in diagnostics[0][1]


def test_malformed_frontmatter_line_is_rejected(tmp_path):
    text = "\n".join(
        [
            "---",
            "name doc-reviewer",
            "description: broken",
            "tools:",
            "  - read_file",
            "---",
            "",
            "body",
        ]
    )
    _write_profile(tmp_path, text + "\n")

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "malformed frontmatter line" in diagnostics[0][1]


def test_stray_list_item_is_malformed(tmp_path):
    text = "\n".join(
        [
            "---",
            "- read_file",
            "name: doc-reviewer",
            "description: broken",
            "tools:",
            "  - read_file",
            "---",
            "",
            "body",
        ]
    )
    _write_profile(tmp_path, text + "\n")

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "list item outside" in diagnostics[0][1]


def test_unknown_frontmatter_key_is_rejected(tmp_path):
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer",
            description="ok",
            tools=["read_file"],
            model="haiku",
        ),
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "unknown frontmatter key" in diagnostics[0][1]
    assert "model" in diagnostics[0][1]


def test_missing_required_key_is_rejected(tmp_path):
    for fields in (
        {"description": "ok", "tools": ["read_file"]},
        {"name": "doc-reviewer", "tools": ["read_file"]},
        {"name": "doc-reviewer", "description": "ok"},
    ):
        clear_profile_cache()
        profile_path = _write_profile(tmp_path, _with_frontmatter(**fields))
        profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)
        assert profiles == {}, fields
        assert "must be a nonempty string" in diagnostics[0][1] or (
            "'tools' must be a nonempty list" in diagnostics[0][1]
        ), fields
        profile_path.unlink()


def test_unknown_tool_is_rejected(tmp_path):
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer",
            description="ok",
            tools=["read_file", "teleport_files"],
        ),
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "unknown tool 'teleport_files'" in diagnostics[0][1]


@pytest.mark.parametrize("tool", ["edit_file", "write_file", "run_command", "task"])
def test_write_tools_are_rejected(tmp_path, tool):
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer", description="ok", tools=["read_file", tool]
        ),
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert f"write tool '{tool}'" in diagnostics[0][1]


def test_reserved_built_in_names_are_rejected(tmp_path):
    for reserved in sorted(subagent_types.BUILTIN_AGENT_TYPE_NAMES):
        clear_profile_cache()
        _write_profile(
            tmp_path,
            _with_frontmatter(
                name=reserved, description="ok", tools=["read_file"]
            ),
            filename=f"{reserved}-clone.md",
        )
        profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)
        assert profiles == {}, reserved
        assert "reserved built-in agent name" in diagnostics[0][1], reserved


@pytest.mark.parametrize("bad", ["Bad Name", "9lives", "Upper", "x" * 65])
def test_invalid_names_are_rejected(tmp_path, bad):
    _write_profile(
        tmp_path,
        _with_frontmatter(name=bad, description="ok", tools=["read_file"]),
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "invalid agent name" in diagnostics[0][1]


def test_empty_name_is_rejected(tmp_path):
    _write_profile(
        tmp_path,
        _with_frontmatter(name="", description="ok", tools=["read_file"]),
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "'name' must be a nonempty string" in diagnostics[0][1]


@pytest.mark.parametrize("turns", ["0", "-3", "201", "abc", "true"])
def test_out_of_range_or_non_integer_turn_limits_are_rejected(tmp_path, turns):
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer", description="ok", tools=["read_file"], max_turns=turns
        ),
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}, turns
    assert "'max_turns'" in diagnostics[0][1], turns


def test_missing_max_turns_gets_bounded_default(tmp_path):
    _write_profile(
        tmp_path,
        _with_frontmatter(name="doc-reviewer", description="ok", tools=["read_file"]),
    )

    profiles, _ = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles["doc-reviewer"]["max_turns"] == DEFAULT_PROFILE_MAX_TURNS


def test_empty_instruction_body_is_rejected(tmp_path):
    _write_profile(
        tmp_path,
        "---\nname: doc-reviewer\ndescription: ok\ntools:\n  - read_file\n---\n\n   \n",
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert profiles == {}
    assert "must be nonempty" in diagnostics[0][1]


def test_duplicate_agent_name_keeps_first_definition(tmp_path):
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer", description="first", tools=["read_file"]
        ),
        filename="a-doc-reviewer.md",
    )
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer", description="second", tools=["grep_files"]
        ),
        filename="b-doc-reviewer.md",
    )

    profiles, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert set(profiles) == {"doc-reviewer"}
    assert profiles["doc-reviewer"]["description"] == "first"
    assert "duplicate agent name" in diagnostics[0][1]


def test_valid_name_parses_without_filesystem(tmp_path):
    slug, entry = parse_project_agent_profile(VALID_PROFILE, source="inline.md")
    assert slug == "doc-reviewer"
    assert entry["max_turns"] == 6
    with pytest.raises(ProjectAgentProfileError):
        parse_project_agent_profile("---\nname: explore\n---\nbody\n")


def test_mtime_change_invalidates_cache(tmp_path):
    profile_path = _write_profile(tmp_path, VALID_PROFILE)
    first, _ = load_project_agent_profiles_with_diagnostics(tmp_path)
    # Identical stamp must serve the cache, not a fresh parse.
    second, _ = load_project_agent_profiles_with_diagnostics(tmp_path)
    assert first is second

    updated = VALID_PROFILE.replace("max_turns: 6", "max_turns: 9")
    profile_path.write_text(updated, encoding="utf-8")
    os.utime(profile_path, ns=(2_000_000_000_000_000_000, 2_000_000_000_000_000_000))

    third, diagnostics = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert third is not first
    assert third["doc-reviewer"]["max_turns"] == 9
    assert diagnostics == ()


def test_new_profile_directory_creation_invalidates_missing_dir_cache(tmp_path):
    assert load_project_agent_profiles(tmp_path) == {}
    _write_profile(tmp_path, VALID_PROFILE)

    profiles, _ = load_project_agent_profiles_with_diagnostics(tmp_path)

    assert set(profiles) == {"doc-reviewer"}


def test_merge_keeps_builtin_agents_authoritative(tmp_path):
    _write_profile(
        tmp_path,
        _with_frontmatter(
            name="doc-reviewer", description="ok", tools=["read_file"]
        ),
    )

    merged = merge_agent_types(tmp_path)

    for builtin, entry in subagent_types.AGENT_TYPES.items():
        # Content equality holds and project entries cannot shadow built-ins.
        assert merged[builtin] == entry
    assert merged["doc-reviewer"]["project_defined"] is True
    assert set(subagent_types.AGENT_TYPES) <= set(merged)
