"""Project-defined Markdown agent profiles loaded from ``.mini-code/agents``.

A project may register additional read-only sub-agent types by dropping
Markdown files into ``.mini-code/agents``::

    ---
    name: doc-reviewer
    description: Reviews documentation changes for accuracy.
    tools:
      - read_file
      - grep_files
    max_turns: 6
    ---

    You review documentation. Be concise.

Loading is fail closed: any file with malformed or unclosed frontmatter,
unknown frontmatter keys, unknown or write tools, a reserved or invalid
name, an out-of-range turn limit, or an empty instruction body is rejected
and never registered. Built-in agents remain authoritative; a project
profile can only add new agent types, never override ``AGENT_TYPES``.

Results are cached per project and invalidated whenever the agents
directory or any profile file's mtime changes.
"""

from __future__ import annotations

import os
import re
from typing import Any

from minicode.subagent_types import (
    AGENT_TYPES,
    BUILTIN_AGENT_TYPE_NAMES,
    MAX_TURNS_OVERRIDE_CEILING,
)

__all__ = (
    "ALLOWED_FRONTMATTER_KEYS",
    "ALLOWED_PROFILE_TOOLS",
    "DEFAULT_PROFILE_MAX_TURNS",
    "MAX_PROFILE_TURNS",
    "PROJECT_AGENTS_DIR",
    "ProjectAgentProfileError",
    "clear_profile_cache",
    "load_project_agent_profiles",
    "load_project_agent_profiles_with_diagnostics",
    "merge_agent_types",
    "parse_project_agent_profile",
    "project_agents_dir",
)

# Directory (relative to the project root) holding project agent profiles.
PROJECT_AGENTS_DIR = os.path.join(".mini-code", "agents")

# Exactly these frontmatter keys are understood; anything else fails closed.
ALLOWED_FRONTMATTER_KEYS = frozenset(
    {"name", "description", "tools", "max_turns"}
)

# The only tools a project profile may request: known read-only tools plus
# the note-reading helpers. Every write-capable tool (write_file, edit_file,
# task, run_command, propose_skill, ...) is absent, so requesting one fails
# closed. Mirrors tooling._READ_ONLY_TOOL_NAMES and the read-only subset of
# the built-in explore/plan tool sets.
ALLOWED_PROFILE_TOOLS = frozenset(
    {
        "read_file",
        "list_files",
        "grep_files",
        "file_tree",
        "find_symbols",
        "find_references",
        "get_ast_info",
        "code_review",
        "diff_viewer",
        "web_fetch",
        "web_search",
        "load_skill",
        "browse_skill_directory",
        "search_skills",
        "subagent_note_read",
        "subagent_note_list",
    }
)

# Tool-name fragments that always mark a write-capable tool. Checked before
# the allowlist so the rejection reason names the actual problem.
_WRITE_TOOL_MARKERS = (
    "write",
    "edit",
    "patch",
    "modify",
    "delete",
    "propose",
    "execute",
    "command",
    "task",
    "run",
    "propose_skill",
)

# Project agents get a bounded default turn budget when frontmatter omits
# max_turns; the ceiling matches subagent_types._MAX_TURNS_OVERRIDE_CEILING.
DEFAULT_PROFILE_MAX_TURNS = 10
MAX_PROFILE_TURNS = MAX_TURNS_OVERRIDE_CEILING

# Agent type names are lowercase slugs: a letter first, then letters,
# digits, underscores or hyphens, at most 64 characters total.
_PROFILE_NAME_RE = re.compile(r"[a-z][a-z0-9_-]{0,63}")
_FRONTMATTER_KEY_RE = re.compile(r"[A-Za-z][A-Za-z0-9_-]*")
_INTEGER_RE = re.compile(r"[0-9]+")


class ProjectAgentProfileError(ValueError):
    """A project agent profile was rejected; it is never registered."""


def project_agents_dir(project_root: str | os.PathLike[str]) -> str:
    """Absolute path of ``<project_root>/.mini-code/agents``."""
    return os.path.join(os.fspath(project_root), PROJECT_AGENTS_DIR)


def parse_project_agent_profile(
    markdown: str,
    *,
    source: str = "<profile>",
) -> tuple[str, dict[str, Any]]:
    """Parse and validate one Markdown agent profile.

    Returns ``(agent_type, profile_entry)`` where ``agent_type`` is the
    validated lowercase slug and ``profile_entry`` mirrors the built-in
    ``AGENT_TYPES`` shape. Raises :class:`ProjectAgentProfileError` when any
    rule is violated.
    """
    normalized = markdown.replace("\r\n", "\n")
    lines = normalized.split("\n")
    if not lines or lines[0].strip() != "---":
        raise ProjectAgentProfileError(
            f"{source}: profile must start with a '---' frontmatter block"
        )

    close = None
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            close = index
            break
    if close is None:
        raise ProjectAgentProfileError(f"{source}: unclosed frontmatter block")

    fields = _parse_frontmatter_fields(lines[1:close], source)
    body = "\n".join(lines[close + 1:]).strip()
    if not body:
        raise ProjectAgentProfileError(
            f"{source}: instruction body after frontmatter must be nonempty"
        )

    unknown = sorted(set(fields) - ALLOWED_FRONTMATTER_KEYS)
    if unknown:
        raise ProjectAgentProfileError(
            f"{source}: unknown frontmatter key(s): {', '.join(unknown)}"
        )

    slug = _validated_slug(_require_scalar(fields, "name", source), source)
    if slug in BUILTIN_AGENT_TYPE_NAMES:
        raise ProjectAgentProfileError(
            f"{source}: '{slug}' is a reserved built-in agent name"
        )
    description = _require_scalar(fields, "description", source)
    tools = _validated_tools(fields.get("tools"), source)
    max_turns = _validated_max_turns(fields.get("max_turns"), source)

    display_name = slug.replace("-", " ").replace("_", " ").title()
    entry: dict[str, Any] = {
        "name": display_name,
        "description": description,
        "system_prompt": body,
        "allowed_tools": frozenset(tools),
        "max_turns": max_turns,
        # Marks project-defined entries so dispatch can treat them apart
        # from the calibrated built-ins, which always win.
        "project_defined": True,
    }
    return slug, entry


def load_project_agent_profiles_with_diagnostics(
    project_root: str | os.PathLike[str],
) -> tuple[dict[str, dict[str, Any]], tuple[tuple[str, str], ...]]:
    """Load valid project profiles plus rejection diagnostics.

    The first element maps each validated agent type to its profile entry;
    the second is a tuple of ``(filename, reason)`` pairs for every file
    that failed validation. A missing agents directory yields empty
    results. Results are cached until the directory or a profile file's
    mtime changes.
    """
    agents_dir = project_agents_dir(project_root)
    stamp = _directory_stamp(agents_dir)
    cache_key = os.path.abspath(agents_dir)
    cached = _PROFILE_CACHE.get(cache_key)
    if cached is not None and cached[0] == stamp:
        return cached[1], cached[2]

    profiles, diagnostics = _scan_profiles(agents_dir)
    _PROFILE_CACHE[cache_key] = (stamp, profiles, diagnostics)
    return profiles, diagnostics


def load_project_agent_profiles(
    project_root: str | os.PathLike[str],
) -> dict[str, dict[str, Any]]:
    """Valid project agent profiles keyed by agent type (empty when none)."""
    profiles, _ = load_project_agent_profiles_with_diagnostics(project_root)
    return profiles


def merge_agent_types(
    project_root: str | os.PathLike[str],
) -> dict[str, dict[str, Any]]:
    """Built-in ``AGENT_TYPES`` plus project profiles, built-ins winning.

    Reserved names are already rejected during validation, so the guard
    below is defense in depth: a project profile can never shadow a
    built-in agent type.
    """
    merged: dict[str, dict[str, Any]] = {
        name: dict(entry) for name, entry in AGENT_TYPES.items()
    }
    for name, entry in load_project_agent_profiles(project_root).items():
        if name in merged:
            continue
        merged[name] = entry
    return merged


def clear_profile_cache() -> None:
    """Drop cached project profiles (used by tests and config reloads)."""
    _PROFILE_CACHE.clear()


def _directory_stamp(agents_dir: str) -> tuple[int, tuple[tuple[str, int], ...]] | None:
    """Cache stamp: directory mtime plus every profile file's mtime.

    Returns ``None`` when the directory does not exist, so missing
    directories are cached as empty and a later directory creation (whose
    mtime stamp is a tuple, never ``None``) triggers a rescan.
    """
    try:
        dir_mtime = os.stat(agents_dir).st_mtime_ns
    except OSError:
        return None
    entries: list[tuple[str, int]] = []
    try:
        for name in sorted(os.listdir(agents_dir)):
            if name.startswith(".") or not name.endswith(".md"):
                continue
            path = os.path.join(agents_dir, name)
            try:
                entries.append((name, os.stat(path).st_mtime_ns))
            except OSError:
                entries.append((name, -1))
    except OSError:
        return None
    return (dir_mtime, tuple(entries))


def _scan_profiles(
    agents_dir: str,
) -> tuple[dict[str, dict[str, Any]], tuple[tuple[str, str], ...]]:
    profiles: dict[str, dict[str, Any]] = {}
    diagnostics: list[tuple[str, str]] = []
    try:
        names = sorted(os.listdir(agents_dir))
    except OSError:
        return {}, ()
    for name in names:
        if name.startswith(".") or not name.endswith(".md"):
            continue
        path = os.path.join(agents_dir, name)
        try:
            with open(path, encoding="utf-8") as handle:
                text = handle.read()
        except (OSError, UnicodeDecodeError) as exc:
            diagnostics.append((name, f"unreadable profile: {exc}"))
            continue
        try:
            slug, entry = parse_project_agent_profile(text, source=name)
        except ProjectAgentProfileError as exc:
            diagnostics.append((name, str(exc)))
            continue
        if slug in profiles:
            diagnostics.append(
                (name, f"duplicate agent name '{slug}'; keeping first definition")
            )
            continue
        profiles[slug] = entry
    return profiles, tuple(diagnostics)


def _parse_frontmatter_fields(
    raw_lines: list[str], source: str
) -> dict[str, Any]:
    """Strictly parse frontmatter key/value pairs.

    Supports ``key: value`` scalars, ``key:`` followed by ``- item`` list
    entries, and inline ``[a, b]`` lists. Anything else - a line without a
    colon, a stray list item, an indented nested structure, a duplicated
    key - is malformed and fails closed.
    """
    fields: dict[str, Any] = {}
    current_list_key: str | None = None
    for offset, line in enumerate(raw_lines, start=2):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("- "):
            if current_list_key is None:
                raise ProjectAgentProfileError(
                    f"{source}: malformed frontmatter line {offset}: "
                    "list item outside a 'key:' list"
                )
            fields[current_list_key].append(_unquote(stripped[2:].strip()))
            continue
        if line[:1].isspace():
            raise ProjectAgentProfileError(
                f"{source}: malformed frontmatter line {offset}: "
                "nested/indented values are not supported"
            )
        if ":" not in stripped:
            raise ProjectAgentProfileError(
                f"{source}: malformed frontmatter line {offset}: '{stripped}'"
            )
        key, _, value = stripped.partition(":")
        key = key.strip()
        if not _FRONTMATTER_KEY_RE.fullmatch(key):
            raise ProjectAgentProfileError(
                f"{source}: malformed frontmatter line {offset}: invalid key"
            )
        if key in fields:
            raise ProjectAgentProfileError(
                f"{source}: duplicate frontmatter key '{key}'"
            )
        value = value.strip()
        current_list_key = None
        if not value:
            fields[key] = []
            current_list_key = key
        elif value.startswith("[") and value.endswith("]"):
            fields[key] = [
                _unquote(part.strip())
                for part in value[1:-1].split(",")
                if part.strip()
            ]
        else:
            fields[key] = _unquote(value)
    return fields


def _require_scalar(fields: dict[str, Any], key: str, source: str) -> str:
    value = fields.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ProjectAgentProfileError(
            f"{source}: '{key}' must be a nonempty string"
        )
    return value.strip()


def _validated_slug(name: str, source: str) -> str:
    if not _PROFILE_NAME_RE.fullmatch(name):
        raise ProjectAgentProfileError(
            f"{source}: invalid agent name '{name}': use a lowercase slug of "
            "letters, digits, '_' or '-' starting with a letter (max 64 chars)"
        )
    return name


def _validated_tools(value: Any, source: str) -> list[str]:
    if not isinstance(value, list) or not value:
        raise ProjectAgentProfileError(
            f"{source}: 'tools' must be a nonempty list of tool names"
        )
    tools: list[str] = []
    for raw in value:
        if not isinstance(raw, str) or not raw.strip():
            raise ProjectAgentProfileError(
                f"{source}: 'tools' entries must be nonempty strings"
            )
        tool = raw.strip()
        lowered = tool.lower()
        if any(marker in lowered for marker in _WRITE_TOOL_MARKERS):
            raise ProjectAgentProfileError(
                f"{source}: write tool '{tool}' is not permitted in a "
                "project agent profile"
            )
        if tool not in ALLOWED_PROFILE_TOOLS:
            raise ProjectAgentProfileError(
                f"{source}: unknown tool '{tool}'"
            )
        if tool in tools:
            raise ProjectAgentProfileError(
                f"{source}: duplicate tool '{tool}'"
            )
        tools.append(tool)
    return tools


def _validated_max_turns(value: Any, source: str) -> int:
    if value is None:
        return DEFAULT_PROFILE_MAX_TURNS
    if not isinstance(value, str) or not _INTEGER_RE.fullmatch(value):
        raise ProjectAgentProfileError(
            f"{source}: 'max_turns' must be an integer"
        )
    turns = int(value, 10)
    if not 1 <= turns <= MAX_PROFILE_TURNS:
        raise ProjectAgentProfileError(
            f"{source}: 'max_turns' must be between 1 and {MAX_PROFILE_TURNS}"
        )
    return turns


def _unquote(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


_PROFILE_CACHE: dict[
    str,
    tuple[
        tuple[int, tuple[tuple[str, int], ...]] | None,
        dict[str, dict[str, Any]],
        tuple[tuple[str, str], ...],
    ],
] = {}
