"""Central workflow execution, extracted from the task tool.

This module owns the workflow entry seam: `run_workflow` gates depth, opens
the parent Run's sidecar journal, runs the phase orchestration inside a
disposable workspace transaction, derives the projected result and records
the parent observation — exactly as the task tool always did.

Two dependencies are injected instead of imported back from
`minicode.tools.task` (keeping this module free of reverse imports):

- the phase orchestrator is resolved from ``context._runtime[
  "_workflowPhaseRunner"]`` (the host-capability channel already used for
  the verifier sandbox backend and the human approval provider), and
- the current child runner arrives via the keyword-only ``run_subagent``
  parameter and is handed to every phase execution.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import replace

from minicode.agent_budget import AgentTurnBudget
from minicode.agent_loop import AgentTurnDeadlineExceeded
from minicode.multi_agent_contracts import (
    WorkflowRequest,
    parse_workflow_request,
)
from minicode.subagent_result import (
    extract_subagent_result,
    project_subagent_result,
)
from minicode.subagent_journal import SubagentRunJournal, _open_subagent_journal
from minicode.subagent_observation import _emit_subagent_observation
from minicode.subagent_types import AGENT_TYPES, MAX_AGENT_DEPTH
from minicode.task_deadline import (
    TaskDeadlineExceeded,
    raise_task_deadline,
    task_timeout_seconds,
)
from minicode.tooling import ToolResult
from minicode.turn_cancellation import TurnCancellationRequested
from minicode.workflow_workspace import (
    FrozenWorkflowChange,
    WorkflowIsolationError,
    WorkflowWorkspaceTransaction,
)

WORKFLOW_PHASE_RUNNER_KEY = "_workflowPhaseRunner"

_WORKFLOW_OUTPUT_MAX_CHARS = 8000
_WORKFLOW_RESULT_SUMMARY_MAX_CHARS = 1000
_WORKFLOW_MAX_PHASES = AGENT_TYPES["workflow"]["max_phases"]


def _bounded_workflow_section(label: str, content: str, limit: int) -> tuple[str, bool]:
    text = str(content or "").strip()
    if len(text) <= limit:
        return f"{label}: {text}", False
    return f"{label}: {text[:limit]}…", True


def _workflow_result_counts(results: list[ToolResult]) -> tuple[int, int]:
    model_turns = 0
    tool_calls = 0
    for result in results:
        metadata = getattr(result, "metadata", None)
        if not isinstance(metadata, dict):
            continue
        model_turns += int(metadata.get("model_turns", 0) or 0)
        tool_calls += int(metadata.get("tool_calls", 0) or 0)
    return model_turns, tool_calls


def _workflow_model_turn_limit(agent_budget: object) -> int | None:
    if agent_budget is None:
        return None
    limit = getattr(agent_budget, "max_model_turns", None)
    if isinstance(limit, int) and limit > 0:
        return limit
    return None


def _derive_workflow_result(
    input_data: dict,
    context,
    phase_reports: list[dict],
    model_turns: int,
    tool_calls: int,
    started: float,
) -> ToolResult:
    """Project the phase reports onto the single workflow ToolResult."""
    duration = time.time() - started
    parts: list[str] = []
    failed = [report for report in phase_reports if not report.get("ok")]
    status = "failed" if failed else "completed"
    for report in phase_reports:
        phase_label = str(report.get("phase", "phase"))
        phase_status = "ok" if report.get("ok") else f"failed: {report.get('output', '')[:200]}"
        parts.append(f"{phase_label}: {phase_status}")
    summary = "; ".join(parts)[:_WORKFLOW_RESULT_SUMMARY_MAX_CHARS]
    verification_result = None
    for report in reversed(phase_reports):
        candidate = report.get("verification_result")
        if candidate is not None:
            verification_result = candidate
            break
    checks = [
        (
            f"{str(check.get('name', 'check'))}: "
            f"{str(check.get('status', 'inconclusive'))} "
            f"[{str(check.get('artifactRef', 'evidence unavailable'))}]"
        )
        for check in verification_result.get("checks", [])[:20]
        if isinstance(check, dict)
    ] if isinstance(verification_result, dict) else []
    review = None
    for report in reversed(phase_reports):
        candidate = report.get("review")
        if candidate is not None:
            review = candidate
            break
    has_scheduler_artifacts = any(
        report.get("scheduler_trace") is not None for report in phase_reports
    )
    execution_artifact = None
    for report in reversed(phase_reports):
        candidate = report.get("execution_artifact")
        if candidate is not None:
            execution_artifact = candidate
            break
    notes = (
        [
            f"{str(check.get('status', 'inconclusive'))} check pending evidence: "
            f"{str(check.get('artifactRef', 'unavailable'))}"
            for check in verification_result.get("checks", [])[:20]
            if isinstance(check, dict)
        ]
        if isinstance(verification_result, dict)
        else []
        if has_scheduler_artifacts and execution_artifact is None
        else [f"workflow review verdict: {review.get('verdict', 'unknown')}" for review in [review] if review]
    )
    output = "\n".join(
        [
            f"workflow {status} in {duration:.1f}s "
            f"(model turns: {model_turns}, tool calls: {tool_calls})",
            summary,
            *checks,
            *notes,
        ]
    )[:_WORKFLOW_OUTPUT_MAX_CHARS]
    return ToolResult(
        ok=not failed,
        output=output,
    )


def _emit_workflow_observation(
    context,
    *,
    subagent_id: str,
    result_contract_status: str,
    journal: SubagentRunJournal | None,
    outcome: str,
    results: list[ToolResult],
    phase_count: int,
    started: float,
    model_turn_limit: int | None = None,
    transaction_error: str | None = None,
    **_extra_fields,
) -> None:
    """Record the single parent-Run observation for this workflow run."""
    model_turns, tool_calls = _workflow_result_counts(results)
    payload = {
        "subagent_id": subagent_id,
        "agent_type": "workflow",
        "outcome": outcome,
        "result_contract_status": result_contract_status,
        "model_turns": model_turns,
        "tool_calls": tool_calls,
        "phase_count": phase_count,
        "duration_seconds": round(time.time() - started, 3),
    }
    if model_turn_limit is not None:
        payload["model_turn_limit"] = model_turn_limit
    if transaction_error:
        payload["transaction_error"] = transaction_error[:200]
    _emit_subagent_observation(context, **payload)


class _WorkflowCommitStateUnknown(BaseException):
    """Promotion was interrupted and the parent is neither base nor target."""


def run_workflow(
    input_data: dict,
    context,
    *,
    depth: int,
    subagent_id: str,
    run_subagent,
) -> ToolResult:
    """Run a workflow against a disposable workspace transaction.

    ``run_subagent`` is the current child runner (the task tool's ``_run``),
    injected at dispatch so phases never reach back into the task module. The
    phase orchestrator itself is a host capability registered under
    ``context._runtime[WORKFLOW_PHASE_RUNNER_KEY]``.
    """
    agent_budget = getattr(context, "_agent_budget", None)
    if agent_budget is None:
        runtime = getattr(context, "_runtime", None)
        agent_budget = AgentTurnBudget.from_runtime(
            runtime if isinstance(runtime, dict) else {}
        )
    if agent_budget is not None:
        try:
            context = replace(context, _agent_budget=agent_budget)
        except TypeError:
            pass
    runtime = getattr(context, "_runtime", None)
    phase_runner = (
        runtime.get(WORKFLOW_PHASE_RUNNER_KEY)
        if isinstance(runtime, dict)
        else None
    )
    if not callable(phase_runner):
        return ToolResult(
            ok=False,
            output=(
                "error[workflow_runner_unavailable]: no workflow phase runner "
                "is registered on this context"
            ),
        )
    started = time.time()
    journal = _open_subagent_journal(context)
    model_turn_limit = _workflow_model_turn_limit(agent_budget)

    if depth >= MAX_AGENT_DEPTH:
        _emit_workflow_observation(
            context,
            subagent_id=subagent_id,
            result_contract_status="unavailable",
            journal=journal,
            outcome="depth_rejected",
            results=[],
            phase_count=0,
            started=started,
            model_turn_limit=model_turn_limit,
        )
        return ToolResult(
            ok=False,
            output=(
                f"error[max_depth]: task tool cannot spawn sub-agents beyond "
                f"depth {MAX_AGENT_DEPTH}"
            ),
        )

    timeout_seconds = float(
        getattr(context, "_task_timeout_seconds", None)
        or task_timeout_seconds(context)
    )
    deadline_monotonic = getattr(context, "_task_deadline_monotonic", None)
    try:
        with WorkflowWorkspaceTransaction(
            context.cwd,
            deadline_monotonic=(
                float(deadline_monotonic)
                if isinstance(deadline_monotonic, (int, float))
                else None
            ),
            timeout_seconds=timeout_seconds,
        ) as transaction:
            try:
                context = replace(
                    context,
                    _task_timeout_seconds=timeout_seconds,
                )
            except TypeError:
                pass
            workflow_result = phase_runner(
                input_data,
                context,
                depth,
                subagent_id=subagent_id,
                workflow_journal=journal,
                transaction=transaction,
                run_subagent=run_subagent,
            )
    except (WorkflowIsolationError, FrozenWorkflowChange) as exc:
        _emit_workflow_observation(
            context,
            subagent_id=subagent_id,
            result_contract_status="unavailable",
            journal=journal,
            outcome="failed",
            results=[],
            phase_count=0,
            started=started,
            model_turn_limit=model_turn_limit,
            transaction_error=str(exc),
        )
        return ToolResult(
            ok=False,
            output=f"error[workflow_isolation]: {exc}",
        )

    phase_reports: list[dict] = []
    metadata = getattr(workflow_result, "metadata", None)
    if isinstance(metadata, dict):
        reports = metadata.get("phase_reports")
        if isinstance(reports, list):
            phase_reports = [report for report in reports if isinstance(report, dict)]
    model_turns, tool_calls = _workflow_result_counts(
        [workflow_result]
        if isinstance(workflow_result, ToolResult)
        else []
    )
    derived = _derive_workflow_result(
        input_data,
        context,
        phase_reports,
        model_turns,
        tool_calls,
        started,
    )
    if transaction is not None:
        try:
            transaction.commit()
        except _WorkflowCommitStateUnknown:
            raise
        except Exception as exc:  # noqa: BLE001 - commit failure fails the run
            _emit_workflow_observation(
                context,
                subagent_id=subagent_id,
                result_contract_status="promoted",
                journal=journal,
                outcome="failed",
                results=[derived],
                phase_count=len(phase_reports),
                started=started,
                model_turn_limit=model_turn_limit,
                transaction_error=str(exc),
            )
            return ToolResult(
                ok=False,
                output=f"error[workflow_commit]: {exc} (outcome: commit_failed)",
            )
    _emit_workflow_observation(
        context,
        subagent_id=subagent_id,
        result_contract_status="promoted",
        journal=journal,
        outcome="completed" if derived.ok else "failed",
        results=[derived],
        phase_count=len(phase_reports),
        started=started,
        model_turn_limit=model_turn_limit,
    )
    return derived


__all__ = [
    "WORKFLOW_PHASE_RUNNER_KEY",
    "run_workflow",
]
