"""Regression tests: central workflow execution extracted into workflow_runner.

Architectural regressions pin the seam contract (one public ``run_workflow``
entry taking ``input_data``/``context`` plus keyword-only
``depth``/``subagent_id``/``run_subagent``; no reverse import from
``workflow_runner`` into ``minicode.tools.task``). Behavioral regressions
exercise depth rejection and child-runner injection through the seam.
"""

from __future__ import annotations

import ast
import inspect
from pathlib import Path

import pytest

from minicode.subagent_types import MAX_AGENT_DEPTH
from minicode.tooling import ToolResult
from minicode.workflow_runner import WORKFLOW_PHASE_RUNNER_KEY, run_workflow

MINICODE_ROOT = Path(__file__).resolve().parent.parent / "minicode"
TASK_SOURCE = (MINICODE_ROOT / "tools" / "task.py").read_text(encoding="utf-8")
WORKFLOW_RUNNER_SOURCE = (MINICODE_ROOT / "workflow_runner.py").read_text(
    encoding="utf-8"
)


class _StubContext:
    """Minimal context: neutral modules treat missing attributes as absent."""

    def __init__(self, runtime: dict | None = None) -> None:
        self._runtime = runtime if runtime is not None else {}


def test_workflow_runner_has_no_reverse_import_into_tools_task() -> None:
    """Architecture: workflow_runner must not import the task tool back."""
    tree = ast.parse(WORKFLOW_RUNNER_SOURCE)
    banned_prefixes = ("minicode.tools", "tools.task", "tools")
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                assert not alias.name.startswith(banned_prefixes), alias.name
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            assert not module.startswith(banned_prefixes), module


def test_run_workflow_is_the_single_public_seam() -> None:
    """The seam takes input_data/context plus keyword-only depth/subagent_id/run_subagent."""
    from minicode import workflow_runner

    public = [
        name
        for name in vars(workflow_runner)
        if not name.startswith("_") and name != "annotations"
    ]
    assert "run_workflow" in public

    signature = inspect.signature(run_workflow)
    params = list(signature.parameters.values())
    assert [p.name for p in params[:2]] == ["input_data", "context"]
    assert all(
        p.kind is inspect.Parameter.POSITIONAL_OR_KEYWORD for p in params[:2]
    )
    keyword_only = params[2:]
    assert [p.name for p in keyword_only] == [
        "depth",
        "subagent_id",
        "run_subagent",
    ]
    assert all(
        p.kind is inspect.Parameter.KEYWORD_ONLY for p in keyword_only
    )


def test_task_tool_dispatches_through_seam_and_injects_child_runner() -> None:
    """The task tool calls the seam and injects the current child runner."""
    from minicode.tools import task
    from minicode import workflow_runner

    assert task.run_workflow is workflow_runner.run_workflow
    assert "run_subagent=_run" in TASK_SOURCE
    # The phase orchestrator is injected as a host capability, not imported.
    assert WORKFLOW_PHASE_RUNNER_KEY in WORKFLOW_RUNNER_SOURCE
    assert WORKFLOW_PHASE_RUNNER_KEY in TASK_SOURCE
    # No other internal call path bypasses the seam.
    assert TASK_SOURCE.count("return _run_workflow(") == 0


def test_seam_rejects_depth_before_any_child_is_spawned() -> None:
    """Depth gate: no phase runner or child runner is touched at max depth."""
    phase_calls: list[object] = []
    child_calls: list[object] = []

    def phase_runner(*args, **kwargs):  # pragma: no cover - must not run
        phase_calls.append((args, kwargs))
        raise AssertionError("phase runner must not run at max depth")

    result = run_workflow(
        {"prompt": "x"},
        _StubContext(runtime={WORKFLOW_PHASE_RUNNER_KEY: phase_runner}),
        depth=MAX_AGENT_DEPTH,
        subagent_id="sub_test",
        run_subagent=lambda *a, **k: child_calls.append((a, k)),
    )

    assert isinstance(result, ToolResult)
    assert result.ok is False
    assert "error[max_depth]" in result.output
    assert phase_calls == []
    assert child_calls == []


def test_seam_requires_phase_runner_capability() -> None:
    """Without the injected phase orchestrator the seam fails closed."""
    result = run_workflow(
        {"prompt": "x"},
        _StubContext(runtime={}),
        depth=0,
        subagent_id="sub_test",
        run_subagent=lambda *a, **k: pytest.fail("child runner must not run"),
    )
    assert result.ok is False
    assert "workflow_runner_unavailable" in result.output


def test_seam_hands_child_runner_and_journal_to_phase_runner(
    monkeypatch: pytest.MonkeyPatch, tmp_path
) -> None:
    """The injected child runner is forwarded verbatim to the phase runner."""
    from minicode import workflow_runner

    class _FakeTransaction:
        def __init__(self, *args, **kwargs) -> None:
            self.init_args = (args, kwargs)

        def __enter__(self):
            return self

        def __exit__(self, *exc_info) -> bool:
            return False

    monkeypatch.setattr(
        workflow_runner, "WorkflowWorkspaceTransaction", _FakeTransaction
    )
    seen: dict[str, object] = {}

    def phase_runner(input_data, context, depth, **kwargs):
        seen["depth"] = depth
        seen["kwargs"] = kwargs
        return ToolResult(ok=True, output="workflow finished", metadata={})

    context = _StubContext(runtime={WORKFLOW_PHASE_RUNNER_KEY: phase_runner})
    context.cwd = str(tmp_path)

    def child_runner(*_args, **_kwargs):
        raise AssertionError("no child should spawn in this stub")

    result = run_workflow(
        {"prompt": "x"},
        context,
        depth=1,
        subagent_id="sub_abc",
        run_subagent=child_runner,
    )

    assert result.ok is True
    assert seen["depth"] == 1
    assert seen["kwargs"]["subagent_id"] == "sub_abc"
    assert seen["kwargs"]["run_subagent"] is child_runner
    assert "workflow_journal" in seen["kwargs"]
    assert "transaction" in seen["kwargs"]


def test_neutral_shared_modules_are_importable_without_tools_task() -> None:
    """The shared plumbing moved to neutral modules stays import-compatible."""
    from minicode.subagent_journal import _open_subagent_journal
    from minicode.subagent_observation import _emit_subagent_observation
    from minicode.subagent_types import AGENT_TYPES
    from minicode.task_deadline import (
        raise_task_deadline,
        task_timeout_seconds,
    )

    assert AGENT_TYPES["workflow"]["max_phases"] >= 1
    assert task_timeout_seconds(None) > 0
    assert raise_task_deadline(_StubContext()) is None
    assert _open_subagent_journal(_StubContext()) is None
    # The task tool keeps exposing the moved names for compatibility.
    from minicode.tools import task

    assert task.AGENT_TYPES is AGENT_TYPES
    assert task.MAX_AGENT_DEPTH == MAX_AGENT_DEPTH
    assert callable(task._task_timeout_seconds)
    assert callable(task._raise_task_deadline)
    assert callable(task._open_subagent_journal)
    assert callable(task._emit_subagent_observation)
