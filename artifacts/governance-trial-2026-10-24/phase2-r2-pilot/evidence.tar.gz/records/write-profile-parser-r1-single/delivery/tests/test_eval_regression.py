"""Regression tests for project Markdown agent profile loading.

Covers the fail-closed contract of ``minicode.subagent_profiles``: malformed
or unclosed frontmatter, unknown keys/tools, write tools, reserved or invalid
names, out-of-range turn limits, empty bodies, missing directories, and
mtime-based cache invalidation.
"""

from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import pytest

from minicode import subagent_profiles
from minicode.subagent_profiles import (
    ProjectAgentProfile,
    SubagentProfileError,
    load_project_agent_catalog,
    load_project_agent_profiles,
    parse_agent_profile,
    reset_profile_cache,
)
from minicode.subagent_types import AGENT_TYPES, PROJECT_AGENT_ALLOWED_TOOLS

VALID_PROFILE = """---
name: api-explorer
description: Maps REST endpoints across the service tree.
tools:
  - grep_files
  - read_file
max_turns: 10
---
Search the repository for route registrations and summarize each endpoint.
"""


@pytest.fixture(autouse=True)
def _fresh_cache():
    reset_profile_cache()
    yield
    reset_profile_cache()


def _write_profile(root, content=VALID_PROFILE, filename="api-explorer.md"):
    agents_dir = root / ".mini-code" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    path = agents_dir / filename
    path.write_text(content, encoding="utf-8")
    return path


class TestValidProfiles:
    def test_valid_profile_parses(self):
        profile = parse_agent_profile(VALID_PROFILE, source="api-explorer.md")
        assert isinstance(profile, ProjectAgentProfile)
        assert profile.name == "api-explorer"
        assert profile.description == "Maps REST endpoints across the service tree."
        assert profile.tools == ("grep_files", "read_file")
        assert profile.max_turns == 10
        assert profile.instructions.startswith("Search the repository")

    def test_load_from_project_directory(self, tmp_path):
        _write_profile(tmp_path)
        profiles = load_project_agent_profiles(tmp_path)
        assert set(profiles) == {"api-explorer"}
        agent_def = profiles["api-explorer"].as_agent_def()
        assert agent_def["system_prompt"].startswith("Search the repository")
        assert set(agent_def["allowed_tools"]) == {"grep_files", "read_file"}

    def test_invalid_files_are_skipped_but_reported(self, tmp_path):
        _write_profile(tmp_path)
        _write_profile(tmp_path, content="no frontmatter here\n", filename="bad.md")
        catalog = load_project_agent_catalog(tmp_path)
        assert set(catalog.profiles) == {"api-explorer"}
        assert len(catalog.errors) == 1
        assert catalog.errors[0][0].endswith("bad.md")

    def test_tools_default_to_readonly_allowlist(self):
        profile = parse_agent_profile(
            "---\nname: lean\ndescription: d\n---\nbody text\n",
        )
        assert set(profile.tools) == set(PROJECT_AGENT_ALLOWED_TOOLS)
        assert profile.max_turns == AGENT_TYPES["explore"]["max_turns"]


class TestMissingDirectory:
    def test_missing_agents_dir_is_empty(self, tmp_path):
        catalog = load_project_agent_catalog(tmp_path / "nowhere")
        assert catalog.profiles == {}
        assert catalog.errors == ()

    def test_empty_agents_dir_is_empty(self, tmp_path):
        (tmp_path / ".mini-code" / "agents").mkdir(parents=True)
        assert load_project_agent_profiles(tmp_path) == {}


class TestFailClosed:
    @pytest.mark.parametrize(
        ("markdown", "reason"),
        [
            ("no frontmatter here\n", "missing"),
            ("---\nname: x\n", "unclosed"),
            ("---\nname: x\nnot a key line\n---\nbody\n", "malformed line"),
            ("---\nboom: 1\nname: x\n---\nbody\n", "unknown key"),
            ("---\nname: Explore\n---\nbody\n", "reserved name"),
            ("---\nname: Workflow\n---\nbody\n", "reserved name"),
            ("---\nname: Bad Name!\n---\nbody\n", "invalid name"),
            ("---\nname: 1starts-wrong\n---\nbody\n", "invalid name"),
            ("---\nname: ok\n---\n   \n", "empty body"),
            ("---\nname: ok\nmax_turns: 0\n---\nbody\n", "low max_turns"),
            ("---\nname: ok\nmax_turns: 201\n---\nbody\n", "high max_turns"),
            ("---\nname: ok\nmax_turns: many\n---\nbody\n", "non-integer max_turns"),
            ("---\nname: ok\ntools: [read_file, write_file]\n---\nbody\n", "write tool"),
            ("---\nname: ok\ntools: [edit_file]\n---\nbody\n", "write tool"),
            ("---\nname: ok\ntools: [run_command]\n---\nbody\n", "write tool"),
            ("---\nname: ok\ntools: [time_travel]\n---\nbody\n", "unknown tool"),
        ],
    )
    def test_parse_rejects(self, markdown, reason):
        with pytest.raises(SubagentProfileError):
            parse_agent_profile(markdown, source="case.md")

    def test_first_closing_delimiter_ends_frontmatter(self):
        profile = parse_agent_profile("---\nname: ok\n---\nbody\n---\nsecond\n")
        assert profile.instructions == "body\n---\nsecond"

    def test_max_turns_ceiling_matches_shared_constant(self):
        from minicode.subagent_types import MAX_TURNS_CEILING

        assert MAX_TURNS_CEILING == 200
        boundary = (
            f"---\nname: ok\nmax_turns: {MAX_TURNS_CEILING}\n---\nbody\n"
        )
        assert parse_agent_profile(boundary).max_turns == MAX_TURNS_CEILING


class TestCacheInvalidation:
    def test_catalog_cached_until_mtime_changes(self, tmp_path):
        path = _write_profile(tmp_path)
        first = load_project_agent_profiles(tmp_path)
        assert first["api-explorer"].max_turns == 10

        # Same content but a newer mtime must invalidate the cache.
        path.write_text(
            VALID_PROFILE.replace("max_turns: 10", "max_turns: 20"), encoding="utf-8"
        )
        os.utime(path, ns=(0, 1_000_000_000_000))

        second = load_project_agent_profiles(tmp_path)
        assert second["api-explorer"].max_turns == 20

    def test_added_and_removed_files_invalidate(self, tmp_path):
        path = _write_profile(tmp_path)
        assert set(load_project_agent_profiles(tmp_path)) == {"api-explorer"}

        path.unlink()
        os.utime(tmp_path / ".mini-code" / "agents", ns=(0, 2_000_000_000_000))
        assert load_project_agent_profiles(tmp_path) == {}

        _write_profile(
            tmp_path,
            content=VALID_PROFILE.replace("name: api-explorer", "name: second-explorer"),
            filename="second-explorer.md",
        )
        os.utime(tmp_path / ".mini-code" / "agents", ns=(0, 3_000_000_000_000))
        assert set(load_project_agent_profiles(tmp_path)) == {"second-explorer"}


class TestBuiltinsAuthoritative:
    def test_reserved_names_never_shadow_builtins(self, tmp_path):
        for builtin in AGENT_TYPES:
            _write_profile(
                tmp_path,
                content=f"---\nname: {builtin}\ndescription: shadow\n---\nbody\n",
                filename=f"shadow-{builtin}.md",
            )
        catalog = load_project_agent_catalog(tmp_path)
        assert catalog.profiles == {}
        assert len(catalog.errors) == len(AGENT_TYPES)

    def test_every_builtin_is_reserved(self):
        from minicode.subagent_types import RESERVED_AGENT_NAMES

        assert RESERVED_AGENT_NAMES == frozenset(AGENT_TYPES)
