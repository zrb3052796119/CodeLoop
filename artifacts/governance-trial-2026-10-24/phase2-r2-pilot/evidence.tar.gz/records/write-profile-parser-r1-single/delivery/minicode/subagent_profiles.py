"""Project Markdown sub-agent profiles loaded from ``.mini-code/agents``.

A project can add read-only sub-agents by dropping Markdown files into
``<project>/.mini-code/agents/*.md``. Each file is a YAML frontmatter block
followed by a nonempty instruction body::

    ---
    name: api-explorer
    description: Maps REST endpoints across the service tree.
    tools:
      - grep_files
      - read_file
    max_turns: 10
    ---
    Search the repository for route registrations and summarize ...

Everything fails closed: a file with malformed or unclosed frontmatter, an
unknown key, an unknown or write-capable tool, a reserved or invalid name, an
out-of-range ``max_turns``, or an empty body is rejected with a
:class:`SubagentProfileError` and never registered. Built-in agent types
(:data:`minicode.subagent_types.AGENT_TYPES`) always stay authoritative —
their names are reserved and cannot be shadowed.

Catalogs are cached per agents directory and invalidated when the directory's
mtime changes; a missing directory yields an empty catalog rather than an
error.
"""

from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass
from typing import Any, Mapping

from minicode.subagent_types import (
    AGENT_TYPES,
    MAX_TURNS_CEILING,
    PROJECT_AGENT_ALLOWED_TOOLS,
    RESERVED_AGENT_NAMES,
)

AGENTS_DIR_NAME = os.path.join(".mini-code", "agents")

# Project profiles are routed by name through sub-agent plumbing that expects
# lowercase identifiers; anything else is treated as invalid, not normalized.
_PROFILE_NAME_RE = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")

# Tools that mutate the workspace or process environment. A project profile
# naming any of these fails closed even before the read-only allowlist check;
# project profiles must never be able to change the checkout.
_WRITE_TOOL_NAMES = frozenset(
    {
        "write_file",
        "edit_file",
        "run_command",
        "apply_patch",
        "notebook_edit",
    }
)

_ALLOWED_FRONTMATTER_KEYS = frozenset({"name", "description", "tools", "max_turns"})

# Profiles without an explicit budget reuse the calibrated explore budget.
_DEFAULT_MAX_TURNS = AGENT_TYPES["explore"]["max_turns"]


class SubagentProfileError(ValueError):
    """A project agent profile file failed validation and is rejected."""


@dataclass(frozen=True)
class ProjectAgentProfile:
    """One validated project Markdown agent profile."""

    name: str
    instructions: str
    description: str
    tools: tuple[str, ...]
    max_turns: int
    source: str

    def as_agent_def(self) -> dict[str, Any]:
        """Project onto the ``AGENT_TYPES``-shaped dict dispatchers consume."""
        return {
            "name": self.name,
            "description": self.description,
            "system_prompt": self.instructions,
            "allowed_tools": set(self.tools),
            "max_turns": self.max_turns,
        }


@dataclass(frozen=True)
class ProjectAgentCatalog:
    """Validated profiles for one project plus the files rejected loading it."""

    profiles: Mapping[str, ProjectAgentProfile]
    errors: tuple[tuple[str, str], ...]

    def get(self, name: str) -> ProjectAgentProfile | None:
        return self.profiles.get(name)


def parse_agent_profile(markdown: str, source: str = "<memory>") -> ProjectAgentProfile:
    """Parse and validate one Markdown agent profile.

    Raises :class:`SubagentProfileError` on any rule violation; there is no
    recovery path that yields a partially trusted profile.
    """
    normalized = str(markdown).replace("\r\n", "\n")
    lines = normalized.split("\n")
    if not lines or lines[0].strip() != "---":
        raise SubagentProfileError(f"{source}: frontmatter is missing or malformed")

    close = None
    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            close = index
            break
    if close is None:
        raise SubagentProfileError(f"{source}: frontmatter is not closed with '---'")

    metadata = _parse_frontmatter_block(lines[1:close], source)
    unknown = sorted(set(metadata) - _ALLOWED_FRONTMATTER_KEYS)
    if unknown:
        raise SubagentProfileError(
            f"{source}: unknown frontmatter key(s): {', '.join(unknown)}"
        )

    name = _validate_name(metadata.get("name"), source)
    description = metadata.get("description", "")
    if not isinstance(description, str):
        raise SubagentProfileError(f"{source}: description must be a string")
    tools = _validate_tools(metadata.get("tools"), source)
    max_turns = _validate_max_turns(metadata.get("max_turns"), source)

    body = "\n".join(lines[close + 1 :]).strip()
    if not body:
        raise SubagentProfileError(f"{source}: instruction body must be nonempty")

    return ProjectAgentProfile(
        name=name,
        instructions=body,
        description=description.strip(),
        tools=tools,
        max_turns=max_turns,
        source=source,
    )


def _parse_frontmatter_block(header_lines: list[str], source: str) -> dict[str, Any]:
    """Strict parser for the small YAML subset profiles are allowed to use.

    Unlike the forgiving skill parser, any line that is neither blank, a
    comment, a ``key: value`` pair, nor a ``- item`` list entry under the most
    recent key is malformed and fails closed.
    """
    metadata: dict[str, Any] = {}
    current_key: str | None = None
    for raw_line in header_lines:
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("- "):
            if current_key is None:
                raise SubagentProfileError(
                    f"{source}: list item outside of a frontmatter key: {stripped!r}"
                )
            existing = metadata.setdefault(current_key, [])
            if not isinstance(existing, list):
                raise SubagentProfileError(
                    f"{source}: mixed list and scalar value for key {current_key!r}"
                )
            existing.append(_unquote(stripped[2:].strip()))
            continue
        if ":" not in stripped:
            raise SubagentProfileError(f"{source}: malformed frontmatter line: {stripped!r}")
        key, value = stripped.split(":", 1)
        current_key = key.strip()
        if not current_key or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*", current_key):
            raise SubagentProfileError(f"{source}: invalid frontmatter key: {current_key!r}")
        value = value.strip()
        if not value:
            metadata[current_key] = []
        elif value.startswith("[") and value.endswith("]"):
            metadata[current_key] = [
                _unquote(part.strip()) for part in value[1:-1].split(",") if part.strip()
            ]
        else:
            metadata[current_key] = _unquote(value)
    return metadata


def _unquote(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _validate_name(value: Any, source: str) -> str:
    if value is None:
        raise SubagentProfileError(f"{source}: frontmatter key 'name' is required")
    if not isinstance(value, str):
        raise SubagentProfileError(f"{source}: name must be a string")
    name = value.strip()
    if _PROFILE_NAME_RE.fullmatch(name) is None:
        raise SubagentProfileError(
            f"{source}: invalid profile name {name!r}; expected lowercase "
            "[a-z0-9_-] starting with a letter (max 64 chars)"
        )
    if name in RESERVED_AGENT_NAMES:
        raise SubagentProfileError(
            f"{source}: profile name {name!r} is reserved by built-in agent types"
        )
    return name


def _validate_tools(value: Any, source: str) -> tuple[str, ...]:
    if value is None:
        return tuple(sorted(PROJECT_AGENT_ALLOWED_TOOLS))
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise SubagentProfileError(f"{source}: tools must be a list of strings")
    tools: list[str] = []
    for raw in value:
        tool = raw.strip()
        if not tool:
            continue
        if tool in _WRITE_TOOL_NAMES:
            raise SubagentProfileError(
                f"{source}: write tool {tool!r} is not allowed in project profiles"
            )
        if tool not in PROJECT_AGENT_ALLOWED_TOOLS:
            raise SubagentProfileError(f"{source}: unknown tool {tool!r}")
        if tool not in tools:
            tools.append(tool)
    if not tools:
        raise SubagentProfileError(f"{source}: tools must name at least one tool")
    return tuple(tools)


def _validate_max_turns(value: Any, source: str) -> int:
    if value is None:
        return _DEFAULT_MAX_TURNS
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise SubagentProfileError(f"{source}: max_turns must be an integer")
    try:
        limit = int(str(value).strip(), 10)
    except ValueError:
        raise SubagentProfileError(f"{source}: max_turns must be an integer") from None
    if not 1 <= limit <= MAX_TURNS_CEILING:
        raise SubagentProfileError(
            f"{source}: max_turns {limit} is out of range [1, {MAX_TURNS_CEILING}]"
        )
    return limit


def agents_dir(project_root: str | os.PathLike[str]) -> str:
    return os.path.join(os.fspath(project_root), AGENTS_DIR_NAME)


def load_project_agent_catalog(
    project_root: str | os.PathLike[str], *, refresh: bool = False
) -> ProjectAgentCatalog:
    """Load (and cache) every valid project profile under ``.mini-code/agents``.

    Invalid files are skipped and reported in ``catalog.errors``; the cache is
    keyed by a directory fingerprint (directory mtime plus per-file mtimes) so
    additions, removals, and in-place edits invalidate it.
    """
    directory = agents_dir(project_root)
    fingerprint = _directory_fingerprint(directory)
    if not refresh:
        cached = _cache_get(directory, fingerprint)
        if cached is not None:
            return cached
    catalog = _scan_directory(directory)
    _cache_store(directory, fingerprint, catalog)
    return catalog


def load_project_agent_profiles(
    project_root: str | os.PathLike[str], *, refresh: bool = False
) -> dict[str, ProjectAgentProfile]:
    """Valid project profiles keyed by name, sorted for deterministic order."""
    return dict(load_project_agent_catalog(project_root, refresh=refresh).profiles)


def reset_profile_cache() -> None:
    """Drop all cached catalogs (test hook; long hosts can call it too)."""
    with _CACHE_LOCK:
        _CACHE.clear()


_CACHE: dict[str, tuple[tuple | None, ProjectAgentCatalog]] = {}
_CACHE_LOCK = threading.Lock()


def _directory_fingerprint(directory: str) -> tuple | None:
    """Cache identity for one agents directory.

    The directory's own mtime covers entry creation and removal; each entry's
    mtime and size cover in-place edits, which do not touch the directory
    mtime. ``None`` means the directory is missing or unreadable.
    """
    try:
        dir_stat = os.stat(directory)
        names = sorted(os.listdir(directory))
    except OSError:
        return None
    entries = []
    for name in names:
        try:
            entry_stat = os.stat(os.path.join(directory, name))
        except OSError:
            entries.append((name, -1, -1))
            continue
        entries.append((name, entry_stat.st_mtime_ns, entry_stat.st_size))
    return (dir_stat.st_mtime_ns, tuple(entries))


def _cache_get(
    directory: str, fingerprint: tuple | None
) -> ProjectAgentCatalog | None:
    with _CACHE_LOCK:
        entry = _CACHE.get(directory)
    if entry is None or entry[0] != fingerprint:
        return None
    return entry[1]


def _cache_store(
    directory: str, fingerprint: tuple | None, catalog: ProjectAgentCatalog
) -> None:
    with _CACHE_LOCK:
        _CACHE[directory] = (fingerprint, catalog)


def _scan_directory(directory: str) -> ProjectAgentCatalog:
    if not os.path.isdir(directory):
        return ProjectAgentCatalog(profiles={}, errors=())
    try:
        entries = sorted(os.listdir(directory))
    except OSError:
        return ProjectAgentCatalog(profiles={}, errors=())

    profiles: dict[str, ProjectAgentProfile] = {}
    errors: list[tuple[str, str]] = []
    for entry in entries:
        if not entry.endswith(".md"):
            continue
        path = os.path.join(directory, entry)
        try:
            with open(path, "r", encoding="utf-8") as handle:
                markdown = handle.read()
        except (OSError, UnicodeDecodeError) as exc:
            errors.append((path, f"unreadable: {exc}"))
            continue
        try:
            profile = parse_agent_profile(markdown, source=path)
        except SubagentProfileError as exc:
            errors.append((path, str(exc)))
            continue
        if profile.name in RESERVED_AGENT_NAMES:
            # Belt and braces: parse_agent_profile already rejects reserved
            # names, so this only guards future refactors of the loader.
            errors.append(
                (path, f"{path}: profile name {profile.name!r} is reserved")
            )
            continue
        if profile.name in profiles:
            errors.append(
                (path, f"{path}: duplicate profile name {profile.name!r} (kept first)")
            )
            continue
        profiles[profile.name] = profile
    return ProjectAgentCatalog(
        profiles={name: profiles[name] for name in sorted(profiles)},
        errors=tuple(errors),
    )


__all__ = (
    "AGENTS_DIR_NAME",
    "ProjectAgentCatalog",
    "ProjectAgentProfile",
    "SubagentProfileError",
    "agents_dir",
    "load_project_agent_catalog",
    "load_project_agent_profiles",
    "parse_agent_profile",
    "reset_profile_cache",
)
