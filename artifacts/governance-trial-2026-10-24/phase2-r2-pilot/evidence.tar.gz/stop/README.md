# Phase2 r2 受控终止准备（尚未执行）

本目录仅为 root review 准备。**当前 root 尚未发出终止执行决定，也没有发送信号。** 已做源码语法检查及 `inspect` 只读模式，初次观察 wrapper PID 99555 / PGID 99555、suite PID 99559 / PGID 99555、trial PID 5339 / PGID 5339，trial 为 `refactor-workflow-runner-r1-single`，已有 4 个完成 row。`initial-readonly-plan.json` 只是快照，60 秒后失效，不能直接用于稍后的终止。

冻结 helper `scripts/three_arm_processes.py` 的本地字节与 r2 `frozen-code.zip` 相等，SHA `d390f8d2199c64b07696ecb3f30337b083ec7ac6c8c427c950fac0e953155676`。脚本不修改 ROOT 源码、manifest、任务、oracle、结果、私有原始 ledger 或 trial 工作区；不调用 `finalize_trial`，不补跑。所有新文件只写独立 `/tmp` 记录目录。

## 为什么必须先阻止派发

冻结 `run_suite` 会在 child 负退出后调用 `finalize_trial`；若没有 execution.json，会生成 `HardTimeout`，之后仍可派发下一 cell。因此不能单独杀 trial。脚本先向精确 suite PID 发 SIGSTOP 并确认状态，清理 trial 后向同一 suite PID 发 SIGKILL，始终不恢复 suite。suite 与 wrapper 共用 PGID，严禁 killpg。原 wrapper 保持运行，由其 `subprocess.run` 实际 wait 返回后写真实 exitCode、finished、duration；本脚本只复制观察到的 metadata，不伪造退出值或时长。

## 供 review 的执行路径（当前不执行）

1. 获得 root 的明确执行决定后，用只读 `ps` 确认三个当前 PID/完整 command，再运行 `inspect` 生成新文件。它校验完整命令、PPID、PGID、启动时间、活动 cell 尚未 finalize、冻结 manifest/helper SHA，记录完成 row / results SHA。命令形状如下（活动 cell 已变则必须更新到实际观察值）：

```sh
'/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python' \
  /private/tmp/codeloop-governance-20261024/phase2-controlled-stop/stop_r2.py inspect \
  --wrapper-pid 99555 --suite-pid 99559 --trial-pid 5339 \
  --trial-id refactor-workflow-runner-r1-single \
  --plan /private/tmp/codeloop-governance-20261024/phase2-controlled-stop/fresh-plan.json
```

2. root 审核 fresh plan 并决定执行后，在 60 秒有效期内用单独授权标记运行：

```sh
'/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python' \
  /private/tmp/codeloop-governance-20261024/phase2-controlled-stop/stop_r2.py stop \
  --plan /private/tmp/codeloop-governance-20261024/phase2-controlled-stop/fresh-plan.json \
  --record-dir /private/tmp/codeloop-governance-20261024/phase2-controlled-stop/intervention-01 \
  --authorization-note ROOT_CONFIRMED_STOP_THIS_R2_RUN
```

该参数只是防误触，不代替真实授权。record-dir 必须不存在。ps/信号需要 host 执行权限；本次只读 inspect 已使用适用权限，不表示 stop 已获批准。

3. suite STOP 后再次检查 cell 身份与完成记录。使用已有 `stop_trial` 精确清理活动 trial 的 PID/PGID 及已登记/当前后代；临时模块对象上的 `_signal` 额外核对已记录完整命令与启动时间，不改源码/标准库。receipt 的启动时刻不符、未知新 PID、身份漂移均拒绝信号，清理不完整不能当成功。停止结果、实际信号记录、已知进程身份及原始证据 SHA 全部落盘。

4. 只有 `cleanupComplete=true` 才结束 suite。活动 cell 不生成 trial row，独立 sidecar 记 `intervention=design_validity_stop`、`orchestratorStopEvents=1`；不计入 trial 人工干预。只有确实收到用户决定且显式传入 `--human-decision-reference` 时，`humanDecisionObserved` 才保存该消息引用，缺省为 null。活动状态单独记为 `interrupted_unfinalized`、success/errorClass 为 null。固定 32 cells 不变；完成记录 SHA 必须前后相等，未运行/中断保持 missing。原 active 全部文件保留，另外复制 SQLite DB/WAL/SHM 到记录目录再做只读汇总，避免 SQLite 触碰原始 SHM。content-free partial usage 仅输出物理 request 数、事件状态数与 provider 已知 token 下界；最终 totalTokens、USD、模型成功、trial exit/duration 均 null，不把 in-flight 改为 failed。

5. 最多等待 15 秒观察原 wrapper 的最终 metadata。若未出现，记录 unknown/等待超时，不改写 meta、不杀 wrapper。`interruption.json` 可与原结果共同解释，不能被拿来重判或完成缺失 row。

## 失败与限制

- 前置身份、时间或 hash 检查失败时不发信号，重新只读观察。
- suite 已 STOP 后若发生 race/unknown child/清理失败，脚本不自动 resume、不泛杀，记录 `stop_procedure_incomplete` 并退出；suite 可能保持暂停，需要 root 根据保存的精确身份继续处理。此失败状态不能标为清理完成。
- 脚本重用的 cleanup 本身是进程管理而非对抗性沙箱。PID/PGID/full command/start-time 是较强身份核查，仍不是内核级不可复用 handle；短窗口的 PID 重用和未登记 daemonization 不能作绝对保证。
- API 服务端可能在本地连接终止后继续处理，部分费用/用量未知；不能从本地清理推定零后续计费。
- 执行路径没有在真实 run 上演练；本次验证为标签修正前的 syntax + inspect，零信号；随后仅修正 intervention/orchestrator 归属与可选用户消息引用，不重跑。旧 initial plan 仍保留原脚本 SHA，必须重新 inspect 才能执行。没有将准备完成当成执行成功。
