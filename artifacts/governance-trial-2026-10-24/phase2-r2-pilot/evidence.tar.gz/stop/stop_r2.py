"""Prepared intervention; inspect is read-only. stop requires separate explicit authorization.

Never finalize a trial, edit a frozen file, write a result row, resume the suite,
kill a process group, or signal the wrapper. All evidence goes outside execution-r2.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sqlite3
import subprocess
import sys
import time
import zipfile

BASE = Path('/private/tmp/codeloop-governance-20261024')
REPO = Path('/Users/zhourunbo/code/coding agent/MiniCode-Python-main')
OUTPUT = BASE / 'phase2-portable/execution-r2'
WRAPPER = BASE / 'run_phase2_live_r2.py'
META = BASE / 'phase2-live-r2-run-meta.json'
MANIFEST_SHA = '32dacc257169eff53026a3b8e1663ed68b62ceae1adac118589073921d47d332'
HELPER_SHA = 'd390f8d2199c64b07696ecb3f30337b083ec7ac6c8c427c950fac0e953155676'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_new(path, value):
    with Path(path).open('x') as f:
        os.chmod(path, 0o600)
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())


def table():
    # Never dump this inventory: retain only the exact task-owned identities.
    out = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,stat=,lstart=,command='],
                         check=True, text=True, capture_output=True, timeout=3,
                         env={**os.environ, 'LC_ALL':'C'}).stdout
    rows = {}
    for line in out.splitlines():
        p = line.split(None, 9)
        if len(p) != 10:
            raise RuntimeError('unparseable ps row')
        rows[int(p[0])] = dict(pid=int(p[0]), ppid=int(p[1]), pgid=int(p[2]), state=p[3],
                              started=' '.join(p[4:9]), command=p[9])
    return rows


def identity(row):
    return {k: row[k] for k in ('pid', 'pgid', 'started', 'command')}


def require_same(expected, rows, *, parent=True):
    current = rows.get(expected['pid'])
    if current is None or identity(current) != identity(expected):
        raise RuntimeError(f"identity changed or missing: PID {expected['pid']}")
    if parent and current['ppid'] != expected['ppid']:
        raise RuntimeError(f"parent changed: PID {expected['pid']}")
    return current


def frozen_contract():
    if digest(OUTPUT / 'manifest.json') != MANIFEST_SHA:
        raise RuntimeError('manifest mismatch')
    helper = REPO / 'scripts/three_arm_processes.py'
    if digest(helper) != HELPER_SHA:
        raise RuntimeError('cleanup helper mismatch')
    with zipfile.ZipFile(OUTPUT / 'frozen-code.zip') as z:
        if hashlib.sha256(z.read('scripts/three_arm_processes.py')).hexdigest() != HELPER_SHA:
            raise RuntimeError('cleanup helper not frozen version')
    meta = json.loads(META.read_text())
    if meta.get('finished') is not None or meta['manifestSha256'] != MANIFEST_SHA:
        raise RuntimeError('run already finished or metadata mismatch')
    return json.loads((OUTPUT / 'manifest.json').read_text())


def completed_hashes():
    return {p.name: digest(p) for p in sorted((OUTPUT / 'trials').glob('*.json'))}


def inspect(args):
    manifest = frozen_contract()
    scheduled = {t['id'] for t in manifest['schedule']}
    if args.trial_id not in scheduled or (OUTPUT / 'trials' / (args.trial_id + '.json')).exists():
        raise RuntimeError('trial is not scheduled and unfinalized')
    rows = table()
    wrapper, suite, trial = (rows[p] for p in (args.wrapper_pid, args.suite_pid, args.trial_pid))
    # macOS Python.app is the observed process image (venv symlink resolves to a launcher).
    executable = '/Library/Frameworks/Python.framework/Versions/3.12/Resources/Python.app/Contents/MacOS/Python'
    expected_commands = [
        f'{executable} {WRAPPER}',
        f'{executable} scripts/run_three_arm_real.py run --output {OUTPUT}',
        f'{executable} {REPO / "scripts/run_three_arm_real.py"} child --output {OUTPUT} --trial {args.trial_id}',
    ]
    if [r['command'] for r in (wrapper, suite, trial)] != expected_commands:
        raise RuntimeError('full command does not exactly match approved launch shape')
    if suite['ppid'] != wrapper['pid'] or trial['ppid'] != suite['pid'] or trial['pgid'] != trial['pid']:
        raise RuntimeError('unexpected ancestry or trial session')
    plan = dict(createdEpoch=time.time(), expiresAfterSeconds=60, manifestSha256=MANIFEST_SHA,
                helperSha256=HELPER_SHA, scriptSha256=digest(__file__), wrapper=wrapper,
                suite=suite, trial=trial, trialId=args.trial_id,
                completedRows=completed_hashes(), resultsSha256=digest(OUTPUT / 'results.json'),
                note='Read-only plan; stale identities or completed-row changes require a new inspect plan.')
    write_new(args.plan, plan)
    print(json.dumps({'mode':'inspect_only','plan':str(args.plan), 'signalsSent':0,
                      'trialId':args.trial_id,'completedRows':len(plan['completedRows'])}))


def capture_owned_identities(root_pid, evidence):
    rows = table()
    owned = {root_pid}
    for line in evidence.read_text().splitlines():
        r = json.loads(line)
        if type(r['pid']) is not int or type(r['pgid']) is not int:
            raise RuntimeError('invalid process receipt')
        if r['pid'] in rows and rows[r['pid']]['pgid'] == r['pgid']:
            # A receipt may outlive its process. New-session PIDs can be reused
            # with the same PGID, so reject a start-time mismatch as well.
            observed_start = time.mktime(time.strptime(rows[r['pid']]['started'], '%a %b %d %H:%M:%S %Y'))
            if r['pid'] != root_pid and abs(observed_start - float(r['spawnedEpoch'])) > 2:
                raise RuntimeError('stale receipt start time; review manually')
            owned.add(r['pid'])
    while True:
        new = {p for p, r in rows.items() if r['ppid'] in owned} - owned
        if not new: break
        owned.update(new)
    return {p: rows[p] for p in owned if p in rows}


def retain_ledger(root, event_dir):
    # Copy only the SQLite ledger and its sidecars after writer cleanup. Never open
    # the original database with SQLite: even read-only WAL access can touch shm.
    copied = event_dir / 'ledger-copy'; copied.mkdir(mode=0o700)
    original_hashes = {}
    for name in ('transport.sqlite', 'transport.sqlite-wal', 'transport.sqlite-shm'):
        source = root / name
        if source.exists():
            original_hashes[name] = digest(source)
            target = copied / name
            target.write_bytes(source.read_bytes()); target.chmod(0o600)
            if digest(target) != original_hashes[name]: raise RuntimeError('ledger copy mismatch')
    if 'transport.sqlite' not in original_hashes:
        return {'available':False, 'totalTokens':None, 'costUsd':None}, original_hashes
    with sqlite3.connect((copied / 'transport.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        requests = [json.loads(x[0]) for x in db.execute('SELECT data FROM requests ORDER BY call')]
    known = [r for r in requests if r.get('usage', {}).get('source') == 'provider']
    counts = {event: sum(r.get('event') == event for r in requests) for event in ('started','completed','failed')}
    # This is an unfinalized observation, never an experiment row or final bill.
    summary = dict(available=True, snapshotKind='design_validity_stop_partial_usage',
                   physicalRequestsObserved=len(requests), eventCounts=counts,
                   providerUsageCalls=len(known), unknownUsageCalls=len(requests)-len(known),
                   knownInputTokens=sum(r['usage']['input_tokens'] for r in known),
                   knownOutputTokens=sum(r['usage']['output_tokens'] for r in known),
                   totalTokens=None, costUsd=None, orchestratorStopEvents=1,
                   modelTaskSuccess=None, processExitCode=None, processDurationSeconds=None,
                   note='Known receipts are lower bounds; in-flight status is retained, not recast as failure. Server-side work after termination is unknown.')
    if any(digest(root / n) != h for n,h in original_hashes.items()):
        raise RuntimeError('original ledger changed after cleanup')
    return summary, original_hashes


def stop(args):
    if args.authorization_note != 'ROOT_CONFIRMED_STOP_THIS_R2_RUN':
        raise RuntimeError('separate root execution decision is required')
    plan = json.loads(args.plan.read_text())
    frozen_contract()
    if plan['manifestSha256'] != MANIFEST_SHA or plan['scriptSha256'] != digest(__file__):
        raise RuntimeError('plan contract or script changed')
    if not 0 <= time.time() - plan['createdEpoch'] <= plan['expiresAfterSeconds']:
        raise RuntimeError('stale plan: inspect exact current identities again')
    if completed_hashes() != plan['completedRows'] or digest(OUTPUT/'results.json') != plan['resultsSha256']:
        raise RuntimeError('completed evidence advanced: make a fresh plan')
    rows = table()
    for kind in ('wrapper','suite','trial'): require_same(plan[kind], rows)
    event_dir = args.record_dir
    event_dir.mkdir(mode=0o700, parents=False, exist_ok=False)
    write_new(event_dir / 'plan.json', plan)
    events = event_dir / 'events.jsonl'
    def record(event):
        with events.open('a') as f:
            os.chmod(events, 0o600)
            f.write(json.dumps(dict(observedEpoch=time.time(), **event))+'\n')
            f.flush(); os.fsync(f.fileno())
    def send_exact(expected, sig):
        require_same(expected, table(), parent=False)
        record({'event':'signal_attempt','pid':expected['pid'],'pgid':expected['pgid'],'signal':sig.name})
        os.kill(expected['pid'], sig)
        record({'event':'signal_syscall_returned','pid':expected['pid'],'signal':sig.name})
    suite_frozen = False
    try:
        # A single PID: suite shares its PGID with wrapper, so killpg is forbidden.
        send_exact(plan['suite'], signal.SIGSTOP)
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            current = require_same(plan['suite'], table())
            if current['state'].startswith('T'):
                suite_frozen = True; break
            time.sleep(0.02)
        if not suite_frozen: raise RuntimeError('suite STOP not confirmed')
        rows = table()
        require_same(plan['wrapper'], rows); require_same(plan['trial'], rows)
        if completed_hashes() != plan['completedRows'] or digest(OUTPUT/'results.json') != plan['resultsSha256']:
            raise RuntimeError('evidence advanced during freeze; inspect retained frozen suite')
        root = OUTPUT / 'private' / plan['trialId']
        if (OUTPUT/'trials'/(plan['trialId']+'.json')).exists():
            raise RuntimeError('active trial finalized during freeze')
        owned = capture_owned_identities(plan['trial']['pid'], root/'processes.jsonl')
        if plan['suite']['pid'] in owned or plan['wrapper']['pid'] in owned:
            raise RuntimeError('receipt includes guardian identity')
        write_new(event_dir/'owned-identities.json', list(owned.values()))
        spec = importlib.util.spec_from_file_location('reviewed_stop_helper', REPO/'scripts/three_arm_processes.py')
        module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        original_signal = module._signal
        def guarded_signal(pid, pgid, value):
            # Extra caller-only guard: no mutation to frozen helper/source or stdlib.
            current = table().get(pid)
            if current is None: return False
            expected = owned.get(pid)
            if expected is None or identity(current) != identity(expected) or current['pgid'] != pgid:
                record({'event':'identity_guard_denied','pid':pid,'pgid':pgid})
                raise PermissionError('unknown or changed exact process identity')
            return original_signal(pid, pgid, value)
        module._signal = guarded_signal
        cleanup = module.stop_trial(plan['trial']['pid'], root/'processes.jsonl',
                                    expected_root_pgid=plan['trial']['pgid'])
        write_new(event_dir/'trial-cleanup.json', cleanup)
        if not cleanup['cleanupComplete']:
            raise RuntimeError('cleanup incomplete: suite remains STOPPED; review survivors without broad kill')
        usage, ledger_hashes = retain_ledger(root, event_dir)
        write_new(event_dir/'partial-usage.json', usage)
        write_new(event_dir/'active-evidence-hashes.json',
                  {str(p.relative_to(root)):digest(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()})
        # Never resume this suite: resumed run_suite would finalize/relabel and dispatch.
        send_exact(plan['suite'], signal.SIGKILL)
        deadline = time.monotonic() + 15
        observed_meta = None
        while time.monotonic() < deadline:
            candidate = json.loads(META.read_text())
            if candidate.get('finished') is not None:
                observed_meta = candidate; break
            time.sleep(0.1)
        if completed_hashes() != plan['completedRows'] or digest(OUTPUT/'results.json') != plan['resultsSha256']:
            raise RuntimeError('completed evidence changed unexpectedly')
        write_new(event_dir/'interruption.json', dict(
            intervention='design_validity_stop', trialId=plan['trialId'],
            orchestratorStopEvents=1,
            humanDecisionObserved=({'messageReference': args.human_decision_reference}
                                   if args.human_decision_reference else None),
            status='interrupted_unfinalized', success=None, errorClass=None,
            originalExpectedCells=32, completedRowCount=len(plan['completedRows']),
            originalCompletedRowsUnchanged=True, originalResultsUnchanged=True,
            activeRowWritten=False, finalizationInvoked=False, reruns=0,
            trialCleanup=cleanup['cleanupComplete'], ledgerHashes=ledger_hashes,
            wrapperMetaObserved=observed_meta, wrapperMetaSha256=digest(META),
            wrapperWaitTimedOut=observed_meta is None,
            note='Actual wrapper metadata is copied as observed, never synthesized. Missing cells remain missing. No HardTimeout conversion.'))
        print(json.dumps({'recordDir':str(event_dir),'cleanupComplete':True,'wrapperFinishedObserved':observed_meta is not None}))
    except BaseException as error:
        record({'event':'stop_procedure_incomplete','errorClass':type(error).__name__,
                'suiteStopConfirmed':suite_frozen,'automaticResume':False})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    p = sub.add_parser('inspect')
    for name in ('wrapper-pid','suite-pid','trial-pid'):p.add_argument('--'+name,type=int,required=True)
    p.add_argument('--trial-id',required=True);p.add_argument('--plan',type=Path,required=True)
    p = sub.add_parser('stop')
    p.add_argument('--plan',type=Path,required=True);p.add_argument('--record-dir',type=Path,required=True)
    p.add_argument('--authorization-note',required=True)
    p.add_argument('--human-decision-reference', default=None,
                   help='Reference to an actually received human decision; omit when unavailable. Never counted as trial human events.')
    args = parser.parse_args()
    (inspect if args.mode == 'inspect' else stop)(args)

if __name__ == '__main__': main()
