# Phase2 r2 固定接口可发现性复审

范围：只读全部16题冻结prompt、shared/case初始文件与oracle源码/fixtures；没有查看第4条及以后模型输出，也未执行验收、改题、重判或重跑。此次为启动后诊断，不是预注册排除规则。

任务SHA-256：`1e134e338af2b19b78a54ded0ecf0bdcccdfc3c45803cf3c60bab5dc960e8cd5`。Manifest：`32dacc257169eff53026a3b8e1663ed68b62ceae1adac118589073921d47d332`。

发现 **6题明确要求了公开输入缺失的确切新接口名/参数名**；另 **2题有较弱的内部绑定或重命名约定**；其余 **8题未发现同等强度的名称缺口**。后一结论不等于完整题意/验收有效性认证。

| 题目 | 公开程度 | 固定契约与证据 |
|---|---|---|
| `read-router` | 明确公开 + 源码可推导 | JSON键与枚举已给出；路由类/方法与行为在初始文件可查。 |
| `read-deadline` | 明确公开 + 源码可推导 | 时钟场景、JSON键、数值/异常类名编码已公开；处理函数保留在源码。 |
| `read-atomic-replace` | 明确公开 + 源码可推导 | JSON对象/键和probe_source要求已给出；持久化实现与来源证据可查。 |
| `read-closing-reminder` | 明确公开 + 源码可推导 | JSON键与5类场景已给出；run_agent_turn及恢复逻辑在初始代码。 |
| `read-image-boundaries` | 明确公开 + 源码可推导 | 工具、边界、成功mock请求要求已给出；真实工具/错误码可由源码推导。 |
| `write-cache-tip` | 源码可推导 | 既有adapter接口及缓存标记保留；oracle经既有next接口观察请求体。 |
| `write-cache-fallback` | 部分公开；确切配置键隐藏缺失 | 公开要求disable flag/kill switch，但确切运行时键promptCache和环境变量MINI_CODE_PROMPT_CACHE在公开prompt与初始全文件均缺失；oracle严格写这些键。 |
| `write-todo-isolation` | 部分可推导；私有参数隐藏缺失 | 公开要求每context隔离，未指定以ToolContext(_todo_state={tasks,counter})注入；初始ToolContext无该字段，oracle直接构造并检查传入字典。 |
| `write-user-profiles` | 既有API可推导；新关键字隐藏缺失 | 既有load/resolve接口可见；新user_root=关键字在全部公开初始文件与prompt均不存在。来源错误也被精确约束为user:filename，而公开只要求保留origin。 |
| `write-profile-parser` | 行为公开；新增API隐藏缺失 | 新增模块及其历史测试均不在公开checkout；四个固定导出名无公开引用，oracle在收集期import全部四名；load函数返回结构也由隐藏测试固定。 |
| `write-profile-dispatch` | 源码可推导 | profile解析接口和task既有入口均公开；需把现有profile与dispatch连接。未发现同等强度的新名称缺口。 |
| `write-profile-contracts` | 源码可推导 | 三个既有函数、关键字和类型约束可见；新增的是允许已有profile slug语义。 |
| `refactor-finalization` | 行为公开；新内部API隐藏缺失 | 新workflow_finalization.py未提供；oracle直接创建私有Snapshot/Ports和字段、调用finalize_workflow；这些名称在公开输入均缺失。 |
| `refactor-workflow-runner` | 主接口明确；隐藏绑定约定 | prompt完整列出run_workflow五参数和关键字约束。隐藏测试另要求__all__精确tuple、task模块有可monkeypatch的run_workflow同名绑定；实现为模块属性调用也可满足公开行为但不满足此测试。次级约定，不与完全未知API混为一谈。 |
| `refactor-frozen-change` | 旧事务可推导；新增能力API隐藏缺失 | 已有WorkflowWorkspaceTransaction/_FrozenWorkflowChangeSet可见，但新FrozenWorkflowChange、freeze/promote与属性/关键字、确切错误文案均由隐藏测试固定；公开只描述能力语义。 |
| `refactor-workspace` | 旧类可推导；新导出拼写未明示 | 旧_TaskDeadlineExceeded/_WorkflowWorkspaceTransaction/_WorkflowIsolationError与兼容行为可见，新模块路径已给。去掉下划线作为导出名是合理可推导约定但未唯一指定；oracle固定这一命名，弱于全新无上下文API缺失。 |

## 对结论的限制

冻结oracle衡量的是“公开行为任务 + 历史实现接口兼容”的联合条件。对于具体API从未公开的新功能/封装题，失败不能无条件解释为行为实现能力不足，也不能据此把single/auto差异归因于架构优劣。两个profile-parser已完成试次就是收集期缺固定导出名，行为断言尚未执行。

保留原始失败、成本、时间和全部cell；不据当前结果删题、补接口、重跑、改成功率。最终报告同时公开该逐题诊断和原冻结规格；若后续提出更明确的题目，应作为新版本研究，不能覆盖本轮。

## 证据定位与边界

`spec-coverage.json`包含每个检查名的prompt命中、公开源文件/行号、隐藏fixture/行号、选择器与oracle哈希；`spec-inventory.json`是本地静态提取工作底稿。名称检索后已人工核对选中测试中的调用/构造。

本次没有证明某个失败交付在其他合理API下必然正确，也没有完整审核每一条隐藏语义断言。read题要求的历史反例能力、运行边界等另需在最终解释中保留，不用名称可发现性替代完整效度论证。
