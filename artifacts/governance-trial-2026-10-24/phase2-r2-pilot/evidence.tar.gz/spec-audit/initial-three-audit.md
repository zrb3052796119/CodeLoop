# Phase2 r2：首三条只读诊断

这三条结果暂未显示需要恢复transport或重跑试次的基础设施故障。原始成功状态均为false，保持不变；失败不能一律解释为模型行为能力不足。

| 已完成cell | 验收事实 | 分类 |
|---|---|---|
| write-profile-parser-r1-single | oracle导入交付模块时缺AGENT_NAME_RE，历史测试收集失败；新生成回归28通过 | 冻结隐藏API契约不匹配；公开任务未给四个固定导出名，不能据此断言功能行为错误 |
| write-profile-parser-r1-auto | 同类缺AGENT_NAME_RE；新生成回归32通过 | 同上 |
| read-atomic-replace-r1-auto | oracle receipt为JSONDecodeError；非空response不以对象或fence开始，按既有解析规则line1/column1失败 | 公开要求exactly one JSON object，交付格式未满足；尚未执行行为diagnostic |

50次模型请求全部完成，失败0、inFlight 0、用量完整，已知token合计1,079,653。三条执行errorClass均为空、scopePassed均真、清理完成、验收未超时。五份实际oracle/regression receipt的SHA均与其result绑定一致。trial顶层oracleErrorClass为空不代表oracle正常返回：具体错误在子receipt，需保留该层记录。

两条profile-parser不是因为验收宿主找不到pytest或项目路径：报错明确导入的是交付副本的minicode/subagent_profiles.py，缺的是该新模块中的固定名称。但这四个名字AGENT_NAME_RE、RESERVED_AGENT_NAMES、load_agent_profiles、resolve_agent_types在公开prompt与全部初始文件中均不存在；初始模块和历史测试本身也未提供。这是实验规格可发现性限制，完整16题静态表见spec-coverage.md；不得通过修改oracle或重新评分抹去原结果。

凭证检查：仅对这三条的64份结果、receipts、配置结构、transcript/日志等既有文件做本地模式扫描，未发现常见provider key、Bearer长值、私钥或凭证字面量候选；没有读取.env、进程环境、私有HOME或凭证存储，也未读取SQLite。报告仅保留路径、SHA与计数，没有复制provider正文。模式扫描无法证明不存在任意格式秘密，不能替代发布前白名单与脱敏审查。

执行日志含token估计漂移与生命周期观察不可用警告；目前记录中未见它们导致执行中断。未把这些警告或已知PTY缺陷强行归因到本三条。

本诊断未调用模型/网络API、未执行测试或oracle、未修改任何冻结目录，且之后的静态16题检查没有读取后续模型输出。机器可核验字段与文件SHA见initial-three-audit.json。
