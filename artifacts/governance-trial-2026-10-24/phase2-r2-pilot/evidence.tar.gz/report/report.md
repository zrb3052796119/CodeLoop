# 真实历史任务比较：描述性结果

状态：incomplete_no_full_comparison；记录 5/32 cells；16 对任务、每 cell 1 次。

| 层次 | single 成功/已完成/计划 | auto 成功/已完成/计划 | auto−single 成功百分点 |
| --- | ---: | ---: | ---: |
| 全部 | 1/3/16 | 0/2/16 | 未知/不可合计 |
| read | 1/1/5 | 0/1/5 | 未知/不可合计 |
| write | 0/1/7 | 0/1/7 | 未知/不可合计 |
| refactor | 0/1/4 | 0/0/4 | 未知/不可合计 |

| 指标：合计；已知/样本数 | single 全部 | auto 全部 | single 成功子集 | auto 成功子集 |
| --- | ---: | ---: | ---: | ---: |
| 输入+输出 token | 未知/不可合计；3/16，已知小计≥3,445,562 | 未知/不可合计；2/16，已知小计≥600,856 | 556,740；1/1 | 未知/不可合计；0/0 |
| 物理调用 | 未知/不可合计；3/16，已知小计≥88 | 未知/不可合计；2/16，已知小计≥28 | 17；1/1 | 未知/不可合计；0/0 |
| agent 墙钟秒 | 未知/不可合计；3/16，已知小计≥2,595.51 | 未知/不可合计；2/16，已知小计≥901.96 | 762.17；1/1 | 未知/不可合计；0/0 |

配对成功分布：{"bothSuccess": 0, "singleOnly": 1, "autoOnly": 0, "bothFailure": 1, "missingPair": 14}。
全体配对开销差（auto−single）：totalTokens=未知/不可合计（2/16 对已知）；modelCalls=未知/不可合计（2/16 对已知）；durationSeconds=未知/不可合计（2/16 对已知）。
两组均成功子集：0 对；按结果筛选，仅作补充，详见 summary.json。

| 委派证据/缺失 | single | auto |
| --- | ---: | ---: |
| trialsWithAttempt | 0 | 0 |
| trialsWithActualDeliveredLeaf | 0 | 0 |
| actualLeafRuns | 0 | 0 |
| deliveredLeafResults | 0 | 0 |
| leafModelCalls | 0 | 0 |

详细角色证据可用 0/5 cells；逐角色物理调用、完成执行及交付见 summary.json，未把 task 请求当作协作。
实际角色物理调用（仅可用证据小计）：single={}；auto={}。
未知 usage 调用 single=0、auto=0；货币费用与人工批准/纠正次数均未知。宿主策略决定及 permission 事件另计。
失败和超时仍计入全部试次；成功子集按各组成功筛选、任务可能不同。未知 token 不插补零，cache 已包含于 input；agent 墙钟不含独立裁判时间，process/judge 时间另外保留。
这是相关历史任务、单次采样的内部描述；没有显著性/置信区间、普遍优劣或记忆增益结论。完整数值、每 cell 缺失状态、失败类别及输入 SHA 在 summary.json / trials.csv。
