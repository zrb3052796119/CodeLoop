from pathlib import Path
import os,sys,subprocess,json,time
base=Path('/private/tmp/codeloop-governance-20261024');ev=base/'hot-store-budget-diagnosis'
source=base/sys.argv[1];label=sys.argv[2];tests=sys.argv[3:]
env=os.environ.copy()
for key in list(env):
 if key.startswith('MINI_CODE_') or key.endswith('_API_KEY') or key in {'ANTHROPIC_AUTH_TOKEN','OPENAI_ACCESS_TOKEN','AZURE_OPENAI_KEY'}:env.pop(key,None)
home=ev/(label+'-home');home.mkdir(exist_ok=True)
env.update(HOME=str(home),USERPROFILE=str(home),MINICODE_PYTEST_REAL_HOME='/Users/zhourunbo',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(source)+os.pathsep+str(ev),HOT_DIAG_SOURCE=str(source),HOT_DIAG_PROOF=str(ev/(label+'-import.json')))
cmd=['/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python','-m','pytest',*tests,'-vv','--randomly-seed=20261024','--tb=long','--showlocals','-o','cache_dir='+str(ev/'cache'),'-p','hot_diag_plugin']
started=time.time()
with (ev/(label+'.log')).open('w') as log: result=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
(ev/(label+'-meta.json')).write_text(json.dumps({'source':str(source),'label':label,'command':cmd,'exit_code':result.returncode,'started':started,'elapsed':time.time()-started},indent=2)+'\n')
print((ev/(label+'.log')).read_text());sys.exit(result.returncode)
