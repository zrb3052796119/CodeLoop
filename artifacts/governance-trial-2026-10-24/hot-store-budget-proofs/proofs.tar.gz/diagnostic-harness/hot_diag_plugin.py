from pathlib import Path
import os,sys,json,hashlib

def pytest_runtest_call(item):
 module=sys.modules.get('minicode.memory_hot_store')
 if module is None:return
 path=Path(module.__file__).resolve();source=Path(os.environ['HOT_DIAG_SOURCE'])
 expected_mutant = os.environ.get('HOT_DIAG_MUTANT')
 assert path == Path(expected_mutant) if expected_mutant else path.is_relative_to(source), path
 out=Path(os.environ['HOT_DIAG_PROOF'])
 if not out.exists():out.write_text(json.dumps({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},indent=2)+'\n')

import pytest

@pytest.fixture(autouse=True)
def instrument_wait_boundaries(request, monkeypatch):
 if os.environ.get('HOT_DIAG_TRACE') != '1' or 'test_memory_hot_store.py' not in request.node.nodeid:
  yield
  return
 import time,threading,types
 from minicode import memory_hot_store as hot
 events=[]
 stamp=time.monotonic
 real_call=hot.MemoryHotStore._call
 real_break=hot.MemoryHotStore._break
 class ObservedEvent(threading.Event):
  def wait(self, timeout=None):
   start=stamp(); result=super().wait(timeout); end=stamp()
   events.append({'kind':'event_wait','thread':threading.current_thread().name,'requested':timeout,'elapsed':end-start,'finished':result})
   return result
 def observe_call(self, operation, default):
  b=hot._turn_budget.get(); remaining_before=b.remaining if b else None; start=stamp()
  try:return real_call(self,operation,default)
  finally:
   b=hot._turn_budget.get()
   events.append({'kind':'call','elapsed':stamp()-start,'remaining_before':remaining_before,'remaining_after':b.remaining if b else None,'available':self.available})
 def observe_break(self,error):
  start=stamp()
  try:return real_break(self,error)
  finally:events.append({'kind':'break','elapsed':stamp()-start,'exception':type(error).__name__})
 monkeypatch.setattr(hot,'threading',types.SimpleNamespace(Event=ObservedEvent,Thread=threading.Thread,Lock=threading.Lock))
 monkeypatch.setattr(hot.MemoryHotStore,'_call',observe_call)
 monkeypatch.setattr(hot.MemoryHotStore,'_break',observe_break)
 yield
 out=Path(os.environ['HOT_DIAG_PROOF']).with_name(Path(os.environ['HOT_DIAG_PROOF']).stem.replace('-import','')+'-timing.json')
 out.write_text(json.dumps({'nodeid':request.node.nodeid,'events':events},indent=2)+'\n')


def pytest_collection_modifyitems(session, config, items):
 path=os.environ.get('HOT_DIAG_MUTANT')
 if not path:return
 from minicode import memory_hot_store as hot
 source=Path(path)
 hot.__file__=str(source)
 exec(compile(source.read_text(),str(source),'exec'),hot.__dict__)
