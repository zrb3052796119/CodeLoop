# Redis wait-budget test diagnosis and minimal repair proposal

Status: diagnosis only; both acceptance snapshots remain unchanged and both full suites continue. The original Phase 1 full-suite traceback is not yet available. Do not relabel its failure as passed based on reruns.

## Verified observations

1. The exact test, memory_hot_store.py, memory_path_identity.py, logging_config.py, memory.py, conftest.py and pyproject.toml have identical SHA-256 at 9f936942 and eb17c62a and in both frozen sources (source-comparison.json).
2. The P0 full log records the target PASSED; P1 full records FAILED. Candidate isolated node passes. Baseline isolated node fails at only the final wall assertion: 0.2004985 < 0.2. The first two results are correct, calls is exactly [one, two, three], third/fourth degrade.
3. Candidate whole file: 69 passed, 1 failed. The target passes; test_connection_wait_is_bounded_and_late_ping_cannot_issue_command instead fails at its wall assertion 0.2002681 < 0.2.
4. Instrumentation of a second baseline node failure records first/second call elapsed about 85.28/85.19 ms, with remaining budget 104.77/19.60 ms. The third Event.wait requests only 19.4023 ms but returns after 29.1432 ms (9.7408 ms extra); _break including captured logging costs 0.2287 ms. Final observed wall is 200.22425 ms. Budget is correctly debited to -9.7502 ms and fused. This is measured wait-return latency, not merely a hypothesis inferred from concurrent workloads. Instrumentation adds observer overhead and is separately labeled; the uninstrumented baseline also fails.
5. No evidence that Phase 1 changed budget logic. No evidence yet of the exact assertion that failed in the original P1 full run; preserve that uncertainty.

## Contract wording

README.md:502-503 says: Redis waiting has a shared 190 ms turn allowance, below the 200 ms ceiling. memory_hot_store.py:24 calls 200 ms a turn limit. The three existing tests measure total caller wall time <200 ms, including scheduling, local handling and logging. The implementation caps its requested wait using a monotonic deadline and remaining allowance; the standard runtime cannot guarantee when a descheduled caller is resumed. This ambiguity must be explicit: repairing tests would verify the controllable 190 ms cumulative requested-wait contract, not prove an unconditional 200 ms observed caller-latency SLA. Do not silently relax or restate a hard wall SLA as already guaranteed.

## Ranked hypotheses

- Confirmed for the isolated baseline and adjacent candidate failures: OS/runtime wakeup plus caller overhead consumes the 10 ms scheduling margin. Specific scheduler cause (CPU competition versus timer coalescing) is unproved and unnecessary to the conclusion.
- Still possible for original full failure until its traceback arrives: prior-test pollution or a different assertion failing. The target fixture resets its ContextVar and creates a fresh store; matching code does not by itself rule out order effects.
- Not supported: nested budget accidentally resets or permits a fourth Redis command. All reproduced failures have correct cumulative state and fuse behavior.

## Proposed minimal test change (not applied)

A. Replace the target's three 75 ms sleeps and total wall comparison with a controlled monotonic clock for this module, while keeping real worker threads and real locks. First and second operations each advance virtual I/O time by 75 ms and complete; record the same shared budget object, assert remaining ==115 ms and ==40 ms (within floating point precision) and that nested budget() never replaces it. The third worker enters a real blocked operation. A module-local observed completion Event records the requested timeout, advances the virtual clock by precisely that timeout, and reports timeout while the worker remains blocked. Assert the third timeout is exactly 40 ms or less after measured setup, remaining exhausted, third/fourth caller result default, exactly three operation invocations, no fourth worker, and fuse permanent. Release/join the real blocked worker in finally. No global time/threading monkeypatch, and no production source changes.

B. Keep the existing genuine late-connection / late-constructor / late-import worker scenarios. Replace only the absolute caller <200 ms comparisons with recorded requested completion timeout: finite, nonnegative, <=190 ms (and <=the remaining budget where cumulative). Delegate to real Event.wait. Assert the caller has returned while the worker is still blocked; future calls no-op; release and join worker; PING/command stays forbidden after release. A generous watchdog is only a deadlock guard, never a latency acceptance threshold. This retains real thread timeout and stale-worker protections rather than merely raising 0.2.

C. Counterexamples on temporary production copies only: nested budget reset; completion wait given full190ms for each command; removal of the post-connect available/deadline guard. The exact replacement tests must fail for their respective contract assertions. Label this as test-strength evidence: unchanged good production should pass both the baseline and new fixtures; it is not proof of a historical production bug.

D. If adopted, README must say the implementation caps requested cumulative Redis waiting at190ms; the200ms figure is an intended nominal ceiling, not a guarantee under arbitrary scheduler delays. If the project instead truly requires total wall <=200ms, this proposal is insufficient and that requirement needs separate design/performance evidence.

Implementation should be in a fresh diagnostic copy or later authorized non-frozen working tree, never either running candidate. Keep the current full-suite result, then validate the changed test file plus exact relevant production regression tests; do not launch another full suite during current concurrency.
