# MemoryHotStore cumulative wait failure diagnosis

当前结论：已在未变化的 9f 基线真实复现同一测试的最终 wall-time 断言失败，并测得请求等待与实际返回之间的额外延迟。未发现累计预算计账缺陷；尚未拿到原 Phase 1 全量失败的详细 trace，因此不能把原 run 的失败最终归因，也不能用定向重跑通过覆盖它。

两份全量继续运行；本任务没有修改两个候选树、生产代码、仓库测试或 Git。

## 证据

- 目标测试、memory_hot_store 及相关依赖、根 conftest、pyproject 在 9f936942 / eb17c62a 和各自冻结导出逐字节一致：source-comparison.json。
- P0 全量同节点通过；P1 全量同节点失败。候选隔离节点 1 pass。
- 基线隔离节点真实失败：前三次调用序列和返回都正确，最终 200.4985 ms 不满足 <200 ms。
- 候选整文件 69 pass / 1 fail：目标节点通过，邻接 late-connect 用例因 200.2681 ms 的同类 wall 断言失败。
- 基线加入边界观测后再次失败：第一次调用后余量 104.7666 ms、第二次后 19.6015 ms，第三次 Event.wait 只请求 19.4023 ms，实际耗时 29.1432 ms；_break 包括捕获日志 0.2287 ms，总 wall 200.22425 ms。正确扣到 -9.7502 ms 并熔断。观测数据在 baseline-instrumented-timing.json；其增加的少量观测开销与未观测的真实失败分开记录。

这支持等待返回/线程调度余量不足，不证明具体 CPU 竞争或平台定时器是唯一原因。源文件相同亦不能单独排除原全量中的顺序污染；需保留原 full traceback。

## 契约边界和方案

README 第 502–503 行确实写190 ms turn allowance、200 ms ceiling；源码也写200 ms turn limit。当前实现能控制累计请求等待时间，不能保证进程被操作系统暂停后何时恢复。因此不能仅把断言阈值改大，也不能声称无条件200ms caller wall SLA已实现。完整方案见 repair-plan.md。

已在纯 /tmp 原型中落实两个互补检查：

1. 模块局部受控 monotonic clock，保留真实 worker/lock。前两次操作各消耗75ms，断言同一 budget identity、剩余115→40ms；第三次真实worker阻塞，断言只请求40ms、预算耗尽、第三/四调用降级、仅三次操作且永久熔断，finally 释放并等待迟到worker退出。
2. 真实 Event.wait 和真实迟到连接线程，直接断言请求timeout有限且≤190ms；调用返回时worker仍阻塞，fuse后不再连接，释放worker后仍不得执行Redis命令。替换wall抖动判断，没有把0.2换成更宽阈值。

同一原型测试字节在 candidate / baseline 各 2 pass（0.33 / 0.30 秒）。三个只存在于/tmp的定向故障分别被准确拒绝：

- 重置嵌套budget：预期115ms却仍190ms，1fail / 1pass。
- 每次 completion wait 重新给190ms：预期40ms却190ms，1fail / 1pass。
- 去掉连接返回后的available/deadline guard：迟到client.get被调用1次，1fail / 1pass。

这些是测试强度验证，不是历史生产bug的PROVEN证明。原型不直接成为仓库补丁；三个现有真实线程wall用例需保持各自late PING/import/command身份与清理断言。若采纳，应另在可写非冻结树实施，并明确README时间保证；若200ms无条件总caller SLA是硬要求，当前方案不足，需要另行性能/架构设计。

## 位置

证据目录：/private/tmp/codeloop-governance-20261024/hot-store-budget-diagnosis/。

- diagnosis-summary.json：命令、源路径、耗时、退出码、原型测试SHA。
- source-comparison.json：两个提交及导出的逐文件SHA。
- baseline-node.log、candidate-file.log：未观测真实失败。
- baseline-instrumented.log / -timing.json：请求等待、实际等待、计账及_break成本。
- probe-tests/test_wait_contract.py：未入库替代测试原型。
- baseline-proposed.log / candidate-proposed.log：相同测试字节对照。
- fault-*.log、对应import/meta JSON：严格限定的故障注入证据，已标注合成。

测试均用 root .venv-acceptance Python、独立 HOME 与精确源 PYTHONPATH，记录运行时实际 import 路径及SHA；没有网络/API调用，也没有重复全量。
