# MemoryHotStore budget fixture repair — implemented

Applied only in the managed Phase 1 worktree. Files: tests/test_memory_hot_store.py, README.md, and the misleading two-line budget comment in minicode/memory_hot_store.py. Production AST is identical before/after; no runtime logic changed. Neither frozen full-suite source was modified. No Git commit created.

Three absolute caller-wall assertions were replaced by budget-owned observations:

- Real connection/construction workers still block on actual Events. A 20-line fixture delegates to real Event.wait and asserts a finite nonnegative request no larger than remaining turn budget and190ms. The caller must return before the worker finishes; after release the worker still cannot issue late Redis commands/PING. Cleanup now also waits for worker lock release in finally.
- The cumulative case keeps real workers/locks and uses only module-local controlled time/completion timing. It checks the same nested budget identity,115ms after first operation,40ms after second, third request limited to remaining40ms, zero remaining after timeout, fourth call skipped and no extra worker. A blocked third worker is explicitly released and drained.
- README explicitly corrects the earlier200ms total-latency claim, explaining that scheduling/local processing can exceed it. This is not a claim that the old hard wall guarantee was met, nor a numerical threshold increase.

Validation: complete hot-store file and both direct neighboring consumers (memory_deposition_experiment, memory_hybrid_v2) passed347 tests in20.53s. Repository CI Ruff E/F ignoringE501 passed, and git diff --check passed. The first Ruff invocation could not create cache in the managed worktree under the sandbox; the rerun using a/tmp cache passed and is the recorded result.

Exact final complete test file SHA256: bfabf364f440601ee190c9145f4be7527e701b8d81d8f24c39388ef5b92f6046. The same file bytes and the same three-node command were run against baseline/fixed production:3pass on each. Three temporary production faults, each with these same final test bytes, produce intended failures: nested reset leaves190 instead of115ms; full per-call190ms wait violates115ms remaining; missing late guard causes forbidden client.get. Each fault result is1fail/2pass. These are test-strength counterexamples, not historical-bug PROVEN evidence. A staging-script attempt looked for absent tests/__init__.py; it was corrected before any proof run and contributes no verdict.

Final machine-readable evidence: final-implementation-report.json, final-proof-sources.json, final-*-import.json and logs under/private/tmp/codeloop-governance-20261024/hot-store-budget-diagnosis/. final-owned-diff.patch contains only the three authorized files.

The initial Phase1 full-suite failure remains recorded and its detailed trace was still pending when this handoff was written; no rerun has been used to relabel that run green. Both full runs continue independently.
