# Hot-store 最终补丁独立审查

结论：无阻塞发现。审查对象为 governance-context-retention 工作树 `eb17c62a5510b6746c5fc677618303c9b83b96e6` 上的 README、memory_hot_store.py 注释、test_memory_hot_store.py 三文件 diff；未修改工作树或索引，未运行全量。

- 生产语义不变：独立 AST 比对确认 `minicode/memory_hot_store.py` 与 HEAD 相同。README 499–508 明确撤回旧的 200 ms 调用总延迟承诺，改为每次等待请求受剩余预算约束、扣减实测耗时，符合 `_call` 155–200 的实际边界。它不是把生产错误修成绿色，也不再声称 OS 调度存在硬实时上界。
- 累计预算未弱化：测试 460–529 保留真实 Thread、Lock 和阻塞第三操作；仅替换 hot 模块本地的时钟/完成事件。逐步检查 0.190→0.115→0.040→0、嵌套上下文对象身份、第三次等待为剩余 40 ms、熔断后第四次调用不启动，失败结果为 None。比先前依赖不足 10 ms 调度余量的 wall<0.2 断言稳定且更直接；1/2 秒 watchdog 仍是进度保障，不能称完全不受调度影响。
- 迟到禁止未弱化：测试 374–435 仍使用真正的 Event.wait(timeout) 和阻塞 worker，确认调用返回时 worker 尚未完成；释放后获取 operation lock 形成同步，再断言没有 GET / PING。超时后再次调用也不重新连接。finally 释放阻塞点，失败路径也执行清理。
- 无共享模块猴补污染：测试 50–52、491–494 替换 `hot.threading` / `hot.time` 的绑定，不修改全局 `threading.Event`、`Thread`、`Lock` 或 `time.monotonic`。pytest monkeypatch 恢复绑定；原有 autouse fixture 恢复 ContextVar。生产 worker 在释放 operation lock 后仅设置局部 done Event，因此此后无依赖猴补绑定的业务操作。
- 对照信号成立：五个 proof 树的最终测试字节 SHA 均为 `bfabf364f440601ee190c9145f4be7527e701b8d81d8f24c39388ef5b92f6046`；baseline/fixed 各 3 passed。reset-nested 在余额断言、full-wait 在 timeout≤remaining、late-command 在真实 client.get 未调用断言失败。它们证明测试能拒绝这三种人工故障，不证明历史生产有该故障。

独立小探针 `independent_cleanup_probe.py` 直接调用原测试函数和真实 pytest MonkeyPatch 清理，3/3 通过；模块属性与绑定恢复、预算上下文恢复为 None、每项返回后新 memory-redis worker 数量为 0。完整结果见同目录 `independent-cleanup-proof.json`，不是新增项目 gate/全套证据。原全量失败 trace 尚未取得，因此本审查不将其归因于 jitter，也不宣布后续候选全量通过。
