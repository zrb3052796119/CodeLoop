from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import threading
import time
import pytest

repo = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
spec = importlib.util.spec_from_file_location('review_hot_store_tests', repo / 'tests/test_memory_hot_store.py')
test = importlib.util.module_from_spec(spec)
spec.loader.exec_module(test)
hot = test.hot
assert Path(hot.__file__).resolve() == repo / 'minicode/memory_hot_store.py'
originals = (threading.Event, threading.Thread, threading.Lock, time.monotonic)
rows = []
for name in [
    'test_connection_wait_is_bounded_and_late_ping_cannot_issue_command',
    'test_late_client_construction_never_pings_after_timeout',
    'test_nested_budget_caps_cumulative_wait_across_multiple_commands',
]:
    existing = set(threading.enumerate())
    token = hot._turn_budget.set(None)
    try:
        with pytest.MonkeyPatch.context() as mp:
            kwargs = {'monkeypatch': mp}
            if name != 'test_nested_budget_caps_cumulative_wait_across_multiple_commands':
                kwargs['completion_waits'] = test.completion_waits.__wrapped__(mp)
            if name == 'test_late_client_construction_never_pings_after_timeout':
                kwargs['redis_client'] = test.redis_client.__wrapped__(mp)
            getattr(test, name)(**kwargs)
            assert (threading.Event, threading.Thread, threading.Lock, time.monotonic) == originals
        assert hot.threading is threading and hot.time is time
        assert hot._turn_budget.get() is None
        workers = [t for t in threading.enumerate() if t not in existing and t.name == 'memory-redis']
        # Observe the bounded final thread unwind after the test releases the lock;
        # no cancellation, unblocking or production cleanup is added by this probe.
        before = time.monotonic()
        for thread in workers:
            thread.join(1)
        assert not any(thread.is_alive() for thread in workers)
        rows.append({'test': name, 'passed': True, 'restoredModuleBindings': True,
                     'sharedModuleAttributesUnchanged': True, 'turnBudgetReset': True,
                     'threadsFinishingAfterTestReturn': len(workers),
                     'finalUnwindObservationSeconds': time.monotonic() - before})
    finally:
        hot._turn_budget.reset(token)
out = {'reviewedTestSha256': hashlib.sha256((repo/'tests/test_memory_hot_store.py').read_bytes()).hexdigest(),
       'productionImport': hot.__file__, 'method': 'manual invocation of exact final test functions with actual pytest MonkeyPatch fixture cleanup; not a new gate or full-suite result', 'cases': rows}
Path('/private/tmp/codeloop-governance-20261024/hot-store-budget-diagnosis/independent-cleanup-proof.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
