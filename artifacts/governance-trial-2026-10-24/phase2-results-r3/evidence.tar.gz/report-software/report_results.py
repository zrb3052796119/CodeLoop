#!/usr/bin/env python3
"""Read-only descriptive reporter for the registered 16-task single/auto study.

No model, freeze, oracle, subprocess, sqlite or input-write operations. Report
files are created only in a new external output directory. No inference/tests
of statistical significance and no new success or mechanism gate.
"""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import hashlib
import importlib
import io
import json
import math
from pathlib import Path
import statistics
import sys
import zipfile

ARMS = ('single', 'auto')
STRATA = {'read': 5, 'write': 7, 'refactor': 4}
NUMERIC = ('modelCalls', 'failedCalls', 'inFlightCalls', 'unknownUsageCalls',
           'inputTokens', 'outputTokens', 'cacheReadTokens', 'knownTotalTokens',
           'delegationAttempts', 'actualLeafRuns', 'leafModelCalls', 'deliveredLeafResults',
           'successfulLeafRuns', 'readAnalysisLeafRuns', 'implementationLeafRuns',
           'deliveredWorkflowResults', 'admissionRejectedCount')
BOOLS = ('success', 'oracleSuccess', 'scopePassed', 'tokenUsageComplete',
         'cacheUsageComplete', 'usageComplete', 'generatedRegressionRequired',
         'regressionTestPassed', 'authorizedSourceChanged', 'collaborationExecuted',
         'collaborationProtocolSatisfied', 'currencyPriceKnown')
METRICS = ('totalTokens', 'inputTokens', 'outputTokens', 'cacheReadTokens',
           'modelCalls', 'durationSeconds', 'judgeSeconds', 'processSeconds')

class EvidenceError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise EvidenceError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def number(value, label, integer=False):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0
            and (not integer or int(value) == value), 'Invalid nonnegative number: ' + label)

class Reader:
    def __init__(self):
        self.hashes = {}
    def bytes(self, path):
        path = Path(path).resolve()
        data = path.read_bytes()
        sha = digest(data)
        require(str(path) not in self.hashes or self.hashes[str(path)] == sha,
                'Input changed while reading: ' + str(path))
        self.hashes[str(path)] = sha
        return data
    def json(self, path):
        return json.loads(self.bytes(path))
    def assert_stable(self):
        for name, sha in self.hashes.items():
            require(digest(Path(name).read_bytes()) == sha, 'Input changed during report: ' + name)


def validate_row(row, planned, category):
    identity = row.get('id')
    require(all(row.get(k) == planned[k] for k in ('id', 'case', 'repeat', 'arm')),
            'Frozen assignment mismatch: ' + str(identity))
    require(row.get('category') == category, 'Stratum mismatch: ' + str(identity))
    for field in BOOLS:
        # Read-only trials have no generated regression; the frozen runner emits
        # an explicit null. Preserve it as not applicable, never as False.
        if field == 'regressionTestPassed' and category == 'read' and field in row and row[field] is None:
            continue
        require(type(row.get(field)) is bool, 'Missing boolean: ' + str(identity) + '/' + field)
    for field in NUMERIC:
        number(row.get(field), field, integer=True)
    for field in ('durationSeconds', 'judgeSeconds', 'processSeconds'):
        number(row.get(field), field)
    require(row['knownTotalTokens'] == row['inputTokens'] + row['outputTokens'], 'Known token sum mismatch')
    if row.get('totalTokens') is not None:
        number(row['totalTokens'], 'totalTokens', integer=True)
    require(row['totalTokens'] == row['knownTotalTokens'] if row['tokenUsageComplete']
            else row['totalTokens'] is None, 'Unknown usage must not become a numeric total')
    require(row['unknownUsageCalls'] <= row['modelCalls'], 'Unknown call count exceeds physical calls')
    require(not row['tokenUsageComplete'] or row['unknownUsageCalls'] == 0, 'Complete tokens with unknown calls')
    require(not row['cacheUsageComplete'] or row['tokenUsageComplete'], 'Cache completeness exceeds token coverage')
    require(row['usageComplete'] == (row['cacheUsageComplete'] and row['tokenUsageComplete']), 'Usage flags disagree')
    require(row['cacheReadTokens'] <= row['inputTokens'], 'Cached tokens exceed inputs')
    require(row['failedCalls'] + row['inFlightCalls'] <= row['modelCalls'], 'Request status counts exceed physical calls')
    require(row['currencyPriceKnown'] is False and all(row.get(k) is None for k in
            ('estimatedCostUsd', 'estimatedCostCny', 'knownCostLowerBoundCny')), 'Unknown route price must remain null')
    needs_regression = category != 'read'
    require(row['generatedRegressionRequired'] == needs_regression, 'Changed preregistered regression requirement')
    success = row['oracleSuccess'] and row['scopePassed'] and (not needs_regression or
              (row['regressionTestPassed'] and row['authorizedSourceChanged']))
    require(row['success'] == success, 'Success disagrees with existing runner acceptance conjunction')
    require(not row.get('unauthorizedChanges') or not row['scopePassed'], 'Unauthorized write reported in successful scope')
    require(row['deliveredLeafResults'] <= row['actualLeafRuns'] <= row['leafModelCalls'] <= row['modelCalls'],
            'Invalid leaf/request count nesting')
    require(row['successfulLeafRuns'] <= row['actualLeafRuns'], 'Successful leaves exceed actual leaves')
    require(row['collaborationExecuted'] == (row['deliveredLeafResults'] > 0), 'Execution/delivery flag mismatch')
    interventions = row.get('interventions', {})
    for field in ('humanApprovalCount', 'humanCorrectionCount'):
        # Current runner records no independent human event stream.
        require(interventions.get(field) is None, 'Human count unsupported by current capture: ' + field)
    for field in ('permissionRequestEvents', 'permissionDecisionEvents'):
        if interventions.get(field) is not None:
            number(interventions[field], field, integer=True)
    if row['arm'] == 'single':
        require(not any(row[k] for k in ('delegationAttempts', 'actualLeafRuns', 'leafModelCalls',
                'deliveredLeafResults', 'collaborationExecuted')), 'Single arm delegated')


def validate_registered_cases(registered, design):
    require(len(design['cases']) == len(registered['cases']), 'Expanded case membership changed')
    for original, expanded in zip(registered['cases'], design['cases']):
        for key, value in original.items():
            if key != 'acceptance':
                require(expanded.get(key) == value, 'Expanded case contract changed: ' + original['id'] + '/' + key)
        # Rebuild changes only these two fields when relocating private oracles.
        for key, value in original['acceptance'].items():
            if key not in ('oraclePath', 'oracleSha256'):
                require(expanded['acceptance'].get(key) == value,
                        'Expanded acceptance changed: ' + original['id'] + '/' + key)



def validate_explicit_registration(reader, run, registered, design, manifest):
    """Bind the prepared runner inputs to a selected portable registration.

    Use the existing rebuild/prepare schema. The only oracle transformation
    allowed is its registered historical-source path relocation; no oracle runs.
    """
    require(design['studyId'] == registered['studyId'], 'Registered study identity mismatch')
    runtime, limits = registered['runtime'], registered['limits']
    require(manifest['temperature'] == runtime['temperature'], 'Frozen temperature differs from registration')
    require(manifest['roleTurnLimits'] == runtime['roleMaxTurns'], 'Frozen role limits differ from registration')
    frozen_limits = {key: limits[key] for key in (
        'maxTokens', 'maxModelCalls', 'maxCostUsd', 'wallSeconds',
        'requestTimeoutSeconds', 'idleTimeoutSeconds', 'connectTimeoutSeconds')}
    frozen_limits['maxOutputTokens'] = runtime['maxOutputTokens']
    require(manifest['limits'] == frozen_limits, 'Frozen limits differ from registration')
    require(manifest['externalJudgeSeconds'] == limits['externalJudgeSeconds'],
            'Frozen judge limit differs from registration')
    tasks = reader.json(run / 'tasks.json')
    cases = {case['id']: case for case in registered['cases']}
    expanded = {case['id']: case for case in design['cases']}
    require(not tasks.get('shared_files') and len(tasks['cases']) == len(cases)
            and {task['id'] for task in tasks['cases']} == set(cases),
            'Prepared task membership differs from registration')
    expected_support = {}
    for task in tasks['cases']:
        identity = task['id']
        case, prepared = cases[identity], expanded[identity]
        require(digest(task['prompt'].encode()) == case['promptSha256']
                and task['prompt'] == prepared['prompt'], 'Prepared prompt differs from registration: ' + identity)
        require(all(task[key] == case[key] for key in ('category', 'authorized_paths')),
                'Prepared task contract differs from registration: ' + identity)
        needs_regression = case['category'] != 'read'
        argv = ['python3', '-m', 'pytest', '-q', 'tests/test_eval_regression.py'] if needs_regression else []
        require(task['generatedRegressionRequired'] is needs_regression and task['verification_argv'] == argv,
                'Prepared verification policy differs from registration: ' + identity)
        inventory = {name: digest(content.encode()) for name, content in task['files'].items()}
        tree = case['sourceTrees']['baseline']
        require(inventory == prepared['sourceInventories']['baseline']
                and len(inventory) == tree['pythonFileCount']
                and digest(json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode())
                    == tree['pythonInventorySha256'], 'Prepared baseline differs from registration: ' + identity)
        oracle = task['oracle_source']
        dependencies = prepared.get('oracleDependencyDirectories', {})
        for index, (directory, dependency_inventory) in enumerate(dependencies.items()):
            target = run / 'oracle-support' / identity / str(index)
            oracle = oracle.replace(repr(str(target)), repr(directory))
            expected_support.update({(target / name).relative_to(run).as_posix(): sha
                                     for name, sha in dependency_inventory.items()})
            parent_tree = case['sourceTrees']['historicalParent']
            require(len(dependency_inventory) == parent_tree['pythonFileCount']
                    and digest(json.dumps(dependency_inventory, sort_keys=True, separators=(',', ':')).encode())
                        == parent_tree['pythonInventorySha256'],
                    'Oracle support inventory differs from registration: ' + identity)
        require(digest(oracle.encode()) == prepared['acceptance']['oracleSha256'],
                'Prepared oracle differs from expanded design: ' + identity)
        for directory in dependencies:
            oracle = oracle.replace(repr(directory), repr('@@ORACLE_PARENT@@'))
        require(digest(oracle.encode()) == case['acceptance']['oracleSha256'],
                'Prepared oracle differs from registration: ' + identity)
    require(reader.json(run / 'oracle-support-hashes.json') == expected_support,
            'Oracle support manifest differs from registration')


def verify_protocol_code(reader, archive, repo, synthetic):
    names = ('three_arm_protocol.py', 'evaluation_transport.py')
    current = {name: reader.bytes(repo / 'scripts' / name) for name in names}
    if not synthetic:
        with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
            for name, content in current.items():
                require(bundle.read('scripts/' + name) == content,
                        'Current reporting dependency differs from frozen harness: ' + name)


def load_run(run, registration, repo, synthetic=False, *, explicit_registration=False):
    reader = Reader()
    registered = reader.json(registration)
    manifest = reader.json(run / 'manifest.json')
    design = reader.json(run / 'study-design.json')
    results = reader.json(run / 'results.json')
    require(bool(results.get('synthetic', False)) == synthetic, 'Synthetic fixture marker/CLI mismatch')
    require(registered['arms'] == list(ARMS) and registered['repeats'] == 1, 'Wrong registered design')
    categories = {c['id']: c['category'] for c in registered['cases']}
    require(len(registered['cases']) == len(categories) == 16 and Counter(categories.values()) == STRATA,
            'Expected 5 read/7 write/4 refactor cases')
    schedule = registered['schedule']
    require(len(schedule) == 32 and len({t['id'] for t in schedule}) == 32, 'Duplicate or incomplete registered schedule')
    require(Counter((t['case'], t['arm'], t['repeat']) for t in schedule) ==
            Counter((case, arm, 1) for case in categories for arm in ARMS), 'Invalid paired cells')
    require(design['schedule'] == manifest['schedule'] == schedule, 'Schedule changed after registration')
    require(all(design[key] == registered[key] for key in ('runtime', 'limits', 'constraints', 'outcomes', 'exclusions')),
            'Expanded study conditions differ from registration')
    require(manifest['arms'] == design['arms'] == list(ARMS) and manifest['repeats'] == 1, 'Frozen arms/repeats differ')
    require(isinstance(registered['runtime']['model'], str) and registered['runtime']['model']
            and manifest['model'] == registered['runtime']['model']
            and registered['pricing']['known'] is False and manifest['price'].get('known') is False,
            'Frozen model/price differs from registration')
    validate_registered_cases(registered, design)
    require(design['portableManifestSha256'] == digest(reader.bytes(registration)), 'Registration SHA mismatch')
    require(manifest['studyDesignSha256'] == digest(reader.bytes(run / 'study-design.json')), 'Study SHA mismatch')
    for field, name in [('taskSha256', 'tasks.json'), ('analysisPlanSha256', 'analysis-plan.md'),
                        ('oracleSupportSha256', 'oracle-support-hashes.json'),
                        ('frozenCodeArchiveSha256', 'frozen-code.zip')]:
        require(manifest[field] == digest(reader.bytes(run / name)), 'Frozen input SHA mismatch: ' + name)
    if explicit_registration:
        validate_explicit_registration(reader, run, registered, design, manifest)
    require(results['manifestSha256'] == digest(reader.bytes(run / 'manifest.json')), 'Result/manifest SHA mismatch')
    require(results['expectedTrials'] == 32, 'Result denominator changed')
    expected = {t['id']: t for t in schedule}
    found = {}
    for row in results['trials']:
        require(row.get('id') in expected and row['id'] not in found, 'Unknown/duplicate result trial')
        validate_row(row, expected[row['id']], categories[row['case']])
        require(reader.json(run / 'trials' / (row['id'] + '.json')) == row, 'Checkpoint differs from trial result')
        found[row['id']] = row
    disk_ids = {p.stem for p in (run / 'trials').glob('*.json')}
    require(disk_ids == set(found), 'Trial files/checkpoint differ; retry after checkpoint finishes')
    # Reuse existing pure host-evidence logic; no runner/runtime/model setup.
    verify_protocol_code(reader, reader.bytes(run / 'frozen-code.zip'), repo, synthetic)
    if not synthetic:
        # The protocol may lazily parse task-result messages with production code.
        production = b''.join(path.relative_to(repo).as_posix().encode() + b'\0' + reader.bytes(path)
                              for path in sorted((repo / 'minicode').rglob('*.py')))
        require(digest(production) == manifest['productionSha256'], 'Reporting repository differs from frozen production')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(repo))
    sys.path.insert(0, str(repo / 'scripts'))
    protocol = importlib.import_module('three_arm_protocol')
    require(Path(protocol.__file__).resolve() == repo / 'scripts/three_arm_protocol.py', 'Wrong imported protocol source')
    require(Path(sys.modules['evaluation_transport'].__file__).resolve() == repo / 'scripts/evaluation_transport.py',
            'Wrong imported protocol dependency')
    role_details = {}
    for identity, row in found.items():
        root = run / 'private' / identity
        paths = [root / 'collaboration.json', root / 'transport-summary.json']
        if not all(path.is_file() for path in paths):
            role_details[identity] = {'available': False, 'reason': 'missing private role/transport evidence'}
            continue
        collaboration, transport = (reader.json(path) for path in paths)
        records, requests = collaboration['runs'], transport['requests']
        messages = reader.json(root / 'transcript.json') if (root / 'transcript.json').is_file() else []
        metrics = protocol.collaboration_metrics(records, requests, messages, collaboration.get('deliveredIds', []))
        require(all(row.get(k) == v for k, v in metrics.items()), 'Collaboration row/private evidence mismatch: ' + identity)
        require(transport['started'] == len(requests) == row['modelCalls'], 'Physical request count mismatch: ' + identity)
        require(len({r['call'] for r in requests}) == len(requests), 'Duplicate physical call receipt')
        role_details[identity] = {
            'available': True,
            'recordedContainers': sum(bool(r.get('isContainer')) for r in records),
            'physicalCallsByRecordedRole': dict(Counter(r.get('role') or 'unattributed' for r in requests)),
            'leafRoles': {role: protocol.collaboration_metrics(
                [r for r in records if r.get('isContainer') or (r.get('role') or 'unattributed') == role], requests,
                messages, collaboration.get('deliveredIds', []))
                for role in sorted({r.get('role') or 'unattributed' for r in records if not r.get('isContainer')})},
        }
    return reader, registered, manifest, [found.get(t['id']) for t in schedule], role_details


def describe(values):
    return {'n': len(values), 'sum': sum(values) if values else None,
            'mean': statistics.mean(values) if values else None,
            'median': statistics.median(values) if values else None,
            'sd': statistics.stdev(values) if len(values) > 1 else None,
            'min': min(values) if values else None, 'max': max(values) if values else None}

def exact_metric(row, metric):
    if row is None:
        return None
    if metric in ('totalTokens', 'inputTokens', 'outputTokens') and not row['tokenUsageComplete']:
        return None
    if metric == 'cacheReadTokens' and not row['cacheUsageComplete']:
        return None
    return row.get(metric)

def metric_summary(rows, metric):
    values = [exact_metric(row, metric) for row in rows]
    known = [v for v in values if v is not None]
    lower_key = 'knownTotalTokens' if metric == 'totalTokens' else metric
    lower = sum(row.get(lower_key, 0) for row in rows if row is not None)
    return {'plannedN': len(rows), 'knownN': len(known), 'unknownN': len(rows) - len(known),
            'total': sum(known) if rows and len(known) == len(rows) else None,
            'knownLowerBoundSum': lower if rows else None,
            'knownOnlyDescription': describe(known), 'complete': bool(rows) and len(known) == len(rows)}

def arm_summary(rows):
    observed = [r for r in rows if r is not None]
    successes = [r for r in observed if r['success']]
    pending = len(rows) - len(observed)
    human = {}
    for key in ('humanApprovalCount', 'humanCorrectionCount', 'permissionRequestEvents', 'permissionDecisionEvents'):
        values = [(r.get('interventions', {}).get(key) if r else None) for r in rows]
        known = [v for v in values if v is not None]
        human[key] = {'total': sum(known) if rows and len(known) == len(rows) else None,
                      'knownN': len(known), 'unknownN': len(rows) - len(known),
                      'knownEventSubtotal': sum(known) if known else None}
    policies = [r.get('hostPolicyApprovalRecords') if r else None for r in rows]
    policy_records = [item for records in policies if records is not None for item in records]
    return {'plannedN': len(rows), 'observedN': len(observed), 'missingN': pending,
            'successes': len(successes), 'failures': len(observed) - len(successes),
            'successRate': len(successes) / len(rows) if rows and not pending else None,
            'successRateBoundsIfIncomplete': [len(successes) / len(rows), (len(successes) + pending) / len(rows)] if rows and pending else None,
            'allTrials': {k: metric_summary(rows, k) for k in METRICS},
            'observedSuccessfulTrials': {k: metric_summary(successes, k) for k in METRICS},
            'successSubsetPopulationComplete': not pending,
            'unknownUsageCallsObserved': sum(r['unknownUsageCalls'] for r in observed),
            'failedPhysicalCallsObserved': sum(r['failedCalls'] for r in observed),
            'inFlightPhysicalCallsObserved': sum(r['inFlightCalls'] for r in observed),
            'operationalErrorClassesAllObserved': dict(Counter(r['errorClass'] for r in observed if r.get('errorClass'))),
            'unsuccessfulTrialReasons': dict(Counter(r.get('oracleErrorClass') or r.get('errorClass') or 'AcceptanceOrScopeFailure'
                                                  for r in observed if not r['success'])),
            'scopeFailuresObserved': sum(not r['scopePassed'] for r in observed),
            'acceptanceFailuresObserved': {
                'oracle': sum(not r['oracleSuccess'] for r in observed),
                'scope': sum(not r['scopePassed'] for r in observed),
                'requiredRegression': sum(r['generatedRegressionRequired'] and not r['regressionTestPassed'] for r in observed),
                'requiredSourceChange': sum(r['generatedRegressionRequired'] and not r['authorizedSourceChanged'] for r in observed)},
            'monetaryCostUsd': None, 'monetaryCostCny': None,
            'interventions': human,
            'hostPolicyDecisions': {'availableTrials': sum(p is not None for p in policies),
                'decisionsObserved': dict(Counter(r['decision'] for r in policy_records))},
            'delegation': {**{k: sum(r[k] for r in observed) for k in (
                'delegationAttempts', 'actualLeafRuns', 'leafModelCalls', 'deliveredLeafResults',
                'successfulLeafRuns', 'readAnalysisLeafRuns', 'implementationLeafRuns', 'deliveredWorkflowResults')},
                'trialsWithAttempt': sum(r['delegationAttempts'] > 0 for r in observed),
                'trialsWithActualDeliveredLeaf': sum(r['collaborationExecuted'] for r in observed)}}


def paired(rows_by_case, category=None, common_success=False):
    pairs = [(case, arms) for case, arms in rows_by_case.items()
             if category is None or arms['category'] == category]
    if common_success:
        pairs = [(case, a) for case, a in pairs if all(a.get(arm) and a[arm]['success'] for arm in ARMS)]
    counts = Counter()
    for _, arms in pairs:
        if any(arms.get(arm) is None for arm in ARMS):
            counts['missingPair'] += 1
        else:
            a, b = arms['single']['success'], arms['auto']['success']
            counts['bothSuccess' if a and b else 'singleOnly' if a else 'autoOnly' if b else 'bothFailure'] += 1
    metrics = {}
    for metric in ('totalTokens', 'modelCalls', 'durationSeconds'):
        deltas = []
        for _, arms in pairs:
            a, b = (exact_metric(arms.get(arm), metric) for arm in ARMS)
            if a is not None and b is not None:
                deltas.append(b - a)
        metrics[metric] = {'pairedN': len(deltas), 'plannedPairN': len(pairs),
                           'meanAutoMinusSingle': statistics.mean(deltas) if pairs and len(deltas) == len(pairs) else None,
                           'knownPairedDescription': describe(deltas)}
    return {'pairN': len(pairs), 'successContingency': {k: counts[k] for k in
             ('bothSuccess', 'singleOnly', 'autoOnly', 'bothFailure', 'missingPair')},
            'successRateDeltaAutoMinusSingle': (counts['autoOnly'] - counts['singleOnly']) / len(pairs)
                if pairs and not counts['missingPair'] else None,
            'metrics': metrics, 'caseIds': [case for case, _ in pairs]}


def summarize(registered, rows, role_details, synthetic):
    cases = {c['id']: {'category': c['category']} for c in registered['cases']}
    for trial, row in zip(registered['schedule'], rows):
        cases[trial['case']][trial['arm']] = row
    arms = {arm: arm_summary([cases[c][arm] for c in cases]) for arm in ARMS}
    categories = {category: {arm: arm_summary([a[arm] for a in cases.values() if a['category'] == category])
                            for arm in ARMS} for category in STRATA}
    detailed_by_arm = {}
    for arm in ARMS:
        assigned = [t for t in registered['schedule'] if t['arm'] == arm]
        details = [role_details[t['id']] for t in assigned if role_details.get(t['id'], {}).get('available')]
        physical, leaf = Counter(), {}
        for detail in details:
            physical.update(detail['physicalCallsByRecordedRole'])
            for role, metrics in detail['leafRoles'].items():
                leaf.setdefault(role, Counter()).update({key: metrics[key] for key in
                    ('actualLeafRuns', 'leafModelCalls', 'successfulLeafRuns', 'deliveredLeafResults')})
        detailed_by_arm[arm] = {'availableTrials': len(details), 'plannedTrials': len(assigned),
            'unknownTrials': len(assigned) - len(details), 'complete': len(details) == len(assigned),
            'physicalCallsByRecordedRoleObserved': dict(physical),
            'leafRolesObserved': {role: dict(counts) for role, counts in leaf.items()}}
    return {'schemaVersion': 1, 'synthetic': synthetic,
            'status': 'SYNTHETIC_SELFTEST_NOT_EXPERIMENT' if synthetic else
                      'complete_descriptive' if all(r is not None for r in rows) else 'incomplete_no_full_comparison',
            'expectedTrials': 32, 'observedTrials': sum(r is not None for r in rows),
            'arms': arms, 'categories': categories,
            'pairedAllTasks': paired(cases),
            'pairedByCategory': {c: paired(cases, c) for c in STRATA},
            'pairedCommonSuccessOnly': paired(cases, common_success=True),
            'actualRoleEvidence': role_details,
            'actualRoleEvidenceByArm': detailed_by_arm,
            'trialStatus': [{'id': t['id'], 'case': t['case'], 'arm': t['arm'],
                'category': cases[t['case']]['category'], 'success': row['success'] if row else None,
                'missing': row is None, 'totalTokens': exact_metric(row, 'totalTokens'),
                'knownTotalTokens': row['knownTotalTokens'] if row else None,
                'modelCalls': row['modelCalls'] if row else None,
                'durationSeconds': row['durationSeconds'] if row else None,
                **{key: row.get(key) if row else None for key in
                   ('errorClass', 'oracleErrorClass', 'oracleSuccess', 'scopePassed',
                    'generatedRegressionRequired', 'regressionTestPassed', 'authorizedSourceChanged',
                    'tokenUsageComplete', 'cacheUsageComplete', 'unknownUsageCalls',
                    'failedCalls', 'inFlightCalls', 'delegationAttempts', 'actualLeafRuns', 'deliveredLeafResults')}}
                for t, row in zip(registered['schedule'], rows)],
            'interpretation': [
                'Descriptive paired historical-task comparison only; no p-values, confidence intervals or generalized winner claim.',
                'All trials retain failures/timeouts and unknown usage. Missing trials are unknown, not failure or zero.',
                'Arm-specific successful subsets may contain different tasks; common-success pairs are supplemental and selected on outcome.',
                'Known input/output/cache counts are subtotals when usage is incomplete; cache tokens are part of input, never added twice.',
                'durationSeconds is agent wall time; processSeconds and judgeSeconds are separate and must not be double-counted.',
                'Host policy approval/permission events are not human approvals/corrections; current human counts and route money remain null.',
                'Task attempts, physical leaf execution, successful leaves and host-delivered results are distinct. Auto need not delegate to succeed.',
                'Tasks share repository/history and each cell has one run; no independent-task inference or memory-effect claim.']}


def fmt(value):
    return '未知/不可合计' if value is None else f'{value:,.2f}'.removesuffix('.00')

def render(summary):
    title = 'SYNTHETIC SELFTEST — 不是实验结果' if summary['synthetic'] else '真实历史任务比较：描述性结果'
    arms = summary['arms']
    lines = ['# ' + title, '', f"状态：{summary['status']}；记录 {summary['observedTrials']}/32 cells；16 对任务、每 cell 1 次。", '',
             '| 层次 | single 成功/已完成/计划 | auto 成功/已完成/计划 | auto−single 成功百分点 |',
             '| --- | ---: | ---: | ---: |']
    for category, groups in [('全部', arms), *summary['categories'].items()]:
        vals = [f"{groups[a]['successes']}/{groups[a]['observedN']}/{groups[a]['plannedN']}" for a in ARMS]
        pair = summary['pairedAllTasks'] if category == '全部' else summary['pairedByCategory'][category]
        delta = pair['successRateDeltaAutoMinusSingle']
        lines.append(f"| {category} | {vals[0]} | {vals[1]} | {fmt(None if delta is None else delta * 100)} |")
    lines += ['', '| 指标：合计；已知/样本数 | single 全部 | auto 全部 | single 成功子集 | auto 成功子集 |',
              '| --- | ---: | ---: | ---: | ---: |']
    for key, label in [('totalTokens', '输入+输出 token'), ('modelCalls', '物理调用'), ('durationSeconds', 'agent 墙钟秒')]:
        cells = []
        for subset, arm in [('allTrials', 'single'), ('allTrials', 'auto'),
                            ('observedSuccessfulTrials', 'single'), ('observedSuccessfulTrials', 'auto')]:
            m = arms[arm][subset][key]
            cells.append(f"{fmt(m['total'])}；{m['knownN']}/{m['plannedN']}" +
                         (f"，已知小计≥{fmt(m['knownLowerBoundSum'])}" if m['unknownN'] else ''))
        lines.append('| ' + label + ' | ' + ' | '.join(cells) + ' |')
    pair = summary['pairedAllTasks']
    lines += ['', f"配对成功分布：{json.dumps(pair['successContingency'], ensure_ascii=False)}。", 
              '全体配对开销差（auto−single）：' + '；'.join(f"{k}={fmt(v['meanAutoMinusSingle'])}（{v['pairedN']}/{v['plannedPairN']} 对已知）" for k,v in pair['metrics'].items()) + '。',
              f"两组均成功子集：{summary['pairedCommonSuccessOnly']['pairN']} 对；按结果筛选，仅作补充，详见 summary.json。", '',
              '| 委派证据/缺失 | single | auto |', '| --- | ---: | ---: |']
    for key in ('trialsWithAttempt', 'trialsWithActualDeliveredLeaf', 'actualLeafRuns', 'deliveredLeafResults', 'leafModelCalls'):
        lines.append(f"| {key} | {arms['single']['delegation'][key]} | {arms['auto']['delegation'][key]} |")
    available = sum(v['available'] for v in summary['actualRoleEvidence'].values())
    lines += ['', f"详细角色证据可用 {available}/{summary['observedTrials']} cells；逐角色物理调用、完成执行及交付见 summary.json，未把 task 请求当作协作。", 
              '实际角色物理调用（仅可用证据小计）：' + '；'.join(
                  f"{arm}={json.dumps(summary['actualRoleEvidenceByArm'][arm]['physicalCallsByRecordedRoleObserved'], ensure_ascii=False)}"
                  for arm in ARMS) + '。',
              f"未知 usage 调用 single={arms['single']['unknownUsageCallsObserved']}、auto={arms['auto']['unknownUsageCallsObserved']}；货币费用与人工批准/纠正次数均未知。宿主策略决定及 permission 事件另计。",
              '失败和超时仍计入全部试次；成功子集按各组成功筛选、任务可能不同。未知 token 不插补零，cache 已包含于 input；agent 墙钟不含独立裁判时间，process/judge 时间另外保留。',
              '这是相关历史任务、单次采样的内部描述；没有显著性/置信区间、普遍优劣或记忆增益结论。完整数值、每 cell 缺失状态、失败类别及输入 SHA 在 summary.json / trials.csv。', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--registration', type=Path,
                        help='Explicit portable registration manifest; never falls back when supplied')
    parser.add_argument('--synthetic', action='store_true', help='Only for explicitly marked self-test fixtures')
    args = parser.parse_args()
    run, repo, output = args.run.resolve(), args.repo.resolve(), args.output.resolve()
    require(not output.exists(), 'Output must be a new directory')
    require(not output.is_relative_to(run) and not output.is_relative_to(repo), 'Report output must be outside run and repository')
    registration = (args.registration.resolve() if args.registration is not None else
                    repo / 'artifacts/governance-trial-2026-10-24/phase2-preparation/manifest.json')
    reader, registered, manifest, rows, roles = load_run(
        run, registration, repo, args.synthetic, explicit_registration=args.registration is not None)
    summary = summarize(registered, rows, roles, args.synthetic)
    summary['provenance'] = {'inputSha256': reader.hashes, 'reporterSha256': digest(Path(__file__).read_bytes()),
                             'registrationPath': str(registration),
                             'registrationSha256': reader.hashes[str(registration.resolve())],
                             'registrationSelection': 'explicit' if args.registration is not None else 'legacy-default',
                             'model': manifest['model'], 'productionSha256': manifest.get('productionSha256'),
                             'harnessSha256': manifest.get('harnessSha256'), 'routeSha256': manifest.get('routeSha256')}
    reader.assert_stable()
    output.mkdir(parents=True)
    (output / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    (output / 'report.md').write_text(render(summary))
    with (output / 'trials.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary['trialStatus'][0]))
        writer.writeheader();writer.writerows(summary['trialStatus'])
    print(json.dumps({'status': summary['status'], 'observedTrials': summary['observedTrials'], 'output': str(output)}))

if __name__ == '__main__':
    try:
        main()
    except (EvidenceError, KeyError, OSError, ValueError) as error:
        print('Report input error: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
