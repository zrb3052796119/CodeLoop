# R3 最终报告只读复核

**未发现统计或分母阻塞项；最终解释应补清协作证据与未知 token 的边界。** 本次独立读取报告、32 个原始 trial/result、全部 transport summary，以及保留 transcript 的消息头/空 subagent 数组；未重跑 reporter、oracle、模型或测试，未改报告/试次，也未在审阅记录复制 provider/消息正文。

- 固定 16 对、32 cells 与原顺序一致，trial/result/CSV/summary 对应一致。成功合取、分层、成功子集、全体配对和 7 对共同成功均可从原行复算：single 8/16，auto 7/16；共同成功 7、single-only 1、auto-only 0、共同失败 8。
- **完整 token 总量仍未知。** single 的 13 个完整 cell 合计 10,997,669，auto 的 14 个完整 cell 合计 12,321,139；报告的 ≥55,261,208 / ≥39,553,249 是包含不完整 cell 中已知 provider usage 的全组下界，不能误叫“13/14 个完整任务小计”。两组各 3 个未知用量物理请求，分别分布于 3 / 2 个 cell；没有补零或把保守预算 charge 冒充 usage。全体配对 token 差为 null，13 对已知只是补充描述。不能由两个下界之差声称节省 token/费用。
- 物理调用 1,223 / 864、agent 墙钟 13,148.7676 / 13,307.4122 秒与原记录一致。缓存已含在 input；judge/process 不应重复计入。价格与人工批准/纠正保持 null。各组成功子集和共同成功子集不等于全体。

## 为什么角色详证是 0/32，零委派又能说到哪一步

原报告 `actualRoleEvidence.available=false` 的直接原因是 **32 个 collaboration.json 均不存在**，并非 transport 记录都缺失。冻结 `three_arm_protocol.py` 的 CollaborationEvidence 构造/进入不写空文件，只在实际 task 入口或交付确认时保存；reporter:265–268 要两文件齐备才执行详细角色复核，因此原 0/32 状态必须保留。

本次另核 32 份 transport summary：**2,087 个唯一物理请求全部 role=main、subagentId=null，完成回包记录中的 task 调用数为 0**，这些计数与原 rows 一致。31 份保留 transcript 没有 task 结果消息头，31 份 subagents 数组为空；`refactor-workspace-r1-auto` 的 HardTimeout 导致这两份最终文件缺失，但其 durable transport summary 仍可核。无 ledgerDamaged/recoveryEvidenceErrors；32 份 cleanup 均 complete。相关 runner/protocol/transport 源字节已与冻结 ZIP 对照一致。

建议写：**“在本轮冻结宿主/传输观测范围内，32 个 cell 均未记录到 task 委派请求或叶角色物理模型调用；详细协作链文件未生成，原 reporter 的角色详证覆盖为 0/32。本次结果未包含已观察到的多 agent 执行。”** 这由补充的直接 transport 核对支持，不是仅凭零值表或缺文件推论。不要扩大成对未受观测活动、模型意图或完整私有交付链的认证，也不能把零委派自动判失败或改成强制委派后补跑。

## 事实对结论的约束

可以陈述 auto 记录的物理请求较少、总 agent 墙钟略多、成功少一题；不能称为协作收益/劣势，不能比较未知总 token 的精确降幅，不能给记忆增益或普遍赢家结论。相关历史题、每 cell 一次、P0+固定 transport 执行且无 memory 消融；这不直接实测当前 main 产品默认档位或 P1/PTY 改动。维持现有默认和机制冻结，是与证据相容的维护决策；不必为了结束治理制造新默认或收益结论。

详细计数、原报告 SHA 与本次只读范围见 `r3-report-readonly-review.json`；无正文的逐 cell transport 计数见 `r3-report-readonly-input-counters.json`，算术/文件绑定见 `r3-report-readonly-arithmetic.json`。原始报告仍保持 reporter v3 输出，不通过修改它消除缺失状态。
