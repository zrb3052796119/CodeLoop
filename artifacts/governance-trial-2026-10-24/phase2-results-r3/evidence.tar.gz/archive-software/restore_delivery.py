#!/usr/bin/env python3
"""DRAFT pure archive restorer. Never import/execute restored Python or oracles.

Restore inputs or one named observed snapshot into a new directory. Symlinks
and special files remain metadata; credentials/cache were never archived.
"""
import argparse
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(condition, message):
    if not condition:
        raise ValueError(message)


def safe(name):
    path = PurePosixPath(name)
    need(name and not path.is_absolute() and "\\" not in name and ".." not in path.parts
         and path.as_posix() == name, "Unsafe path")
    return path


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--inputs", action="store_true")
    parser.add_argument("--trial")
    parser.add_argument("--snapshot", choices=("agent-workspace-observed-after-judgement", "oracle-retained-snapshot", "regression-retained-snapshot"))
    args = parser.parse_args()
    need(args.inputs != bool(args.trial and args.snapshot), "Choose inputs OR a trial and snapshot")
    output = args.output.resolve()
    need(not output.exists(), "Output must be new")
    manifest = json.loads((args.package / "manifest.json").read_text())
    archive_bytes = (args.package / manifest["archive"]).read_bytes()
    need(sha(archive_bytes) == manifest["archiveSha256"], "Archive SHA mismatch")
    expected = {entry["path"]: entry for entry in manifest["entries"]}
    payload = {}
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
        for member in archive:
            safe(member.name)
            need(member.isfile() and member.name not in payload and member.name in expected, "Unexpected member")
            data = archive.extractfile(member).read()
            need(len(data) == expected[member.name]["bytes"] and sha(data) == expected[member.name]["sha256"], "Member SHA mismatch")
            payload[member.name] = data
    need(set(payload) == set(expected), "Missing member")
    objects = json.loads(payload["shared/objects-index.json"])
    with zipfile.ZipFile(io.BytesIO(payload["run/frozen-code.zip"])) as frozen:
        def get(checksum):
            item = objects[checksum]
            safe(item["member"])
            data = frozen.read(item["member"]) if item["kind"] == "frozen-zip-member" else payload[item["member"]]
            need(sha(data) == checksum and len(data) == item["bytes"], "Object mismatch")
            return data

        output.mkdir(parents=True)
        def write(name, data, mode=0o600):
            path = output.joinpath(*safe(name).parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            need(not path.exists() and not path.is_symlink(), "Duplicate restored target")
            path.write_bytes(data)
            path.chmod(mode & 0o777)  # Never restore setuid/setgid bits.
            need(path.read_bytes() == data, "Write mismatch")

        if args.inputs:
            tasks = json.loads(payload["shared/tasks-template.json"])
            tasks["shared_files"] = {name: get(ref["objectSha256"]).decode() for name, ref in tasks.get("shared_files", {}).items()}
            for case in tasks["cases"]:
                case["files"] = {name: get(ref["objectSha256"]).decode() for name, ref in case["files"].items()}
                case["oracle_source"] = get(case["oracle_source"]["objectSha256"]).decode()
            raw = encode(tasks)
            need(sha(raw) == json.loads(payload["run/manifest.json"])["taskSha256"], "Original task bytes not restored")
            write("tasks.json", raw)
            for name in ("manifest.json", "study-design.json", "analysis-plan.md", "oracle-support-hashes.json", "frozen-code.zip"):
                write(name, payload["run/" + name])
            for name, checksum in json.loads(payload["shared/oracle-support.json"]).items():
                write(name, get(checksum))
            write("registration.json", payload["registration/manifest.json"])
            print(json.dumps({"restored": "original input bytes", "taskSha256": sha(raw),
                              "executed": False, "pathRelocation": "Not performed; historical absolute paths remain original evidence."}))
            return
        safe(args.trial)
        snapshot = json.loads(payload["records/" + args.trial + "/snapshots/" + args.snapshot + ".json"])
        need(snapshot["available"], "Snapshot was not retained; do not invent it")
        baseline = json.loads(payload["shared/baselines.json"])[snapshot["caseId"]]
        current = {name: {"kind": "file", "sha256": checksum, "mode": snapshot["unchangedFileModes"][name]}
                   for name, checksum in baseline.items() if name not in snapshot["deleted"] and name not in snapshot["changes"]}
        current.update(deepcopy(snapshot["changes"]))
        need(sha(json.dumps(current, sort_keys=True, separators=(",", ":")).encode()) == snapshot["inventorySha256"], "Snapshot inventory mismatch")
        nonmaterialized = {}
        for name, item in current.items():
            safe(name)
            if item["kind"] == "file":
                write("workspace/" + name, get(item["sha256"]), item["mode"])
            else:
                nonmaterialized[name] = item
        write("restoration.json", encode({"trialId": args.trial, "snapshot": args.snapshot,
              "inventorySha256": snapshot["inventorySha256"], "nonmaterialized": nonmaterialized,
              "excluded": snapshot["excluded"], "executed": False,
              "boundary": "Included regular-file bytes; links/special/private/cache entries are not recreated. Observed snapshot, not inferred finish-time state."}))
        print(json.dumps({"trialId": args.trial, "snapshot": args.snapshot, "restoredRegularFiles": sum(v["kind"] == "file" for v in current.values()), "executed": False}))


if __name__ == "__main__":
    main()
