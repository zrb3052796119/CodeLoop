#!/usr/bin/env python3
"""DRAFT: manual post-report archiver; never run against an active experiment.

No runtime imports, oracle, reporter, model, shell, SQLite, network, or Git calls.
inventory/build both require an existing non-synthetic complete 32-cell report.
Publication review concerns disclosure only; it never changes trial acceptance.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import tempfile
import zipfile

VERSION = "r3-results-archive-draft-v2-not-executed"
FORBIDDEN_PARTS = {".git", ".aws", ".ssh", ".gnupg", ".venv", "venv", "HOME",
                   "home", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                   ".minicode", ".mini-code", ".mini-code-memory", ".mini-code-memory-local",
                   ".mini-code-session-memory", ".mini-code-tool-results",
                   ".codex", ".claude", ".cache", ".config", ".local", "node_modules"}
FORBIDDEN_NAMES = {".env", "response.txt", "transcript.json", "calls.jsonl", "process.log",
                   "credentials", "credentials.json", ".netrc", ".npmrc", "config.env",
                   ".minicode-memory-authority.lock"}
SECRET_PATTERNS = (rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
                   rb"\bsk-[A-Za-z0-9_-]{24,}",
                   rb"(?i)Authorization\s*[:=]\s*[\"']?Bearer\s+[A-Za-z0-9_.-]{24,}")
REQUEST_KEYS = ("call", "agentType", "role", "actorId", "subagentId", "model", "routeSha256",
                "estimatedInputTokens", "maxOutputTokens", "event", "reservedTokens",
                "startedEpoch", "firstByteSeconds", "ttftSeconds", "firstContentSeconds",
                "lastEventSeconds", "lastByteSeconds", "streamDone", "headersSeconds",
                "httpStatus", "streamFinishReason", "seconds", "chargedTokens", "errorClass")
USAGE_KEYS = ("source", "input_tokens", "output_tokens", "cache_read_tokens")
TRANSPORT_KEYS = ("started", "completed", "failed", "inFlight", "admissionRejectedCount",
                  "admissionRejectedByReason", "providerUsageCalls", "unknownUsageCalls",
                  "usageComplete", "inputTokensKnown", "outputTokensKnown", "cacheReadTokensKnown",
                  "cacheUsageComplete", "chargedTokens", "tokenBudgetSemantics")
REJECTION_KEYS = ("rejection", "actorId", "subagentId", "role", "agentType", "model",
                  "parentToolOperationId", "routeSha256", "event", "reason", "rejectedEpoch",
                  "reservedTokens", "currentRequests", "currentChargedTokens", "maxModelCalls",
                  "maxTotalTokens", "deadlineEpoch", "estimatedInputTokens", "maxOutputTokens")
COLLAB_KEYS = ("subagentId", "agentType", "role", "startedEpoch", "isContainer",
               "parentSubagentId", "returnedEpoch", "returned", "toolOk", "resultSha256",
               "deliveredEpoch", "deliveryEvidence", "errorClass")
EVENT_KEYS = ("schemaVersion", "eventId", "sequence", "timestamp", "workspaceId",
              "sessionId", "runId", "type", "step")
EVENT_PAYLOAD_IDS = ("status", "outcome", "role", "toolName", "operationId", "subagentId",
                     "reviewId", "executorId", "errorClass", "resultType", "patchDigest",
                     "candidateDigest", "checkId")
EVENT_PAYLOAD_VALUES = ("attempt", "isError", "durationSeconds", "exitCode", "modelCalls",
                        "inputTokens", "outputTokens", "totalTokens")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def relative(name):
    require(isinstance(name, str) and "\\" not in name, "Invalid POSIX member")
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and all(p not in ("", ".", "..") for p in path.parts)
            and path.as_posix() == name, "Unsafe member")
    return path


def excluded(name):
    path = relative(name)
    return (bool(set(path.parts) & FORBIDDEN_PARTS) or path.name in FORBIDDEN_NAMES
            or path.name.startswith(".env.") or ".sqlite" in path.name
            or path.suffix in (".pyc", ".pyo", ".pem", ".key"))


def picked(value, keys):
    return {k: value[k] for k in keys if k in value}


def narrow_scan(data, label):
    # Supplement to explicit byte-bound publication review, never its substitute.
    require(not any(re.search(p, data) for p in SECRET_PATTERNS),
            "Potential secret pattern in candidate " + label)


class Collector:
    def __init__(self):
        self.payload = {}
        self.sources = {}
        self.reads = {}
        self.candidates = {}
        self.objects = {}
        self.zip_objects = {}
        self.trees = {}

    def read(self, path, label):
        path = Path(path)
        require(path.is_file() and not path.is_symlink() and path.resolve() == path.absolute(),
                "Nonregular or linked source: " + label)
        content = path.read_bytes()
        checksum = sha(content)
        require(path not in self.reads or self.reads[path][0] == checksum, "Source changed: " + label)
        self.reads[path] = (checksum, label)
        return content

    def json(self, path, label):
        return json.loads(self.read(path, label))

    def candidate(self, label, content, classification):
        narrow_scan(content, label)
        entry = {"sha256": sha(content), "bytes": len(content), "classification": classification}
        require(label not in self.candidates or self.candidates[label] == entry, "Source label collision")
        self.candidates[label] = entry

    def add(self, name, content, provenance):
        relative(name)
        require(name not in self.payload, "Duplicate archive member")
        narrow_scan(content, name)
        self.payload[name] = content
        self.sources[name] = provenance

    def raw(self, name, path, label=None):
        label = label or name
        content = self.read(path, label)
        self.candidate(label, content, "original-bytes; publication review required")
        self.add(name, content, {"kind": "original-bytes", "source": label, "sourceSha256": sha(content)})
        return content

    def derived(self, name, value, sources, note):
        self.add(name, encoded(value), {"kind": "derived-projection", "sources": sources, "note": note})

    def ref(self, content, source):
        checksum = sha(content)
        self.candidate(source, content, "original-file-content; publication review required")
        if checksum not in self.objects:
            if checksum in self.zip_objects:
                self.objects[checksum] = {"kind": "frozen-zip-member", "member": self.zip_objects[checksum],
                                          "bytes": len(content)}
            else:
                name = "objects/" + checksum
                self.objects[checksum] = {"kind": "archive-member", "member": name, "bytes": len(content)}
                self.add(name, content, {"kind": "original-file-content", "firstSource": source,
                                         "sourceSha256": checksum})
        return checksum

    def stable(self):
        for path, (checksum, label) in self.reads.items():
            require(path.is_file() and not path.is_symlink() and path.resolve() == path.absolute()
                    and sha(path.read_bytes()) == checksum, "Source changed while archiving: " + label)
        for root, expected in self.trees.items():
            require(tree_metadata(root) == expected, "Snapshot membership or metadata changed while archiving")


def tree_metadata(root):
    result = {}
    for directory, folders, files in os.walk(root, followlinks=False):
        for name in [*folders, *files]:
            path = Path(directory) / name
            rel = path.relative_to(root).as_posix()
            info = path.lstat()
            result[rel] = [info.st_mode, info.st_size, info.st_mtime_ns, info.st_ino]
            if name in folders and (excluded(rel) or path.is_symlink()):
                folders.remove(name)
    return result


def transport_projection(transport):
    result = picked(transport, TRANSPORT_KEYS)
    result["requests"] = []
    for request in transport["requests"]:
        row = picked(request, REQUEST_KEYS)
        row["usage"] = picked(request["usage"], USAGE_KEYS)
        # providerUsage can contain provider-specific arbitrary data; preserve only
        # the runner's normalized usage, with source='provider' or unknown/null.
        row["taskToolAttempts"] = [
            {"index": i, "name": "task", "agentType": call.get("arguments", {}).get("agent_type")
             if isinstance(call.get("arguments"), dict) else None}
            for i, call in enumerate(request.get("toolCalls", [])) if call.get("name") == "task"]
        result["requests"].append(row)
    result["admissionRejections"] = [picked(r, REJECTION_KEYS) for r in transport.get("admissionRejections", [])]
    result["projectionBoundary"] = "No request/response/reasoning, provider IDs, arbitrary providerUsage, tool arguments or credentials."
    return result


def check_usage(projection, row):
    requests = projection["requests"]
    require(len({r["call"] for r in requests}) == len(requests) == row["modelCalls"] == projection["started"],
            "Physical-call count mismatch")
    known = [r for r in requests if r["usage"].get("source") == "provider"]
    cache = [r for r in known if r["usage"].get("cache_read_tokens") is not None]
    checks = {"inputTokens": sum(r["usage"]["input_tokens"] for r in known),
              "outputTokens": sum(r["usage"]["output_tokens"] for r in known),
              "cacheReadTokens": sum(r["usage"]["cache_read_tokens"] for r in cache),
              "unknownUsageCalls": len(requests) - len(known),
              "failedCalls": sum(r["event"] == "failed" for r in requests),
              "inFlightCalls": sum(r["event"] == "started" for r in requests),
              "tokenUsageComplete": bool(requests) and len(known) == len(requests),
              "cacheUsageComplete": bool(requests) and len(cache) == len(requests),
              "delegationAttempts": sum(len(r["taskToolAttempts"]) for r in requests)}
    require(all(row[key] == value for key, value in checks.items()), "Usage projection differs from existing result")
    require(row["knownTotalTokens"] == checks["inputTokens"] + checks["outputTokens"], "Known total mismatch")
    require(row["totalTokens"] == (row["knownTotalTokens"] if checks["tokenUsageComplete"] else None),
            "Unknown tokens changed to zero or an estimate")
    require(row["currencyPriceKnown"] is False and all(row[k] is None for k in
            ("estimatedCostUsd", "estimatedCostCny", "knownCostLowerBoundCny")), "Unknown price lost")
    require(all(row["interventions"][k] is None for k in ("humanApprovalCount", "humanCorrectionCount")),
            "Unsupported human intervention counts")


def journal_projection(collector, private, prefix):
    outputs, event_counts, errors = [], Counter(), 0
    journal = private / "journal"
    # Walk only this trial's journal; never inspect HOME, caches or SQLite.
    for directory, folders, files in os.walk(journal, followlinks=False):
        folders[:] = sorted(n for n in folders if not (Path(directory) / n).is_symlink())
        if "events.ndjson" not in files:
            continue
        path = Path(directory) / "events.ndjson"
        label = prefix + path.relative_to(private).as_posix()
        raw = collector.read(path, label)
        events = []
        for index, line in enumerate(raw.splitlines(), 1):
            try:
                event = json.loads(line)
                value = picked(event, EVENT_KEYS)
                event_counts[event["type"]] += 1
                payload = event.get("payload", {})
                value["payload"] = {k: payload[k] for k in EVENT_PAYLOAD_VALUES
                                     if k in payload and (payload[k] is None or type(payload[k]) in (bool, int, float))}
                value["payload"].update({k: payload[k] for k in EVENT_PAYLOAD_IDS if k in payload
                    and isinstance(payload[k], str) and re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", payload[k])})
                if isinstance(payload.get("usage"), dict):
                    value["payload"]["usage"] = {k: v for k, v in payload["usage"].items()
                        if k in ("input_tokens", "output_tokens", "total_tokens", "cache_read_tokens", "source")
                        and (v is None or type(v) in (int, float) or v in ("provider", "unknown"))}
                value.update(sourceLine=index, sourceLineSha256=sha(line))
            except (ValueError, KeyError, TypeError):
                errors += 1
                value = {"sourceLine": index, "sourceLineSha256": sha(line), "parseError": True}
            events.append(value)
        name = prefix + "journal/" + sha(label.encode()) + ".json"
        collector.derived(name, {"events": events, "sourceSha256": sha(raw)}, [label],
                          "Event headers, typed counters and bounded IDs only; payload text omitted; no fabricated event.")
        outputs.append({"source": label, "sourceSha256": sha(raw), "projection": name})
    return {"files": outputs, "projectedEventCounts": dict(event_counts), "lineParseErrors": errors,
            "note": "Projection error count is line-based; runner intervention_metrics has file-level parsing semantics."}


def capture_snapshot(collector, root, base, source_prefix):
    current, omitted = {}, []
    if not root.is_dir():
        return {"available": False, "reason": "snapshot-not-retained", "changes": None, "deleted": None}
    require(not root.is_symlink() and root.resolve() == root.absolute(), "Linked snapshot root")
    collector.trees[root] = tree_metadata(root)
    for directory, folders, files in os.walk(root, followlinks=False):
        for name in sorted([*files, *folders]):
            path = Path(directory) / name
            rel = path.relative_to(root).as_posix()
            mode = path.lstat().st_mode
            if excluded(rel):
                if name in folders:
                    folders.remove(name)
                omitted.append({"path": rel, "kind": "directory" if stat.S_ISDIR(mode) else "excluded-file",
                                "reason": "private-or-cache-path; contents-not-read", "sha256": None})
                continue
            if stat.S_ISDIR(mode):
                continue
            if stat.S_ISLNK(mode):
                if name in folders:
                    folders.remove(name)
                # Link text is data, never followed or recreated automatically.
                target = os.readlink(path)
                current[rel] = {"kind": "symlink", "target": target, "mode": stat.S_IMODE(mode)}
                collector.candidate(source_prefix + "/" + rel + "#link", target.encode(), "symlink-text; review required")
            elif stat.S_ISREG(mode):
                content = collector.read(path, source_prefix + "/" + rel)
                current[rel] = {"kind": "file", "sha256": collector.ref(content, source_prefix + "/" + rel),
                                "mode": stat.S_IMODE(mode)}
            else:
                current[rel] = {"kind": "special", "fileType": stat.S_IFMT(mode), "mode": stat.S_IMODE(mode)}
        folders.sort()
    changes = {name: item for name, item in current.items()
               if name not in base or (item.get("kind"), item.get("sha256")) != ("file", base[name])}
    same = {name: item["mode"] for name, item in current.items() if name not in changes}
    return {"available": True, "changes": changes, "unchangedFileModes": same,
            "deleted": sorted(set(base) - set(current)), "excluded": omitted,
            "inventorySha256": sha(json.dumps(current, sort_keys=True, separators=(",", ":")).encode()), "publicFileCount": len(current),
            "snapshotMeaning": "Observed at archive time from this named retained snapshot; not an execution-finish timestamp.",
            "restoreBoundary": "All included regular-file bytes and mode metadata; links/special files recorded, not materialized; private/cache omissions explicit."}


def collect(config, config_path):
    c = Collector()
    run, report = Path(config["run"]).resolve(), Path(config["reportDirectory"]).resolve()
    registration, reporter = Path(config["registration"]).resolve(), Path(config["reporter"]).resolve()
    require(config.get("operatorConfirmedRunStopped") is True, "Manually confirm all cells and launcher ended before reading")
    # Read the finished report before any trial/private data; never poll or wait.
    summary = c.json(report / "summary.json", "report/summary.json")
    require(summary["status"] == "complete_descriptive" and summary["synthetic"] is False
            and summary["expectedTrials"] == summary["observedTrials"] == 32,
            "Requires the existing complete 32-cell report; missing/incomplete experiments must use a different archive label")
    manifest = c.json(run / "manifest.json", "run/manifest.json")
    registered = c.json(registration, "registration/manifest.json")
    design = c.json(run / "study-design.json", "run/study-design.json")
    require(manifest["schedule"] == registered["schedule"] == design["schedule"], "Schedule mismatch")
    schedule = manifest["schedule"]
    require(len(schedule) == len({r["id"] for r in schedule}) == 32, "Not 32 unique cells")
    require(registered["arms"] == manifest["arms"] == ["single", "auto"], "Wrong arms")
    require(Counter((r["case"], r["arm"], r["repeat"]) for r in schedule) ==
            Counter((case["id"], arm, 1) for case in registered["cases"] for arm in registered["arms"]),
            "Paired registered membership differs")
    provenance = summary["provenance"]
    require(provenance["registrationSelection"] == "explicit"
            and provenance["registrationSha256"] == sha(c.read(registration, "registration/manifest.json"))
            and provenance["reporterSha256"] == sha(c.read(reporter, "report-software/report_results.py")),
            "Report binding mismatch")
    for key in ("productionSha256", "harnessSha256", "routeSha256", "model"):
        require(provenance[key] == manifest[key], "Report source/route mismatch: " + key)
    require(sha(c.read(run / "manifest.json", "run/manifest.json")) == config["expectedRunManifestSha256"],
            "Operator-selected freeze mismatch")
    for key, filename in (("taskSha256", "tasks.json"), ("analysisPlanSha256", "analysis-plan.md"),
                          ("studyDesignSha256", "study-design.json"), ("oracleSupportSha256", "oracle-support-hashes.json"),
                          ("frozenCodeArchiveSha256", "frozen-code.zip")):
        require(manifest[key] == sha(c.read(run / filename, "run/" + filename)), "Frozen input mismatch")
    require(design["portableManifestSha256"] == provenance["registrationSha256"], "Design/registration mismatch")
    for key in ("runtime", "limits", "constraints", "outcomes", "exclusions"):
        require(design[key] == registered[key], "Registered condition mismatch: " + key)
    for filename in ("manifest.json", "study-design.json", "analysis-plan.md", "oracle-support-hashes.json", "frozen-code.zip"):
        c.raw("run/" + filename, run / filename)
    c.raw("registration/manifest.json", registration)
    c.raw("report-software/report_results.py", reporter)
    for filename in ("summary.json", "report.md", "trials.csv"):
        c.raw("report/" + filename, report / filename)
    for item in config.get("attestations", []):
        name = item["archiveName"]
        relative(name)
        source = Path(item["path"]).resolve()
        require(name.startswith("attestations/") and not excluded(source.name), "Invalid attestation selection")
        require(sha(c.read(source, name)) == item["sha256"], "Attestation changed")
        c.raw(name, source)
    for filename in ("pack_r3_results.py", "restore_delivery.py"):
        c.raw("archive-software/" + filename, Path(__file__).resolve().parent / filename)
    with zipfile.ZipFile(io.BytesIO(c.payload["run/frozen-code.zip"])) as bundle:
        members = [i for i in bundle.infolist() if not i.is_dir()]
        require(len({i.filename for i in members}) == len(members), "Duplicate frozen ZIP member")
        contents = {}
        for info in members:
            relative(info.filename)
            require(not excluded(info.filename) and not stat.S_ISLNK(info.external_attr >> 16), "Private/linked frozen member")
            content = bundle.read(info.filename)
            narrow_scan(content, "frozen-code.zip!" + info.filename)
            c.zip_objects.setdefault(sha(content), info.filename)
            contents[info.filename] = content
        production = b"".join(name.encode() + b"\0" + data for name, data in sorted(contents.items())
                               if name.startswith("minicode/") and name.endswith(".py"))
        require(sha(production) == manifest["productionSha256"], "Frozen production digest mismatch")
        runner_ast = ast.parse(contents["scripts/run_three_arm_real.py"].decode())
        harness_names = next(ast.literal_eval(node.value) for node in runner_ast.body
                             if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
                             and target.id == "HARNESS_FILES" for target in node.targets))
        # Existing registered-study configure_study appends this one member.
        harness_names = tuple(dict.fromkeys((*harness_names, "implementation_judge.py")))
        harness = b"".join(name.encode() + b"\0" + contents["scripts/" + name] for name in harness_names)
        require(sha(harness) == manifest["harnessSha256"], "Frozen harness digest mismatch; inspect the frozen recipe, never relax the binding")
    original_tasks = c.read(run / "tasks.json", "run/tasks.json")
    tasks = json.loads(original_tasks)
    require(encoded(tasks) == original_tasks, "Original tasks JSON is not the frozen writer encoding; do not silently lose byte identity")
    shape, baselines = deepcopy(tasks), {}
    for container, projected, label in [(tasks, shape, "shared_files"), *
            [(case, shape["cases"][i], "files") for i, case in enumerate(tasks["cases"])]]:
        case_id = container.get("id", "shared")
        projected[label] = {name: {"objectSha256": c.ref(text.encode(), "tasks/" + case_id + "/" + name)}
                            for name, text in container.get(label, {}).items()}
        for name in projected[label]:
            require(not excluded(name), "Private path in frozen tasks")
            relative(name)
        if case_id != "shared":
            baselines[case_id] = {name: sha(text.encode()) for name, text in
                                  {**tasks.get("shared_files", {}), **container[label]}.items()}
            projected["oracle_source"] = {"objectSha256": c.ref(container["oracle_source"].encode(), "tasks/" + case_id + "/oracle.py")}
    c.derived("shared/tasks-template.json", shape, ["run/tasks.json"],
              "Lossless file-string factorization. Restore file/oracle strings, same key order, ensure_ascii=False, indent=2 + LF; require original task SHA.")
    c.derived("shared/baselines.json", baselines, ["run/tasks.json"], "Per-case source inventories; bytes deduplicated by SHA.")
    support = c.json(run / "oracle-support-hashes.json", "run/oracle-support-hashes.json")
    support_refs = {}
    for name, expected in support.items():
        relative(name)
        require(name.startswith("oracle-support/") and not excluded(name), "Invalid support member")
        content = c.read(run / name, "run/" + name)
        require(sha(content) == expected, "Support bytes changed")
        support_refs[name] = c.ref(content, "run/" + name)
    c.derived("shared/oracle-support.json", support_refs, ["run/oracle-support-hashes.json"], "Original support files, once per SHA.")
    results = c.json(run / "results.json", "run/results.json")
    require(results.get("synthetic", False) is False and results["expectedTrials"] == 32
            and results["manifestSha256"] == sha(c.payload["run/manifest.json"]), "Results identity mismatch")
    rows = {r["id"]: r for r in results["trials"]}
    require(len(results["trials"]) == len(rows) == 32 and set(rows) == {r["id"] for r in schedule}
            and {p.stem for p in (run / "trials").glob("*.json")} == set(rows), "Finalized trial membership mismatch")
    c.raw("run/results.json", run / "results.json")
    cases = {case["id"]: case for case in tasks["cases"]}
    absence, withheld, snapshots = {}, [], {}
    for planned in schedule:
        identity = planned["id"]
        relative(identity)
        require("/" not in identity, "Invalid trial ID")
        row = c.json(run / "trials" / (identity + ".json"), "trials/" + identity + ".json")
        require(row == rows[identity] and all(row[k] == planned[k] for k in ("id", "case", "arm", "repeat")), "Trial/checkpoint mismatch")
        c.raw("trials/" + identity + ".json", run / "trials" / (identity + ".json"))
        private, prefix = run / "private" / identity, "records/" + identity + "/"
        absence[identity] = []
        # Exact receipts can contain free-form/path fields: all require the same
        # post-run byte-bound publication review as source files and judge logs.
        originals = ("execution.json", "execution-start.json", "runtime-contract.json", "process-cleanup.json",
                     "baseline-files.json", "error.json", "judgement/result.json")
        for name in originals:
            if (private / name).is_file():
                c.raw(prefix + name, private / name)
            else:
                absence[identity].append(name)
        baseline_path = private / "baseline-files.json"
        if baseline_path.is_file():
            actual_baseline = c.json(baseline_path, prefix + "baseline-files.json")
            expected_baseline = {name: ["file", checksum] for name, checksum in baselines[row["case"]].items()}
            require(actual_baseline == expected_baseline, "Actual initial workspace differs from frozen task files")
        for stage in ("oracle", "regression"):
            for name in ("result.json", "receipt.json", "stage.json", "cleanup.json", "processes.jsonl", "output.log"):
                path = private / "judgement" / stage / name
                if path.is_file():
                    c.raw(prefix + "judgement/" + stage + "/" + name, path)
                else:
                    absence[identity].append("judgement/" + stage + "/" + name)
        source = private / "transport-summary.json"
        transport = c.json(source, prefix + "transport-summary.json")
        projection = transport_projection(transport)
        check_usage(projection, row)
        c.derived(prefix + "transport-usage.json", projection,
                  [{"source": prefix + "transport-summary.json", "sha256": sha(c.read(source, prefix + "transport-summary.json"))}],
                  "Direct allowlisted fields from finalized SQLite-exported summary; normalized provider/unknown usage preserved; no raw provider content.")
        collab_path = private / "collaboration.json"
        if collab_path.is_file():
            collab = c.json(collab_path, prefix + "collaboration.json")
            runs = []
            for run_record in collab["runs"]:
                record = picked(run_record, COLLAB_KEYS)
                projected = run_record.get("projected")
                record["projectedOutcome"] = picked(projected, ("outcome", "partial", "subagentId", "resultVersion")) if isinstance(projected, dict) else None
                runs.append(record)
            value = {"runs": runs, "hostAcknowledgedIds": collab.get("deliveredIds", []),
                     "reporterRoleEvidence": summary["actualRoleEvidence"].get(identity),
                     "boundary": "Host acknowledgements only. Reporter also parses private transcript delivery; transcript-only IDs not inferred or recreated here."}
            c.derived(prefix + "collaboration-witness.json", value,
                      [{"source": prefix + "collaboration.json", "sha256": sha(c.read(collab_path, prefix + "collaboration.json"))},
                       {"source": "report/summary.json", "sha256": sha(c.payload["report/summary.json"])}],
                      "Content-free run/outcome/acknowledgement projection; not a substitute for private reporter revalidation.")
        else:
            absence[identity].append("collaboration.json")
        journal = journal_projection(c, private, prefix)
        c.derived(prefix + "journal-index.json", journal, [prefix + "journal"], "All retained journal event streams projected; raw payloads withheld.")
        workspace_path = private / "workspace.json"
        locations = {stage + "-retained-snapshot": private / "judgement" / stage / "workspace" for stage in ("oracle", "regression")}
        if workspace_path.is_file():
            workspace = Path(c.json(workspace_path, prefix + "workspace.json")["path"]).resolve()
            allowed = [Path(p).resolve() for p in config["allowedWorkspaceParents"]]
            require(workspace.name.startswith("minicode-real-three-arm-") and any(workspace.is_relative_to(p) for p in allowed), "Unexpected workspace location")
            locations["agent-workspace-observed-after-judgement"] = workspace
        else:
            absence[identity].append("workspace.json")
        for snapshot_name, location in locations.items():
            snapshot = capture_snapshot(c, location, baselines[row["case"]], prefix + snapshot_name)
            snapshot.update(caseId=row["case"], trialId=identity, snapshot=snapshot_name,
                            runnerChangedFiles=row["changedFiles"], verificationInducedChanges=row["verificationInducedChanges"],
                            baselineReceiptAvailable=baseline_path.is_file())
            name = prefix + "snapshots/" + snapshot_name + ".json"
            c.derived(name, snapshot, [prefix + "baseline-files.json", "trials/" + identity + ".json"],
                      "Observed file inventory and exact public-file delta from named case baseline, not reconstructed finish-time state.")
            snapshots[identity + "/" + snapshot_name] = name
        for name in ("response.txt", "transcript.json", "transport-summary.json", "calls.jsonl", "process.log", "subagents.json",
                     "transport.sqlite", "transport.sqlite-wal", "transport.sqlite-shm"):
            path = private / name
            if path.is_file():
                # Never open the response, transcript, SQLite, or convenience
                # transcript exports here. Report-read hashes are attributed.
                recorded = provenance.get("inputSha256", {}).get(str(path.resolve()))
                measured = c.reads.get(path, (None,))[0]
                withheld.append({"source": prefix + name, "bytesAtArchiveObservation": path.stat().st_size,
                                 "sha256": measured or recorded,
                                 "hashSource": "archiver-read-for-projection" if measured else "existing-reporter-provenance" if recorded else "not-read-null",
                                 "reason": "Private originals retained locally; no provider text/SQLite/raw response in archive."})
    # Every report input read by this archiver must still match the earlier
    # reporter. Unread private originals are not falsely certified stable.
    report_hashes = provenance["inputSha256"]
    for path, (checksum, label) in c.reads.items():
        if str(path) in report_hashes:
            require(checksum == report_hashes[str(path)], "Input changed since finished report: " + label)
    c.derived("private-originals-retained.json", withheld, ["report/summary.json"], "No raw private content read merely to invent a new hash; null preserved.")
    c.derived("availability.json", {"missingOptionalEvidence": absence, "snapshots": snapshots}, [], "Missing receipts/snapshots remain missing, regardless of trial outcome.")
    c.derived("shared/objects-index.json", c.objects, ["run/frozen-code.zip", "shared/tasks-template.json"], "Content-addressed storage; each byte sequence stored once.")
    context = config["publicationContext"]
    require(context.get("runIdentity") and context.get("registrationSourceCommit") and context.get("runtimeSourceCommit"), "Missing supplied Git/publication identities")
    c.derived("archive-context.json", {"archiverVersion": VERSION, "archiveObservationAt": datetime.now(timezone.utc).isoformat(),
        "publicationContext": context, "bindings": picked(manifest, ("model", "routeSha256", "resolvedTransportRouteSha256", "productionSha256", "harnessSha256", "frozenCodeArchiveSha256", "taskSha256", "studyDesignSha256", "analysisPlanSha256", "oracleSupportSha256")),
        "registrationSha256": provenance["registrationSha256"], "reporterSha256": provenance["reporterSha256"],
        "runManifestSha256": sha(c.payload["run/manifest.json"]),
        "scope": "32 existing finalized outcomes; no rerun/rejudge, no new experiment gate. Supplied Git identities are provenance labels, not independently resolved by this offline archiver.",
        "localReplay": "Original reporter v3 remains unchanged; full collaboration revalidation needs retained private transcript plus original path relocation.",
        "publicReplay": "Usage/call subtotals and published report/statistics, exact frozen inputs and included delivered bytes; content-free collaboration witnesses have explicit limits."},
        ["run/manifest.json", "registration/manifest.json", "report/summary.json"], "Archive context; timestamp is packaging time, never a fabricated trial/registration time.")
    c.stable()
    return c


def build_archive(c, destination):
    require(not destination.exists(), "Use a fresh output directory")
    destination.mkdir(parents=True)
    archive_path = destination / "evidence.tar.gz"
    with archive_path.open("wb") as target:
        with gzip.GzipFile(filename="", mode="wb", compresslevel=1, fileobj=target, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.USTAR_FORMAT) as archive:
                for name, content in sorted(c.payload.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.uid, info.gid, info.mtime = len(content), 0o644, 0, 0, 0
                    archive.addfile(info, io.BytesIO(content))
    seen = set()
    with tempfile.TemporaryDirectory(prefix="r3-archive-byte-restore-") as temp:
        restored = Path(temp)
        with tarfile.open(archive_path, "r:gz") as archive:
            for member in archive:
                name = relative(member.name)
                require(member.isfile() and member.name not in seen and member.name in c.payload, "Unsafe/unexpected archive member")
                content = archive.extractfile(member).read()
                require(content == c.payload[member.name], "Archive bytes differ")
                target = restored.joinpath(*name.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                require(target.read_bytes() == content, "Restored bytes differ")
                seen.add(member.name)
        require(seen == set(c.payload), "Missing restored member")
        # Pure helper source is separately reviewed; no subprocess or imports
        # from the runtime. Reconstruct original tasks bytes directly here.
        template = json.loads(c.payload["shared/tasks-template.json"])
        with zipfile.ZipFile(io.BytesIO(c.payload["run/frozen-code.zip"])) as frozen:
            def object_bytes(checksum):
                entry = c.objects[checksum]
                value = frozen.read(entry["member"]) if entry["kind"] == "frozen-zip-member" else c.payload[entry["member"]]
                require(sha(value) == checksum, "Restored object SHA mismatch")
                return value
            template["shared_files"] = {name: object_bytes(ref["objectSha256"]).decode() for name, ref in template.get("shared_files", {}).items()}
            for case in template["cases"]:
                case["files"] = {name: object_bytes(ref["objectSha256"]).decode() for name, ref in case["files"].items()}
                case["oracle_source"] = object_bytes(case["oracle_source"]["objectSha256"]).decode()
            require(sha(encoded(template)) == json.loads(c.payload["run/manifest.json"])["taskSha256"], "Exact task reconstruction failed")
            for checksum in c.objects:
                object_bytes(checksum)
            baselines = json.loads(c.payload["shared/baselines.json"])
            for member in json.loads(c.payload["availability.json"])["snapshots"].values():
                snapshot = json.loads(c.payload[member])
                if not snapshot["available"]:
                    continue
                base = baselines[snapshot["caseId"]]
                reconstructed = {name: {"kind": "file", "sha256": checksum, "mode": snapshot["unchangedFileModes"][name]}
                                 for name, checksum in base.items() if name not in snapshot["deleted"] and name not in snapshot["changes"]}
                reconstructed.update(snapshot["changes"])
                require(sha(json.dumps(reconstructed, sort_keys=True, separators=(",", ":")).encode()) == snapshot["inventorySha256"],
                        "Snapshot delta reconstruction differs from observed inventory")
                require(all(item["sha256"] in c.objects for item in reconstructed.values() if item["kind"] == "file"),
                        "Missing delivered file content object")
    c.stable()
    entries = [{"path": name, "sha256": sha(data), "bytes": len(data)} for name, data in sorted(c.payload.items())]
    manifest = {"schemaVersion": 1, "archiverVersion": VERSION, "classification": "post-report descriptive evidence archive; no new experimental judgement",
                "archive": archive_path.name, "archiveSha256": sha(archive_path.read_bytes()), "archiveBytes": archive_path.stat().st_size,
                "entryCount": len(entries), "rawBytes": sum(e["bytes"] for e in entries), "expectedTrials": 32,
                "restorationVerification": "Every member extracted safely and byte-compared; every content object, exact original tasks JSON SHA and all available snapshot delta inventories checked",
                "compression": "Sorted USTAR, uid/gid/mtime=0, gzip filename empty/mtime=0/level=1; one compression pass",
                "narrowSecretScan": "Selected text + each frozen ZIP member scanned; explicit publication review remains required; no arbitrary-secret guarantee",
                "entries": entries}
    (destination / "manifest.json").write_bytes(encoded(manifest))
    (destination / "README.md").write_text("# R3 result evidence\n\nThis package preserves the existing 32 finalized records and finished report. Original/derived status is in source-index.json.\n\n"
        "The runtime ZIP and content objects are shared; tasks JSON is byte-reconstructable. Named snapshot deltas describe retained observed files, not an inferred finish-time state. "
        "See archive-context.json, availability.json and each snapshot's exclusions.\n\n"
        "Private HOME/credentials/SQLite/provider transcript/raw response are not included. Public usage receipts retain source flags and nulls. "
        "The unmodified full reporter still needs private transcript evidence for complete collaboration revalidation; the public witness does not replace it.\n\n"
        "No monetary price or human intervention count is invented. No result is rejudged. Git labels are supplied provenance; frozen source bytes are hashed.\n")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("inventory", "build"))
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--publication-review", type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    output = args.output.resolve()
    for root in (Path(config["run"]).resolve(), Path(config["reportDirectory"]).resolve(), *[Path(p).resolve() for p in config.get("neverWriteRoots", [])]):
        require(not output.is_relative_to(root), "Output must be outside frozen/source/report roots")
    require(not output.exists(), "Output must be new")
    collector = collect(config, args.config)
    inventory = {"schemaVersion": 1, "purpose": "Post-run disclosure review, not experiment scoring or authorization",
                 "archiverSha256": sha(Path(__file__).read_bytes()), "runManifestSha256": config["expectedRunManifestSha256"],
                 "rawCandidates": collector.candidates, "payloadMemberCount": len(collector.payload),
                 "instructions": "Review every candidate for credentials/provider transcript/raw response. Set reviewedRawFiles to the exact source-label→SHA mapping only after inspection; never relax scoring or edit frozen evidence."}
    if args.mode == "inventory":
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(encoded(inventory))
        print(json.dumps({"inventory": str(output), "candidates": len(collector.candidates), "archiveCreated": False}))
        return
    require(args.publication_review is not None, "Build needs the byte-bound publication review")
    review = json.loads(args.publication_review.read_text())
    require(set(review) == {"archiverSha256", "runManifestSha256", "reviewedRawFiles"},
            "Publication review must contain only the three documented metadata fields")
    expected = {name: item["sha256"] for name, item in collector.candidates.items()}
    require(review.get("runManifestSha256") == config["expectedRunManifestSha256"]
            and review.get("reviewedRawFiles") == expected, "Publication review does not match these exact candidates")
    require(review.get("archiverSha256") == sha(Path(__file__).read_bytes()), "Archiver changed since review")
    collector.derived("publication-review.json", review, [], "Byte-bound disclosure review; no experimental outcome changed.")
    collector.derived("source-index.json", deepcopy(collector.sources), [],
                      "Every earlier member classified as original or derived; this index is itself derived and bound by outer manifest. Logical source labels avoid new HOME path disclosure.")
    result = build_archive(collector, output)
    print(json.dumps({k: v for k, v in result.items() if k != "entries"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
