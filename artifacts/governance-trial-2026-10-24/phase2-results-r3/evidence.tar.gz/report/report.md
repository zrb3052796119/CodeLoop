# 真实历史任务比较：描述性结果

状态：complete_descriptive；记录 32/32 cells；16 对任务、每 cell 1 次。

| 层次 | single 成功/已完成/计划 | auto 成功/已完成/计划 | auto−single 成功百分点 |
| --- | ---: | ---: | ---: |
| 全部 | 8/16/16 | 7/16/16 | -6.25 |
| read | 1/5/5 | 0/5/5 | -20 |
| write | 6/7/7 | 6/7/7 | 0 |
| refactor | 1/4/4 | 1/4/4 | 0 |

| 指标：合计；已知/样本数 | single 全部 | auto 全部 | single 成功子集 | auto 成功子集 |
| --- | ---: | ---: | ---: | ---: |
| 输入+输出 token | 未知/不可合计；13/16，已知小计≥55,261,208 | 未知/不可合计；14/16，已知小计≥39,553,249 | 6,650,939；8/8 | 5,863,329；7/7 |
| 物理调用 | 1,223；16/16 | 864；16/16 | 267；8/8 | 211；7/7 |
| agent 墙钟秒 | 13,148.77；16/16 | 13,307.41；16/16 | 4,125.21；8/8 | 3,671.39；7/7 |

配对成功分布：{"bothSuccess": 7, "singleOnly": 1, "autoOnly": 0, "bothFailure": 8, "missingPair": 0}。
全体配对开销差（auto−single）：totalTokens=未知/不可合计（13/16 对已知）；modelCalls=-22.44（16/16 对已知）；durationSeconds=9.92（16/16 对已知）。
两组均成功子集：7 对；按结果筛选，仅作补充，详见 summary.json。

| 委派证据/缺失 | single | auto |
| --- | ---: | ---: |
| trialsWithAttempt | 0 | 0 |
| trialsWithActualDeliveredLeaf | 0 | 0 |
| actualLeafRuns | 0 | 0 |
| deliveredLeafResults | 0 | 0 |
| leafModelCalls | 0 | 0 |

详细角色证据可用 0/32 cells；逐角色物理调用、完成执行及交付见 summary.json，未把 task 请求当作协作。
实际角色物理调用（仅可用证据小计）：single={}；auto={}。
未知 usage 调用 single=3、auto=3；货币费用与人工批准/纠正次数均未知。宿主策略决定及 permission 事件另计。
失败和超时仍计入全部试次；成功子集按各组成功筛选、任务可能不同。未知 token 不插补零，cache 已包含于 input；agent 墙钟不含独立裁判时间，process/judge 时间另外保留。
这是相关历史任务、单次采样的内部描述；没有显著性/置信区间、普遍优劣或记忆增益结论。完整数值、每 cell 缺失状态、失败类别及输入 SHA 在 summary.json / trials.csv。
