# Continuous-request policy fixture timing diagnosis

**Fixture preconditions were unstable; no production transport defect was demonstrated.** Only `tests/test_continuous_request_policy.py` changes. ROOT, transport and Phase2 runtime stay unchanged.

## Observed CI failures and real baseline

- Run 40118490617, macOS 3.12, PR head `6e7ba88f`: caller case raised `EvaluationIdleTimeout` at `_consume` receive-gap check.
- Run 40120281015, Ubuntu 3.12, PR head `8fba3787`: expected caller deadline exception occurred but `failed/unknownUsageCalls` was 0, not 1.
- `source-comparison.json` shows both historical test files and transport are byte-identical to the pre-edit `715dd122` baseline. `report.json` records complete raw-log/XML/summary paths and SHA values; copied failure extracts retain both exact traces.

## Causal factors and bounded proof

The old fixture started its 60ms caller deadline before constructing the transport/SQLite ledger. A controlled 70ms initialization delay makes the measured admission checkpoint reject before any physical request: zero accounting is correct. Separately, a controlled 55ms first reader gap exceeds idle=50ms while caller=60ms remains unexpired; idle rejection is correct. `before-setup.log` and `before-gap.log` each fail at the same assertion/exception family as CI. These are controlled schedule witnesses, not captured exact CI timelines.

The alternative hypotheses of broken idle priority or missing accounting were not supported: the relevant guard is correctly first, or no request has started. A separate final test now asserts that an already-expired caller opens no HTTP and creates no request/failed/unknown record.

The revised fixture uses a module-local monotonic clock, the real adapter/transport/thread/queue/SQLite ledger, and an event handshake after the first heartbeat is durably consumed. Caller receives 30ms and 31ms gaps, both below the unchanged 50ms idle limit, while total elapsed time crosses the unchanged 60ms caller deadline. Idle separately receives a 51ms gap; cancellation occurs in fake HTTP after physical admission. Exact error class, exactly one opened/started/failed/unknown request, actual receive order and response closure are checked outside the reader. No global time monkeypatch, sleep extension or threshold relaxation is used.

The same scheduling plugin produces green with the revised fixture, but its wall-time hooks are intentionally superseded by the new explicit timeline and reader. That alone is not a robustness proof. The final identical test bytes also reject four synthetic contract faults: dropping caller deadline in consume, replacing idle allowance with 1s, swallowing token request, and omitting terminal failure ledger update. The first three fail with a wrong exception; the last fails the exact accounting assertion. These are sensitivity checks, not historical production bugs.

## Final validation

- Final related scope: **113 passed in 4.91s**, including this file, transport, adapter call controls and continuous diagnostic.
- Final four fault cases: all intentionally fail at their target contract.
- Restored final test file: **15 passed in 0.91s**. This is included in the 113 scope; do not sum counts.
- Scoped Ruff and `git diff --check` pass.
- Final test SHA: `f73325d0f18305d10cee66b636f7aa118c39020fc19589c2a1610065864852ce`.
- Unchanged transport SHA: `b3034785c2268067b0503731aadafb4f29b5c36df5141b98e1a4fa1c69232534`.
- Each final run records P1 module import paths and hashes, isolated HOME, argv, seed and exit code. No oracle/model/API execution occurred.

An initial adjacent invocation used the nonexistent filename `test_model_call_control.py`, causing 0-test collection failure; `invalid-missing-node-*` retains this invalid attempt. It is not counted as product failure or successful verification. Earlier diagnostic pytest cache-write warnings came from sandbox permissions; final checks use a tmp cache. There is no full-suite or CI-green claim here.

Independent review is recorded separately in `independent-review.md/json`. No commit or production edit is part of this handoff.
