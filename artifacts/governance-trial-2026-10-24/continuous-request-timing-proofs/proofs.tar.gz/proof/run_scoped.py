import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
base=Path(__file__).resolve().parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
python=Path('/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python')
label,mode,*nodes=sys.argv[1:]
home=Path(tempfile.mkdtemp(prefix='home-',dir=base))
env={k:v for k,v in os.environ.items() if not (k.startswith(('MINI_CODE_','MINICODE_','OPENAI_','ANTHROPIC_','AZURE_','GEMINI_','GOOGLE_API_')) or any(x in k for x in ('API_KEY','ACCESS_TOKEN','SECRET')))}
env.update(HOME=str(home),PYTHONPATH=os.pathsep.join([str(root),str(base)]),PYTHONDONTWRITEBYTECODE='1',IMPORT_PROOF_PATH=str(base/(label+'-imports.json')))
cmd=[str(python),'-m','pytest','-p','import_proof_plugin','-o','cache_dir='+str(base/'pytest-cache'),'--randomly-seed=20261024','-q',*nodes]
if mode!='none':
    cmd[3:3]=['-p','fault_probe_plugin' if mode.startswith('fault_') else 'timing_probe_plugin']
    env.update(TIMING_PROBE_MODE=mode,TIMING_PROBE_FACTS=str(base/(label+'-facts.json')))
started=time.time()
with (base/(label+'.log')).open('w') as log:
    result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'argv':cmd,'cwd':str(root),'exit':result.returncode,'seconds':time.time()-started,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'testSha256':sha(root/'tests/test_continuous_request_policy.py'),'transportSha256':sha(root/'scripts/evaluation_transport.py'),'mode':mode,'testLogSha256':sha(base/(label+'.log')),'isolatedHome':True,'credentialsRemoved':True,'providerCalls':0}
(base/(label+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
print((base/(label+'.log')).read_text()[-6500:])
