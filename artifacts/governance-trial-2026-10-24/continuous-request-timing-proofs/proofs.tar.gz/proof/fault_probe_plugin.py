"""Synthetic fault sensitivity only; these are not historical product bugs."""
import os
from dataclasses import replace
import pytest

@pytest.fixture(autouse=True)
def inject_selected_fault(request,monkeypatch):
    from scripts import evaluation_transport
    from minicode.turn_cancellation import TurnCancellationToken
    mode=os.environ['TIMING_PROBE_MODE']
    if mode=='fault_caller':
        original=evaluation_transport.EvaluationTransport._consume
        def consume(self,response,**kwargs):
            kwargs['deadline_monotonic']=None
            return original(self,response,**kwargs)
        monkeypatch.setattr(evaluation_transport.EvaluationTransport,'_consume',consume)
    elif mode=='fault_idle':
        original=evaluation_transport.EvaluationTransport.__init__
        def init(self,config):
            original(self,replace(config,idle_timeout_seconds=1))
        monkeypatch.setattr(evaluation_transport.EvaluationTransport,'__init__',init)
    elif mode=='fault_cancel':
        monkeypatch.setattr(TurnCancellationToken,'request',lambda self,*args,**kwargs:None)
    elif mode=='fault_ledger':
        original=evaluation_transport.SharedLedger.update
        def update(self,call,fields):
            if fields.get('event')=='failed':
                return
            return original(self,call,fields)
        monkeypatch.setattr(evaluation_transport.SharedLedger,'update',update)
    else:
        raise AssertionError(mode)
