import hashlib,json,os,sys
from pathlib import Path

def pytest_collection_finish(session):
    if not session.items:
        return
    root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main').resolve()
    rows={}
    for name in ('minicode.openai_adapter','minicode.model_call_control','scripts.evaluation_transport'):
        path=Path(sys.modules[name].__file__).resolve()
        assert path.is_relative_to(root), (name,str(path))
        rows[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    Path(os.environ['IMPORT_PROOF_PATH']).write_text(json.dumps(rows,indent=2)+'\n')
