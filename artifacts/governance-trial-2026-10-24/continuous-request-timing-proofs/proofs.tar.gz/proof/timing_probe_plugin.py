"""Controlled scheduling diagnostic, not a captured CI interleaving."""
import json
import os
import time
from pathlib import Path
from types import SimpleNamespace
import pytest

@pytest.fixture(autouse=True)
def force_reported_boundary(request, monkeypatch):
    if request.node.name != 'test_none_total_deadline_keeps_actual_idle_owner_and_cancellation[caller]':
        return
    from minicode import openai_adapter, model_call_control
    from scripts import evaluation_transport
    module = request.module
    mode = os.environ['TIMING_PROBE_MODE']
    clock = SimpleNamespace(now=1000.0)
    local_time = SimpleNamespace(monotonic=lambda:clock.now, time=time.time, sleep=time.sleep)
    for target in (module, evaluation_transport, openai_adapter, model_call_control):
        monkeypatch.setattr(target, 'time', local_time)
    if mode == 'setup_lag':
        original = evaluation_transport.EvaluationTransport.__init__
        def init(self, *args, **kwargs):
            original(self, *args, **kwargs)
            clock.now += 0.07
        monkeypatch.setattr(evaluation_transport.EvaluationTransport, '__init__', init)
    elif mode == 'first_byte_gap':
        original = module.ScriptedResponse.read1
        first = True
        def read1(self, amount):
            nonlocal first
            data = original(self, amount)
            if first:
                clock.now += 0.055
                first = False
            return data
        monkeypatch.setattr(module.ScriptedResponse, 'read1', read1)
    else:
        raise AssertionError(mode)
    yield
    Path(os.environ['TIMING_PROBE_FACTS']).write_text(json.dumps({'mode':mode,'finalClock':clock.now,'kind':'controlled schedule, not observed CI timeline'}))
