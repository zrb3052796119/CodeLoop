import hashlib,json,os,subprocess,time
from pathlib import Path
source_repo=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
primary=Path('/Users/zhourunbo/code/coding agent/MiniCode-Python-main')
base=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source_repo,text=True).strip()
changes=subprocess.check_output(['git','status','--porcelain'],cwd=source_repo,text=True)
if changes.strip(): raise SystemExit('Refusing Phase 1 acceptance of a dirty tree')
root=base/('phase1-candidate-'+head[:12])
subprocess.run(['git','clone','--shared','--no-checkout',str(primary),str(root)],check=True)
subprocess.run(['git','checkout','--detach',head],cwd=root,check=True)
archive=base/(root.name+'.tar')
subprocess.run(['git','archive','--format=tar','-o',str(archive),head],cwd=primary,check=True)
archive_sha=hashlib.sha256(archive.read_bytes()).hexdigest()
env=dict(os.environ)
for key in list(env):
    if key.startswith('MINI_CODE_') or key in ('PYTEST_ADDOPTS','PYTEST_PLUGINS','ANTHROPIC_API_KEY','OPENAI_API_KEY'):
        env.pop(key)
home=base/(root.name+'-home');home.mkdir()
env.update(PYTHONPATH=str(root),HOME=str(home),MINICODE_PYTEST_REAL_HOME=str(home),PYTHONDONTWRITEBYTECODE='1',PIP_CERT='/etc/ssl/cert.pem')
python=str(primary/'.venv-acceptance/bin/python')
restore_manifest=root/'artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json'
restore_command=[python,'scripts/restore_archived_artifacts.py','--manifest',str(restore_manifest),'--restore']
with (base/'phase1-input-restoration.log').open('w') as log:
    subprocess.run(restore_command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
command=[python,'-m','pytest','tests','-vv','-ra','--tb=short','--randomly-seed=20261024','--junitxml='+str(base/'phase1-candidate-results.xml')]
meta={'head':head,'archiveSha256':archive_sha,'source':str(root),'seed':20261024,'command':command,'started':time.time(),'customDiagnosticPlugins':False,'checkoutKind':'local shared-object clone, detached exact HEAD','apiCallsAuthorizedForThisRun':False,'restorationManifestSha256':hashlib.sha256(restore_manifest.read_bytes()).hexdigest(),'restorationCommand':restore_command,'note':'Independent Phase 1 candidate; acceptance requires Phase 0 baseline to pass too.'}
(base/'phase1-candidate-run-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
try:
    with (base/'phase1-candidate-pytest.log').open('w') as log:
        result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=9000)
    meta['exitCode']=result.returncode
except subprocess.TimeoutExpired:
    meta['exitCode']=124;meta['timedOut']=True
finally:
    meta['finished']=time.time();meta['durationSeconds']=meta['finished']-meta['started']
    (base/'phase1-candidate-run-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
raise SystemExit(meta['exitCode'])
