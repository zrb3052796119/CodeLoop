"""Freeze a clean repaired candidate and run the complete seeded acceptance once."""
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

source_repo = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
primary = Path('/Users/zhourunbo/code/coding agent/MiniCode-Python-main')
base = Path(__file__).parent
label = 'phase1-repaired'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source_repo, text=True).strip()
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=source_repo, text=True).strip():
    raise SystemExit('Refusing acceptance of a dirty tree')
root = base / (label + '-candidate-' + head[:12])
meta_path = base / (label + '-run-meta.json')
log_path = base / (label + '-pytest.log')
xml_path = base / (label + '-results.xml')
restore_path = base / (label + '-input-restoration.log')
archive = base / (root.name + '.tar')
home = base / (root.name + '-home')
if any(p.exists() for p in (root, meta_path, log_path, xml_path, restore_path, archive, home)):
    raise SystemExit('Refusing to overwrite acceptance evidence')
subprocess.run(['git', 'clone', '--shared', '--no-checkout', str(primary), str(root)], check=True)
subprocess.run(['git', 'checkout', '--detach', head], cwd=root, check=True)
subprocess.run(['git', 'archive', '--format=tar', '-o', str(archive), head], cwd=primary, check=True)
env = dict(os.environ)
for key in list(env):
    if key.startswith('MINI_CODE_') or key in ('PYTEST_ADDOPTS', 'PYTEST_PLUGINS', 'ANTHROPIC_API_KEY', 'OPENAI_API_KEY'):
        env.pop(key)
home.mkdir()
env.update(PYTHONPATH=str(root), HOME=str(home), MINICODE_PYTEST_REAL_HOME=str(home), PYTHONDONTWRITEBYTECODE='1', PIP_CERT='/etc/ssl/cert.pem')
python = str(primary / '.venv-acceptance/bin/python')
manifest = root / 'artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json'
restore_command = [python, 'scripts/restore_archived_artifacts.py', '--manifest', str(manifest), '--restore']
with restore_path.open('w') as log:
    subprocess.run(restore_command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
command = [python, '-m', 'pytest', 'tests', '-vv', '-ra', '--tb=short', '--randomly-seed=20261024', '--junitxml=' + str(xml_path)]
meta = dict(head=head, archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(), source=str(root), seed=20261024, command=command, started=time.time(), customDiagnosticPlugins=False, checkoutKind='local shared-object clone, detached exact HEAD', apiCallsAuthorizedForThisRun=False, restorationManifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest(), restorationCommand=restore_command, supersedesRun='phase1-candidate-eb17c62a5510; original failure evidence retained')
meta_path.write_text(json.dumps(meta, indent=2) + '\n')
try:
    with log_path.open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=9000)
    meta['exitCode'] = result.returncode
except subprocess.TimeoutExpired:
    meta['exitCode'] = 124
    meta['timedOut'] = True
finally:
    meta['finished'] = time.time()
    meta['durationSeconds'] = meta['finished'] - meta['started']
    meta_path.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
raise SystemExit(meta['exitCode'])
