#!/usr/bin/env python3
"""Seal two completed P1 attempts; validation is read-only unless --write is given."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import stat
import tarfile
import tempfile
import xml.etree.ElementTree as ET

BASE = Path('/private/tmp/codeloop-governance-20261024')
DESTINATION = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/'
                   'MiniCode-Python-main/artifacts/governance-trial-2026-10-24/'
                   'phase1-acceptance')
FIRST_HEAD = 'eb17c62a5510b6746c5fc677618303c9b83b96e6'
ATTEMPTS = (
    ('attempt-1-eb17', 'phase1-candidate', 'phase1-input-restoration.log',
     'run_phase1_candidate.py'),
    ('attempt-2-repaired', 'phase1-repaired', 'phase1-repaired-input-restoration.log',
     'run_phase1_repaired.py'),
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()


def finite_number(value: object) -> bool:
    return type(value) in (float, int) and math.isfinite(value)


class Inputs:
    """Explicit regular-file reads, with a second byte check before publishing."""

    def __init__(self) -> None:
        self.read: dict[Path, bytes] = {}
        self.large: dict[Path, tuple[str, int]] = {}

    def hash_file(self, path: Path) -> str:
        path = path.absolute()
        require(path.is_relative_to(BASE), f'Input outside evidence root: {path}')
        before = path.lstat()
        require(stat.S_ISREG(before.st_mode), f'Non-regular input: {path}')
        require(path.resolve().is_relative_to(BASE.resolve()), f'Escaping input: {path}')
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
        after = path.stat()
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
                f'Input changed while hashing: {path}')
        record = (digest.hexdigest(), after.st_size)
        require(path not in self.large or self.large[path] == record, f'Changing input: {path}')
        self.large[path] = record
        return record[0]

    def get(self, path: Path) -> bytes:
        path = path.absolute()
        require(path.is_relative_to(BASE), f'Input outside evidence root: {path}')
        require(stat.S_ISREG(path.lstat().st_mode), f'Non-regular input: {path}')
        require(path.resolve().is_relative_to(BASE.resolve()), f'Escaping input: {path}')
        data = path.read_bytes()
        require(path not in self.read or self.read[path] == data, f'Changing input: {path}')
        self.read[path] = data
        return data

    def unchanged(self) -> None:
        for path, data in self.read.items():
            require(path.read_bytes() == data, f'Input changed while packaging: {path}')
        for path in self.large:
            self.hash_file(path)


def xml_summary(raw: bytes, meta: dict) -> dict:
    tree = ET.fromstring(raw)
    require(tree.tag in ('testsuites', 'testsuite'), 'Not a JUnit report')
    suites = list(tree.iter('testsuite'))
    cases = list(tree.iter('testcase'))
    require(suites and cases, 'No completed testcases in JUnit report')
    outcomes = {'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0}
    failures = []
    for case in cases:
        bad = case.findall('failure') + case.findall('error')
        if bad:
            for problem in bad:
                outcomes['failed' if problem.tag == 'failure' else 'errors'] += 1
                failures.append({'node': case.get('classname', '') + '::' + case.get('name', ''),
                                 'kind': problem.tag, 'message': problem.get('message'),
                                 'detail': problem.text})
        elif case.find('skipped') is not None:
            outcomes['skipped'] += 1
        else:
            outcomes['passed'] += 1
    leaves = [s for s in suites if s.find('testsuite') is None]
    for key, counted in (('failures', outcomes['failed']), ('errors', outcomes['errors']),
                         ('skipped', outcomes['skipped'])):
        require(sum(int(s.get(key, '0')) for s in leaves) == counted,
                f'JUnit {key} attributes disagree with testcases')
    require(sum(int(s.get('tests', '0')) for s in leaves) == sum(outcomes.values()),
            'JUnit test totals disagree with outcomes')
    clean = outcomes['failed'] == outcomes['errors'] == 0
    require((meta['exitCode'] == 0) == clean, 'Exit code and JUnit result disagree')
    return {'sourceRun': meta, 'xmlSha256': sha(raw),
            'xmlSuites': [s.attrib for s in suites], 'outcomes': outcomes,
            'junitSeconds': sum(float(s.get('time', '0')) for s in leaves),
            'failures': failures, 'passed': clean}


def completed_attempt(inputs: Inputs, label: str, prefix: str,
                      restore_name: str, wrapper: str) -> tuple[dict[str, bytes], dict, Path]:
    members: dict[str, bytes] = {}
    meta_path = BASE / (prefix + '-run-meta.json')
    meta_raw = inputs.get(meta_path)
    meta = json.loads(meta_raw)
    require(all(k in meta for k in ('finished', 'exitCode', 'durationSeconds')),
            f'{prefix}: run is not finished; refusing to package')
    require(meta.get('timedOut') is not True and type(meta['exitCode']) is int
            and meta['exitCode'] in (0, 1), f'{prefix}: run did not complete normally')
    require(all(finite_number(meta.get(k)) for k in ('started', 'finished', 'durationSeconds')),
            f'{prefix}: incomplete timestamps')
    require(meta['finished'] >= meta['started'] and meta['durationSeconds'] > 0,
            f'{prefix}: invalid completion timestamps')
    require(abs(meta['finished'] - meta['started'] - meta['durationSeconds']) < 0.01,
            f'{prefix}: duration mismatch')
    require(re.fullmatch(r'[0-9a-f]{40}', meta.get('head', '')) is not None,
            f'{prefix}: invalid source identity')
    require(meta.get('seed') == 20261024, f'{prefix}: unexpected acceptance seed')
    require(meta.get('customDiagnosticPlugins') is False
            and meta.get('apiCallsAuthorizedForThisRun') is False,
            f'{prefix}: unexpected run contract')
    command = meta.get('command', [])
    expected_args = ['-m', 'pytest', 'tests', '-vv', '-ra', '--tb=short',
                     '--randomly-seed=20261024',
                     '--junitxml=' + str(BASE / (prefix + '-results.xml'))]
    require(command[1:] == expected_args,
            f'{prefix}: not the expected unfiltered complete seeded suite')
    root = Path(meta['source'])
    expected_name = ('phase1-candidate-' if prefix == 'phase1-candidate'
                     else 'phase1-repaired-candidate-') + meta['head'][:12]
    require(root == BASE / expected_name and root.is_dir(), f'{prefix}: source path mismatch')
    xml_raw = inputs.get(BASE / (prefix + '-results.xml'))
    log_raw = inputs.get(BASE / (prefix + '-pytest.log'))
    summary = xml_summary(xml_raw, meta)
    final_lines = log_raw.decode('utf-8', errors='replace').splitlines()[-12:]
    terminal = [line for line in final_lines
                if re.search(r'=+ .*\b(?:passed|failed)\b.* in [\d.]+s', line)]
    require(len(terminal) == 1, f'{prefix}: pytest terminal summary is missing or ambiguous')
    # Convert count-first regex pairs to named totals; xfail maps to JUnit skip.
    counts = {name: int(count) for count, name in re.findall(
        r'(\d+) (passed|failed|errors?|skipped|xfailed|xpassed|deselected)', terminal[0])}
    require('deselected' not in counts, f'{prefix}: filtered pytest run')
    terminal_outcomes = {
        'passed': counts.get('passed', 0) + counts.get('xpassed', 0),
        'failed': counts.get('failed', 0),
        'errors': counts.get('error', 0) + counts.get('errors', 0),
        'skipped': counts.get('skipped', 0) + counts.get('xfailed', 0),
    }
    require(terminal_outcomes == summary['outcomes'], f'{prefix}: log and XML totals disagree')
    summary['pytestSummaryLine'] = terminal[0]
    summary['pytestPrintedSeconds'] = float(re.search(r' in ([\d.]+)s', terminal[0]).group(1))
    archive = BASE / (root.name + '.tar')
    require(inputs.hash_file(archive) == meta['archiveSha256'], f'{prefix}: source archive mismatch')
    # The source archive is verified but intentionally excluded from the proof package.
    restoration = inputs.get(BASE / restore_name)
    require(b'Verified 8 reports' in restoration and b'Restored 8 missing reports' in restoration,
            f'{prefix}: pinned-input restoration did not complete')
    manifest_path = root / 'artifacts/archives/governance-pinned-inputs-2026-10-24/manifest.json'
    require(sha(inputs.get(manifest_path)) == meta['restorationManifestSha256'],
            f'{prefix}: restoration manifest identity mismatch')
    for name, data in (('run-meta.json', meta_raw), ('results.xml', xml_raw),
                       ('pytest.log', log_raw), ('input-restoration.log', restoration),
                       ('run-wrapper.py', inputs.get(BASE / wrapper)),
                       ('summary.json', encoded(summary))):
        members[label + '/' + name] = data
    existing = BASE / (prefix + '-summary.json')
    if prefix == 'phase1-candidate':
        # Preserve the original pre-existing failed-attempt summary byte-for-byte.
        original = inputs.get(existing)
        old = json.loads(original)
        require(old['sourceRun']['head'] == meta['head']
                and old['xmlSha256'] == summary['xmlSha256']
                and old['outcomes'] == summary['outcomes'], 'Original attempt summary mismatch')
        members[label + '/original-summary.json'] = original
    elif existing.exists():
        original = inputs.get(existing)
        old = json.loads(original)
        require(old.get('xmlSha256') == summary['xmlSha256']
                and old.get('outcomes') == summary['outcomes'], 'Repaired summary mismatch')
        members[label + '/recorded-summary.json'] = original
    return members, summary, root


def production_hash(inputs: Inputs, root: Path) -> str:
    payload = bytearray()
    for path in sorted((root / 'minicode').rglob('*.py')):
        payload.extend(path.relative_to(root).as_posix().encode() + b'\0' + inputs.get(path))
    require(payload, 'No frozen production sources found')
    return sha(bytes(payload))


def assemble() -> tuple[dict[str, bytes], bytes, dict, Inputs]:
    inputs = Inputs()
    members: dict[str, bytes] = {}
    attempts = []
    roots = []
    # Check repaired completion before doing any large reads or creating output.
    repaired = json.loads(inputs.get(BASE / 'phase1-repaired-run-meta.json'))
    require('finished' in repaired and 'exitCode' in repaired,
            'phase1-repaired is still running; refusing to package')
    for args in ATTEMPTS:
        group, summary, root = completed_attempt(inputs, *args)
        members.update(group)
        attempts.append(summary)
        roots.append(root)
    require(attempts[0]['sourceRun']['head'] == FIRST_HEAD, 'First attempt is not eb17')
    require(attempts[0]['sourceRun']['exitCode'] == 1, 'Original failed attempt was replaced')
    frozen_hash = production_hash(inputs, roots[1])
    quality = []
    for profile in ('current', 'a'):
        prefix = 'phase1-repaired-quality-' + profile
        raw = inputs.get(BASE / (prefix + '.json'))
        meta_raw = inputs.get(BASE / (prefix + '-meta.json'))
        result, meta = json.loads(raw), json.loads(meta_raw)
        require(meta.get('profile') == profile and meta.get('sourceUnchanged') is True,
                f'{profile}: quality source stability is not established')
        require(type(meta.get('exitCode')) is int and meta['exitCode'] in (0, 1),
                f'{profile}: quality evaluation incomplete')
        require(meta.get('productionSha256') == frozen_hash,
                f'{profile}: quality production bytes differ from frozen repaired suite')
        require(result.get('mode') == 'offline-deterministic' and result.get('remoteCallCount') == 0,
                f'{profile}: unexpected quality evaluation mode')
        gate_passed = result.get('gate', {}).get('passed')
        require(type(gate_passed) is bool and (meta['exitCode'] == 0) == gate_passed,
                f'{profile}: quality exit/result mismatch')
        quality.append({'profile': profile, 'exitCode': meta['exitCode'], 'passed': gate_passed,
                        'head': meta['head'], 'productionSha256': frozen_hash,
                        'seconds': meta['seconds'], 'remoteCallCount': result['remoteCallCount']})
        members['quality/' + profile + '.json'] = raw
        members['quality/' + profile + '-meta.json'] = meta_raw
    members['quality/run-wrapper.py'] = inputs.get(BASE / 'run_phase1_repaired_quality.py')
    static_raw = inputs.get(BASE / 'phase1-repaired-static-checks.json')
    static = json.loads(static_raw)
    for relative, expected in static['files'].items():
        path = Path(relative)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe static source path')
        require(sha(inputs.get(roots[1] / path)) == expected, f'Static-check source changed: {relative}')
    static_passed = all(static.get(name, {}).get('exitCode') == 0 for name in ('compileall', 'ruff'))
    members['static/phase1-repaired-static-checks.json'] = static_raw
    members['package_phase1_acceptance.py'] = inputs.get(Path(__file__).absolute())
    all_passed = attempts[1]['passed'] and all(q['passed'] for q in quality) and static_passed
    facts = {'schemaVersion': 1, 'attempts': attempts, 'repairedQuality': quality,
             'staticPassed': static_passed, 'repairedAcceptancePassed': all_passed,
             'productionSha256': frozen_hash,
             'claimBoundary': 'Local seeded suite and offline recorded-evidence quality only; not a native multi-OS CI pass.'}
    members['acceptance-facts.json'] = encoded(facts)
    rows = []
    for label, summary in zip(('First local attempt', 'Second local attempt'), attempts):
        o, m = summary['outcomes'], summary['sourceRun']
        rows.append(f"| {label} | `{m['head']}` | {o['passed']} | {o['failed']} | {o['errors']} | "
                    f"{o['skipped']} | {m['exitCode']} | {summary['junitSeconds']:.3f} | {m['durationSeconds']:.3f} |")
    failed_nodes = '\n'.join(
        '- ' + label + ': ' + (', '.join('`' + failure['node'] + '`'
                                       for failure in summary['failures']) or 'none')
        for label, summary in zip(('First local attempt', 'Second local attempt'), attempts)
    )
    quality_lines = '\n'.join(f"- `{q['profile']}`: passed={str(q['passed']).lower()}, "
                              f"exit={q['exitCode']}, {q['seconds']:.3f}s, remote calls={q['remoteCallCount']}."
                              for q in quality)
    readme = f'''# Phase 1 — two local attempts (not latest PR acceptance)

**Second local full suite passed: {str(attempts[1]['passed']).lower()}.**
Second local combined checks passed: **{str(all_passed).lower()}**.
All results below are derived from completed run metadata and JUnit XML at packaging time.
The initial failed attempt remains preserved; a later pass does not turn it green.

| Attempt | Commit | Passed | Failed | Errors | Skipped | Exit | JUnit seconds | Wrapper seconds |
|---|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

Both suite attempts used seed `{attempts[1]['sourceRun']['seed']}` and exact detached source clones.
Source archive hashes, commands, restoration manifest hashes, timestamps, complete pytest logs,
JUnit XML, wrappers and independently derived summaries are retained for each attempt.
The source archives themselves are verified against metadata but excluded to avoid duplicating source trees.
JUnit and wrapper durations measure different boundaries; pytest's printed duration remains in its raw log.

All failed nodes from both local attempts, directly from XML (details remain in summaries):

{failed_nodes}

The repaired quality evaluations are offline replay of recorded evidence, with production bytes
verified equal to the repaired frozen suite even if intervening commits changed only docs/evidence:

{quality_lines}

Static compileall/Ruff checks passed: **{str(static_passed).lower()}**. Each recorded source/test hash
was checked against the repaired frozen clone. This package does not claim a native Windows/Linux/macOS
CI pass, live model generalization, or any result from the separate Phase 0 baseline.
A later PR candidate requires CI evidence tied to that candidate; matching production bytes in
quality evaluations does not establish that its complete test suite passed.
Existing targeted proof packages are referenced by repository history and are not duplicated here.

## Integrity and scope

Only explicit allowlisted run/quality/static files, generated summaries, and this packager are archived.
No HOME, private-notes-backup, credentials, source tree tar, wheel directory or other proof package is copied.
`manifest.json` lists every member's byte count and SHA-256, plus the gzip hash and README hash.
Tar ownership/mode/timestamps and gzip mtime are fixed. The script decompresses its generated archive,
checks every regular member byte-for-byte, then rechecks inputs before writing these three files.
It refuses incomplete/timeout/interrupted runs, mismatched XML/exit codes, changed sources and an
existing destination. Run `package_phase1_acceptance.py --write` only after the repaired wrapper exits;
without `--write` it validates and reports without creating the final package.
'''.encode()
    return members, readme, facts, inputs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true', help='write the three-file final package')
    args = parser.parse_args()
    members, readme, facts, inputs = assemble()
    if not args.write:
        inputs.unchanged()
        print(json.dumps({'validated': True, 'written': False,
                          'repairedAcceptancePassed': facts['repairedAcceptancePassed'],
                          'memberCount': len(members)}))
        return
    require(not DESTINATION.exists(), 'Destination already exists; refusing overwrite')
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, data in sorted(members.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
            entry.uid = entry.gid = 0
            archive.addfile(entry, io.BytesIO(data))
    compressed = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=compressed, mode='wb', compresslevel=9, mtime=0) as stream:
        stream.write(buffer.getvalue())
    packed = compressed.getvalue()
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)), mode='r:') as archive:
        entries = archive.getmembers()
        require([e.name for e in entries] == sorted(members), 'Archive member mismatch')
        for entry in entries:
            require(entry.isfile() and archive.extractfile(entry).read() == members[entry.name],
                    f'Archive roundtrip changed bytes: {entry.name}')
    manifest = {'schemaVersion': 1, 'archive': 'proofs.tar.gz', 'archiveBytes': len(packed),
                'archiveSha256': sha(packed), 'readmeSha256': sha(readme),
                'memberCount': len(members), 'uncompressedMemberBytes': sum(map(len, members.values())),
                'repairedAcceptancePassed': facts['repairedAcceptancePassed'],
                'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                            for name, data in sorted(members.items())]}
    inputs.unchanged()
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.phase1-acceptance-', dir=DESTINATION.parent) as temporary:
        staged = Path(temporary) / 'package'
        staged.mkdir()
        for name, data in (('README.md', readme), ('manifest.json', encoded(manifest)),
                           ('proofs.tar.gz', packed)):
            (staged / name).write_bytes(data)
        inputs.unchanged()
        require(not DESTINATION.exists(), 'Destination appeared; refusing overwrite')
        os.rename(staged, DESTINATION)
    print(json.dumps({'destination': str(DESTINATION), 'files': 3,
                      'archiveSha256': sha(packed), 'archiveBytes': len(packed),
                      'repairedAcceptancePassed': facts['repairedAcceptancePassed']}))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, ET.ParseError) as error:
        raise SystemExit('REFUSED: ' + str(error)) from error
