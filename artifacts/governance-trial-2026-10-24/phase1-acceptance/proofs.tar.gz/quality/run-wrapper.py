from pathlib import Path
import hashlib,json,os,subprocess,sys,time
profile=sys.argv[1]
assert profile in ('current','a')
b=Path(__file__).parent;w=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
python='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
env=dict(os.environ)
for key in list(env):
 if key.startswith('MINI_CODE_') or key in ('PYTEST_ADDOPTS','PYTEST_PLUGINS','ANTHROPIC_API_KEY','OPENAI_API_KEY'): env.pop(key)
home=b/('phase1-repaired-quality-'+profile+'-home');home.mkdir(exist_ok=True)
env.update(PYTHONPATH=str(w),HOME=str(home),MINICODE_PYTEST_REAL_HOME=str(home),PYTHONDONTWRITEBYTECODE='1')
command=[python,'scripts/evaluate_agent_quality.py','--profile',profile]
source_sha=lambda: hashlib.sha256(b''.join(p.relative_to(w).as_posix().encode()+b'\0'+p.read_bytes() for p in sorted((w/'minicode').rglob('*.py')))).hexdigest()
source_before=source_sha()
assert not (b/('phase1-repaired-quality-'+profile+'.json')).exists()
started=time.time()
with (b/('phase1-repaired-quality-'+profile+'.json')).open('w') as out:
 result=subprocess.run(command,cwd=w,env=env,stdout=out,stderr=subprocess.PIPE,text=True,timeout=600)
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'profile':profile,'exitCode':result.returncode,'seconds':time.time()-started,'command':command,'source':str(w),'agentLoopSha256':hashlib.sha256((w/'minicode/agent_loop.py').read_bytes()).hexdigest(),'stderr':result.stderr,'productionSha256':source_before,'sourceUnchanged':source_sha()==source_before}
(b/('phase1-repaired-quality-'+profile+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
raise SystemExit(result.returncode)
