# Failed-write continuation：并发检查身份关联 fixture 修复

只改 `tests/test_failed_write_candidate_continuation.py`，32行新增/4行替换；最终 SHA `bb1d2c2ea53786ab1c302e1a7de99e212f301d5ce1addb0b200c4e7a4085c558`。未改生产、ROOT、文档，未commit/push，未跑全套/quality/API。等待root最终复审。

## 原因与真实红例

旧CI40124691703/macOS3.11 job120963503461，PR head `1decc8134528aa9795f32deab58493a288153c02`，实际checkout `a1066ea1c6efbacd71290cf1ab771b03cd8e7843`。完整原XML：14962passed/1failed/0errors/8skipped，seed48。唯一失败是本测试failed-checks参数；原日志记录checks `[0,1,1,0]`、formal `[1,0]`，fake Executor内部硬判 `[1,0]==[0,1]`，被真实agent loop捕获成model错误，最终execute_phase_failed。

生产workflow_runner.py:5020–5108为每check创建独立workspace并并行执行，join后才按请求index重排正式结果；fixture的ObservedVerifier在每次真实super.run返回后就把记录追加到commands。因此其回调完成顺序并没有compat先于regression的契约。原CI的具体调度未知。

`order_probe_plugin.py`在同一真实ObservedVerifier周围使用Barrier/Event：两worker都进入后，compat等待真实regression返回并完成observer append；真实super.run、退出码、证据、文件及oracle均不替换。旧Git1de精确fixture字节在同一P1生产上复现同一错误，1failed/2.05s。其assignment/digest一致，source为真实PARTIAL，排除了本反例的跨候选混入。该证据是**匹配反序的确定性反例**，不是历史CI精确重放。

## 最小修改与验证

helper按 `(execution_assignment_id, patch_digest)` 分轮，对每轮核对checkId和观察到的Verifier请求argv；拒绝重复与缺失。fake Executor第二次请求仍精确要求初轮 `compat=0, regression=1`（green参数则0），循环外仍精确要求随后完整一轮 `compat=0, regression=0`。没有对裸退出码排序。argv来自真实调用的VerificationCheck请求绑定，不声称返回check summary自带argv。

| 执行 | 结果 | 边界 |
| --- | --- | --- |
| 原fixture + 强制regression先返回 | 1failed/2.05s | 精确同症状；只运行failed参数 |
| 最终fixture + 同一排序plugin | 2passed/10.54s | failed与green-pending两参数；正式checks反序仍保留 |
| 最终fixture + 自然调度 | 2passed/10.52s | 只读profile保存自身观测，无排序介入 |

两次最终执行覆盖同2用例，**不能相加成4个测试**。before/after每次sourceBefore=sourceAfter，四个关键生产模块SHA在三次执行相同，动态import路径都指向P1；minicode/scripts对1de无diff。前后并未使用相同pytest完整argv：旧只选failed参数，新覆盖两个；相同的是该failed场景、真实生产、解释器/seed/隔离政策及未修改的排序plugin。

原nonformal串行检查断言、真实候选编辑与独立review、同Executor/model/session、预算精确计账、父目录提交保护、最终源码/回归测试、audit及commit-ready、临时workspace清理断言全部保留。最终两情形都committed、6个真实fixture模型请求，预算上限500000token/40calls未变。测试没有真实provider调用。

从自然调度成功运行捕获实际commands/request，直接执行最终helper及**模型外层最终断言**的原AST：两组实际记录通过；重复check、缺失check、未知check ID、错argv、拆分assignment、拆分digest、退出码错配7种人工记录变异全部拒绝。它们是局部断言敏感性证明，非端到端生产故障，也非新增历史bug；详见association-sensitivity.json。未把异常藏在会被agent loop吞掉的fake model断言里当成功。

scoped Ruff(E/F,ignoreE501,no-cache)及git diff --check通过；命令输出来自工具记录，见static-checks.json，未伪称有独立保留的原始process log。

## 证据与收尾

原完整CIraw/XML/summary保存在`../ci-40124691703/`；allowlist包含各一次，SHA与源路径明确，打包时若已公开同字节原件可引用现有manifest，不能只留摘要。其余包括旧/新fixture、patch、受控plugin、实际观测、运行argv/meta/import来源、三份日志和敏感性脚本；不含HOME、pytest cache或临时workflow树。

root已只读审阅patch与完整排序plugin并报告无阻塞；本最终报告仍交root复核。尚无修订后的完整CI结论，不自动提交、打包或更新文档。
