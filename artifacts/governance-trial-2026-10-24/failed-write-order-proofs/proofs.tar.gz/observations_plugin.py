"""Capture only the final fixture's own checker records for sensitivity review."""
import json
import os
from pathlib import Path
import sys
import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if not item.name.startswith('test_failed_final_write_returns_to_same_executor_before_delivery'):
        yield
        return
    previous = sys.getprofile()
    captured = {}
    def profile(frame,event,arg):
        if event == 'return' and frame.f_code.co_name == 'test_failed_final_write_returns_to_same_executor_before_delivery':
            values=frame.f_locals
            captured.update(commands=values['commands'],request=values['request'],initialChecksPass=values['initial_checks_pass'])
        if previous is not None:
            previous(frame,event,arg)
    sys.setprofile(profile)
    try:
        yield
    finally:
        sys.setprofile(previous)
        target=Path(os.environ['ORDER_PROOF']).with_name('actual-observer-records.json')
        prior=json.loads(target.read_text()) if target.exists() else {}
        prior[item.nodeid]=captured
        target.write_text(json.dumps(prior,indent=2)+'\n')
