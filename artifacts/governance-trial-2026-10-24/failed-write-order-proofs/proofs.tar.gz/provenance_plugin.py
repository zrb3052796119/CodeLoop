import hashlib,importlib,json,os
from pathlib import Path

def pytest_sessionstart(session):
    root=Path(os.environ['PROOF_ROOT']).resolve()
    rows=[]
    for name in ('minicode.agent_loop','minicode.deterministic_verifier','minicode.workflow_runner','minicode.tools.task'):
        module=importlib.import_module(name)
        path=Path(module.__file__).resolve()
        assert path.is_relative_to(root), (name,str(path))
        rows.append({'module':name,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    Path(os.environ['IMPORT_PROOF']).write_text(json.dumps(rows,indent=2)+'\n')
