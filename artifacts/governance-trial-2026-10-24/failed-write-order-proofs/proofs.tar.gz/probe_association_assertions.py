"""Synthetic record corruption against the exact final helper + outer assertion.

Uses observations from a real successful workflow; does not mutate production
or claim these corruptions happened in CI.
"""
import ast
from copy import deepcopy
import hashlib,json
from pathlib import Path
b=Path(__file__).parent
source=(b/'final_test_failed_write_candidate_continuation.py').read_bytes()
root=ast.parse(source)
test=next(n for n in root.body if isinstance(n,ast.FunctionDef) and n.name=='test_failed_final_write_returns_to_same_executor_before_delivery')
helper=next(n for n in test.body if isinstance(n,ast.FunctionDef) and n.name=='formal_rounds')
assertions=[n for n in test.body if isinstance(n,ast.Assert) and any(isinstance(c,ast.Call) and isinstance(c.func,ast.Name) and c.func.id=='formal_rounds' for c in ast.walk(n))]
assert len(assertions)==1
code=compile(ast.fix_missing_locations(ast.Module(body=[helper,*assertions],type_ignores=[])),'final-fixture-helper-and-outer-assert','exec')
observed=json.loads((b/'actual-observer-records.json').read_text())
def evaluate(row,mutator=None):
    state=deepcopy(row)
    for item in state['commands']: item['argv']=tuple(item['argv'])
    if mutator:mutator(state['commands'])
    namespace={'commands':state['commands'],'request':state['request'],'initial_checks_pass':state['initialChecksPass']}
    try:exec(code,namespace)
    except (AssertionError,KeyError) as exc:return {'accepted':False,'exception':type(exc).__name__,'message':str(exc)}
    return {'accepted':True}
rows=[]
for node,record in observed.items():
    verdict=evaluate(record);assert verdict['accepted']
    rows.append({'name':'actual-positive','node':node,**verdict})
record=next(v for v in observed.values() if not v['initialChecksPass'])
def formal(items):return [i for i,x in enumerate(items) if x['formal']]
def duplicate(items):items.append(deepcopy(items[formal(items)[0]]))
def missing(items):items.pop(formal(items)[0])
def unknown(items):items[formal(items)[0]]['checkId']='unexpected'
def argv(items):items[formal(items)[0]]['argv']=('python','-m','pytest','-q','unrequested.py')
def assignment(items):items[formal(items)[0]]['assignmentId']+='-other'
def digest(items):items[formal(items)[0]]['patchDigest']+='-other'
def mismatch_exit(items):
    a,c=formal(items)[:2]
    items[a]['exit'],items[c]['exit']=items[c]['exit'],items[a]['exit']
for name,mutator in [('duplicate-check',duplicate),('missing-check',missing),('unexpected-check-id',unknown),('wrong-request-argv',argv),('split-assignment',assignment),('split-patch-digest',digest),('wrong-exit-association',mismatch_exit)]:
    verdict=evaluate(record,mutator);assert not verdict['accepted'],name
    rows.append({'name':name,'synthetic':True,**verdict})
result={'status':'7_synthetic_record_corruptions_rejected','fixtureSha256':hashlib.sha256(source).hexdigest(),'actualRecordsSha256':hashlib.sha256((b/'actual-observer-records.json').read_bytes()).hexdigest(),'scope':'Exact final fixture helper and its outer assert executed on captured actual records. Not end-to-end fault injection, historical product bug proof, or an additional pytest count.','results':rows}
(b/'association-sensitivity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
