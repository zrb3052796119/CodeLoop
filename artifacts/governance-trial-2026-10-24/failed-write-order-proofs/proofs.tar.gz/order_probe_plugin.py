"""Order real concurrent ObservedVerifier calls; do not fabricate results."""
import json
import os
from pathlib import Path
import threading
import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if not item.name.startswith('test_failed_final_write_returns_to_same_executor_before_delivery'):
        yield
        return
    records, gates = [], {}
    lock = threading.Lock()
    base = item.module.DeterministicVerifier
    def bind(cls, **_kwargs):
        if cls.__name__ != 'ObservedVerifier':
            return
        original = cls.run
        def ordered(self, **kwargs):
            formal = getattr(kwargs['evidence_sink'], '__name__', '') == 'per_check_sink'
            if not formal:
                return original(self, **kwargs)
            assert len(kwargs['checks']) == 1
            check_id = kwargs['checks'][0].check_id
            assert check_id in ('compat', 'regression')
            key = (kwargs['execution_assignment_id'], kwargs['patch_digest'])
            source = (Path(kwargs['cwd']) / 'candidate.py').read_text()
            assert source in (item.module.PARTIAL, item.module.GREEN_PENDING, item.module.COMPLETE)
            with lock:
                gate = gates.setdefault(key, {'barrier': threading.Barrier(2), 'done': threading.Event()})
                records.append({'event':'entered','checkId':check_id,'assignmentId':key[0],
                    'patchDigest':key[1],'source':source,'thread':threading.current_thread().name})
            gate['barrier'].wait(timeout=10)
            if check_id != 'regression':
                assert gate['done'].wait(timeout=10), 'real regression verifier did not finish'
            try:
                result = original(self, **kwargs)
                with lock:
                    records.append({'event':'returned-after-observer-append','checkId':check_id,
                        'assignmentId':key[0],'patchDigest':key[1],'result':result})
                return result
            finally:
                if check_id == 'regression':
                    gate['done'].set()
        cls.run = ordered
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(base,'__init_subclass__',classmethod(bind),raising=False)
        try:
            yield
        finally:
            target=Path(os.environ['ORDER_PROOF'])
            prior=json.loads(target.read_text()) if target.exists() else {}
            prior[item.nodeid]=records
            target.write_text(json.dumps(prior,indent=2)+'\n')
