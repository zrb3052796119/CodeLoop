import hashlib,json,os,subprocess,sys,time
from pathlib import Path
b=Path(__file__).parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
label=sys.argv[1]
python='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
argv=[python,'-m','pytest','-q','-s','-o',f'cache_dir={b}/pytest-cache','--randomly-seed=20261024','-p','provenance_plugin',*sys.argv[2:]]
env={k:v for k,v in os.environ.items() if not k.startswith(('MINI_CODE_','MINICODE_')) and k not in ('PYTEST_ADDOPTS','PYTEST_PLUGINS') and not any(t in k for t in ('TOKEN','API_KEY','SECRET','PASSWORD','CREDENTIAL'))}
home=b/('home-'+label);home.mkdir(exist_ok=False)
env.update(HOME=str(home),PYTHONPATH=os.pathsep.join((str(b),str(root),str(root/'tests'))),PYTHONDONTWRITEBYTECODE='1',PROOF_ROOT=str(root),IMPORT_PROOF=str(b/(label+'-imports.json')),ORDER_PROOF=str(b/(label+'-order.json')))
files=['tests/test_failed_write_candidate_continuation.py','minicode/agent_loop.py','minicode/deterministic_verifier.py','minicode/workflow_runner.py','minicode/tools/task.py']
snapshot=lambda:{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
before=snapshot();started=time.monotonic()
with (b/(label+'.log')).open('w') as out:
    result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90)
meta={'label':label,'argv':argv,'cwd':str(root),'exitCode':result.returncode,'seconds':time.monotonic()-started,'sourceBefore':before,'sourceAfter':snapshot()}
(b/(label+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2));print((b/(label+'.log')).read_text()[-18000:])
