"""Run the final fixture's exact grouping and final assertion on observed results."""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path

p=Path(__file__).parent
source=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main/tests/test_repeated_candidate_repair.py')
tree=ast.parse(source.read_bytes())
test=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_second_'))
helper=next(n for n in test.body if isinstance(n,ast.FunctionDef) and n.name=='formal_rounds')
request=ast.literal_eval(next(n.value for n in test.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='request' for t in n.targets)))
final_assert=next(n for n in test.body if isinstance(n,ast.Assert) and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Call) and isinstance(n.test.left.func,ast.Name) and n.test.left.func.id=='formal_rounds')
program=compile(ast.Module(body=[helper,final_assert],type_ignores=[]),str(source),'exec')
argv={check['checkId']:tuple(check['argv']) for check in request['verificationChecks']}
observed=json.loads((p/'after-controlled-order.json').read_text())
commands=[]
for event in observed:
    if event['event']!='returned-after-observer-append':continue
    result=event['result']
    for check in result['checks']:
        commands.append({'formal':True,'checkId':check['checkId'],'exit':check['exitCode'],
                         'assignmentId':result['executionAssignmentId'],'patchDigest':result['patchDigest'],
                         'argv':argv[check['checkId']]})
assert len(commands)==6
cases={'observed-reversed-completion':commands}
fault=deepcopy(commands);fault[0]['exit'],fault[1]['exit']=fault[1]['exit'],fault[0]['exit'];cases['swapped-check-exit-association']=fault
fault=deepcopy(commands);fault.insert(1,deepcopy(fault[0]));cases['duplicate-result']=fault
fault=deepcopy(commands);fault[0]['argv']=argv['regression'];cases['wrong-command-argv']=fault
fault=deepcopy(commands);fault[0]['patchDigest']='different-candidate';cases['cross-candidate-result']=fault
fault=deepcopy(commands);del fault[0];cases['missing-check']=fault
fault=deepcopy(commands);fault[:4]=fault[2:4]+fault[:2];cases['wrong-repair-round-sequence']=fault
results=[]
for name,rows in cases.items():
    try:
        exec(program,{'commands':rows,'request':request})
    except AssertionError as error:
        status='rejected';detail=str(error)
    else:
        status='accepted';detail=None
    results.append({'case':name,'status':status,'detail':detail})
assert results[0]['status']=='accepted' and all(r['status']=='rejected' for r in results[1:])
report={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'helperLine':helper.lineno,'assertionLine':final_assert.lineno,'cases':results,'scope':'Exact final fixture helper and final assertion extracted through AST, using real observed result identities plus deliberately corrupted copies; synthetic assertion sensitivity, not historical production defects.'}
(p/'association-sensitivity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
