# Repeated repair: result association, not callback completion order

The old macOS 3.11 CI failure is a fixture assumption. Production runs independent checks concurrently and restores request order only when aggregating their results/evidence. The local `ObservedVerifier` instead appends from each returning worker. A real Barrier/Event schedule reproduces the exact old `[0,2,1,0]` assertion failure while the workflow commits and seven model calls/budget assertions hold. No verifier result or command execution is mocked by the ordering probe.

The fixture now identifies each candidate by assignment plus patch digest, then binds each result to check ID and argv. It rejects duplicates or missing checks and still requires three exact rounds: compat always 0; regression 2 → 1 → 0. The Analyst selects the current regression result instead of whichever callback finished last. Existing same-Executor, frozen candidate, budget, durable audit, review and commit assertions remain.

The old fixture fails under the controlled schedule (8.28s); the new fixture passes that same schedule (8.90s), the native single-case run (8.31s), and a schedule reversing every round (8.78s). These are executions of one test. Production is unchanged from pushed `8fba3787`; this is not a same-test red/green production repair. The exact final helper and final assertion also reject six synthetic association corruptions without executing extra workflows.

Independent read-only review is GO. No full suite/quality was run and no Git commit was created by this task. New full CI remains pending; the existing 8fba run keeps its original identity. ROOT and Phase 2 are untouched. The controlled schedule does not recover the unobserved old CI interleaving.
