"""Force a permitted completion order with real workers and real verifier results."""
import json
import os
from pathlib import Path
import threading

import pytest


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.name != 'test_second_actionable_failure_resumes_same_executor_with_budget_and_candidate':
        yield
        return
    records = []
    gates = {}
    lock = threading.Lock()
    base = item.module.DeterministicVerifier

    def bind(cls, **_kwargs):
        if cls.__name__ != 'ObservedVerifier':
            return
        original = cls.run

        def ordered(self, **kwargs):
            formal = getattr(kwargs['evidence_sink'], '__name__', '') == 'per_check_sink'
            if not formal:
                return original(self, **kwargs)
            checks = kwargs['checks']
            assert len(checks) == 1
            check_id = checks[0].check_id
            assert check_id in ('compat', 'regression')
            cwd = Path(kwargs['cwd'])
            candidate = (cwd / 'candidate.py').read_text()
            regression = (cwd / 'test_none.py').read_text()
            if regression == item.module.BAD_TEST:
                phase, first = 'bad-regression', 'regression'
            elif candidate == item.module.PARTIAL:
                phase, first = 'product-failure', 'regression'
            else:
                assert candidate == item.module.COMPLETE
                phase, first = 'repaired', 'regression'
            key = (kwargs['execution_assignment_id'], kwargs['patch_digest'])
            with lock:
                gate = gates.setdefault(key, {'barrier': threading.Barrier(2), 'done': threading.Event()})
                records.append({'event': 'entered', 'phase': phase, 'checkId': check_id,
                                'thread': threading.current_thread().name,
                                'assignmentId': key[0], 'patchDigest': key[1]})
            gate['barrier'].wait(timeout=10)
            if check_id != first:
                assert gate['done'].wait(timeout=10), 'first real verifier did not finish'
            try:
                result = original(self, **kwargs)
                with lock:
                    records.append({'event': 'returned-after-observer-append', 'phase': phase,
                                    'checkId': check_id, 'result': result})
                return result
            finally:
                if check_id == first:
                    gate['done'].set()

        cls.run = ordered

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(base, '__init_subclass__', classmethod(bind), raising=False)
        try:
            yield
        finally:
            Path(os.environ['REPAIR_ORDER_PROOF']).write_text(json.dumps(records, indent=2)+'\n')
