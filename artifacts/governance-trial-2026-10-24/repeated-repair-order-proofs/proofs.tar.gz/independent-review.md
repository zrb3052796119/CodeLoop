# Independent repeated-repair fixture review

GO for the single test-file change; no blocking finding. Read-only review only: the reviewer ran no tests and changed no production or fixture source.

Final test SHA-256: `206bffcdc88b678941e20f8e46c0762fa98a7584857e0967cb4c1b6ec7f51ba7`.

The new observer preserves the actual result checkId, request argv, assignmentId and patchDigest. It checks the returned check set against the requested check set, groups formal checks by candidate identity, rejects duplicate checks, and requires each round's complete check set. External assertions still require exactly three candidate rounds: compatibility succeeds in each, and the regression exits are 2 then 1 then 0. This does not sort exit codes or drop unexpected results. Analyst diagnosis now reads the regression result within the current candidate round, rather than whichever concurrent callback appended last. Candidate rounds themselves are causally sequential; the removed assumption concerns completion order within a round.

The original budget, session continuity, candidate contents, final commit and audit assertions remain. Assertions inside the worker are supplemented by the external exact round checks, so a swallowed worker assertion cannot by itself make those result-association checks pass.

Reviewed author evidence: the same real Barrier/Event ordering plugin and unchanged production hashes yield old fixture failure at its append-order assertion (workflow already committed, seven model calls), then final fixture pass. Native and all-reversed final runs also pass. The synthetic association probe uses the final helper and assertion against recorded result identities: wrong check/exit association, duplicate, wrong argv, cross-candidate, missing check and wrong round order are rejected. These are assertion-sensitivity checks, not historical production bugs. The independent reviewer did not rerun them, and repeated runs are not additive test coverage.

Limits: request argv is linked through the real verifier's returned checkId, not an independent syscall-level command trace; this is sufficient for this fixture's ordering correction and does not prove the verifier's implementation separately. No full-suite or CI-green claim is made.
