import hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
label=sys.argv[1]
python='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
argv=[python,'-m','pytest','-q','-o',f'cache_dir={p}/pytest-cache','--randomly-seed=20261024',*sys.argv[2:]]
env={k:v for k,v in os.environ.items() if not k.startswith('MINI_CODE_') and k not in ('PYTEST_ADDOPTS','PYTEST_PLUGINS') and not any(t in k for t in ('TOKEN','API_KEY','SECRET','PASSWORD','CREDENTIAL'))}
home=p/('home-'+label);home.mkdir(exist_ok=True)
env.update(HOME=str(home),PYTHONPATH=os.pathsep.join((str(p),str(root))),REPAIR_ORDER_PROOF=str(p/(label+'-order.json')))
t=time.monotonic()
with (p/(label+'.log')).open('w') as out:
 r=subprocess.run(argv,env=env,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=60)
meta={'label':label,'argv':argv,'cwd':str(root),'exitCode':r.returncode,'seconds':time.monotonic()-t,'testSha256':hashlib.sha256((root/'tests/test_repeated_candidate_repair.py').read_bytes()).hexdigest(),'productionSha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ('minicode/deterministic_verifier.py','minicode/workflow_runner.py')}}
(p/(label+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2));print((p/(label+'.log')).read_text())
