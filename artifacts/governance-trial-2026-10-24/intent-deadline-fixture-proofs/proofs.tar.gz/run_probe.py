import hashlib,json,os,subprocess,sys,time
from pathlib import Path
b=Path(__file__).parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
label=sys.argv[1]
python='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
argv=[python,'-m','pytest','-q','-o',f'cache_dir={b}/pytest-cache','--randomly-seed=20261024','-p','provenance_plugin',*sys.argv[2:]]
env={k:v for k,v in os.environ.items() if not k.startswith(('MINI_CODE_','MINICODE_')) and k not in ('PYTEST_ADDOPTS','PYTEST_PLUGINS') and not any(t in k for t in ('TOKEN','API_KEY','SECRET','PASSWORD','CREDENTIAL'))}
home=b/('home-'+label);home.mkdir(exist_ok=False)
env.update(HOME=str(home),PYTHONPATH=os.pathsep.join((str(b),str(root),str(root/'tests'))),PYTHONDONTWRITEBYTECODE='1',PROOF_ROOT=str(root),IMPORT_PROOF=str(b/(label+'-imports.json')),ORDER_PROOF=str(b/(label+'-observation.json')))
files=['tests/test_intent_semantic_classifier.py','minicode/intent_semantic_classifier.py','minicode/model_call_control.py','minicode/agent_budget.py','minicode/intent_parser.py']
snapshot=lambda:{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
before=snapshot();started=time.monotonic()
with (b/(label+'.log')).open('x') as out:
    result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90)
meta={'label':label,'argv':argv,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'exitCode':result.returncode,'seconds':time.monotonic()-started,'sourceBefore':before,'sourceAfter':snapshot(),'testSha':before[files[0]],'credentialsStripped':True,'independentHome':True}
(b/(label+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'label':label,'exitCode':result.returncode,'seconds':meta['seconds']},indent=2));print((b/(label+'.log')).read_text()[-7000:])
