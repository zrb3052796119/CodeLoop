# Intent semantic deadline fixture: causal diagnosis and repair

The failure is a test-precondition gap. The test intends to check that an elapsed parent deadline takes precedence over an exception **after provider entry**, but its 5 ms real-time deadline could expire during preparation. Production correctly rejects that case before reserving budget or emitting `model.started`. Only `tests/test_intent_semantic_classifier.py` changed; production remains byte-identical to `ed21acb302a548e1c3c9ddf3a989e9c113fa7d47`.

## Historical evidence and causal limit

Main CI run `40146728915`, attempt 1, macOS 3.12 job `121029558209`, actual head/checkout `ed21acb302a548e1c3c9ddf3a989e9c113fa7d47`, seed **52**, ended **14,962 passed / 1 failed / 8 skipped**. The `provider_error0` case raised the expected `ModelCallDeadlineExceeded`, then failed at old line 785 because `sink.events` was empty. The XML duration was 0.009 s, shorter than the fixture's 0.02 s provider sleep. This supports preflight expiry, but the exact CI interleaving is unknown. Original raw log, XML and summary retain their SHA identities in `original-ci-sources.json`; the precise XML case is in `original-ci-target.json`.

The unchanged production path is explicit: `minicode/intent_semantic_classifier.py:513` checks the parent deadline before reservation at 538 and the started event at 564. The actual model call begins at 570; its exception handlers recheck parent controls and settle the estimate. Empty events and zero usage are lawful for the earlier path.

The original fixture was compared byte-for-byte with the CI commit. A natural local run produced **1 failed / 1 passed** at the same empty-event assertion. A controlled wrapper then introduced 20 ms preparation latency before the actual `infer`, without fabricating outcomes. Both old cases failed; observations show **0 provider calls, no events, no budget usage**. This is a sufficient causal counterexample, not a replay of the unknown CI scheduling.

## Minimal fixture change

The final fixture rebinds only the classifier/control modules' local `time` attributes. It never modifies the shared stdlib clock. The original 5 ms deadline is valid when the real `call_model_next` reaches `model.next`; only then does the fake provider advance the local clock by 20 ms and raise the original parameterized exception through the existing `_Model` method. Both ConnectionError and TimeoutError remain covered.

Assertions outside the provider verify the exact control exception, one actual call, valid entry deadline, started event and positive reservation at entry, unchanged forwarded deadline, released reservation, exact estimated input charge, zero output charge, uncertain usage, complete started/failed event sequence with matching operation ID and timeout classification, and absence of the private exception text. This prevents either an early rejection or an assertion swallowed as a provider error from passing the test.

Final test SHA-256: `3e5aa848a5b8b516cedd153082ad2fcd14ca70b7120714787cd942710203cef2`. Original SHA-256: `0b232b5f5005a7db7765a5764dab5159a621a8ee4a2dd48a1f445dc80eea33a4`. `final-source-verification.json` binds each local run to identical production bytes and the expected P1 import paths.

## Results and scope

All local runs use seed **20261024**, isolated HOME and cleared credential/config environment variables. CI used seed 52; these identities are not interchangeable.

| Run | Pytest result | Exit |
| --- | --- | --- |
| `after-controlled` | 2 passed in 0.33s | 0 |
| `after-native` | 2 passed in 0.31s | 0 |
| `after-related` | no tests ran in 0.00s | 4 |
| `before-controlled` | 2 failed in 0.36s | 1 |
| `before-native` | 1 failed, 1 passed in 0.30s | 1 |
| `fault-charge` | 1 failed in 0.32s | 1 |
| `fault-event` | 1 failed in 0.32s | 1 |
| `fault-parent-recheck` | 1 failed in 0.30s | 1 |
| `fault-preflight` | 1 failed in 0.33s | 1 |
| `final-related` | 81 passed in 0.78s | 0 |
| `restored-target` | 2 passed in 0.30s | 0 |

The successful related run covers the full semantic-classifier, semantic-calibration and turn-cancellation files: **81 passed in 0.78 s**. The target's 2 cases are inside those 81; the controlled, natural and restored 2-case runs overlap and must not be added. `after-related` is an explicitly invalid first command referencing nonexistent `tests/test_model_call_control.py`; its exit 4 and no-tests output remain preserved and are not validation. Ruff with `--no-cache` and `git diff --check` passed.

Four synthetic faults precisely fail the final fixture: omit post-provider parent recheck (expected exception absent); omit estimate charge (0 versus the actual reserved 696); omit failed event (incomplete event sequence); reject before provider entry (0 calls versus 1). These are sensitivity checks, not claims of historical production bugs. Production is identical before and after, so no production-bug “PROVEN” result is claimed.

The architecture agent's `independent-review.md/json` concludes GO with no blocking findings after read-only code and evidence review; it is not a second execution of the author's runs. Root separately rechecked all 439 existing quality input files and found identical bytes; the changed fixture is outside that set (`intent-deadline-quality-identity.json`). This permits reuse of the earlier source-bound quality evidence, not a claim of a newly run quality or complete suite. New CI remains pending. This work did not run the full suite, quality tasks or APIs, did not inspect r3 trial/results, and did not modify ROOT, production, scripts, config or the parent-owned five documents. Only the test file is ready for the parent's review and commit; no commit/push or evidence packaging was performed here.
