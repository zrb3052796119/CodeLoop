"""Synthetic boundary faults, not historical production defects."""
import pytest

def pytest_addoption(parser):
    parser.addoption('--intent-proof-fault',action='store',default='')

@pytest.fixture(autouse=True)
def injected_fault(request,monkeypatch):
    mode=request.config.getoption('--intent-proof-fault')
    if not mode or 'test_provider_exception_does_not_mask_elapsed_parent_deadline[' not in request.node.nodeid:
        return
    import minicode.intent_semantic_classifier as module
    cls=module.BudgetedSemanticIntentClassifier
    if mode=='omit-parent-recheck':
        original=cls.infer;checkpoint=module.checkpoint_model_call;owner={}
        def infer(self,*args,**kwargs):
            owner['model']=self._model
            return original(self,*args,**kwargs)
        def ignore_after_provider(**kwargs):
            if owner['model'].calls:
                return
            return checkpoint(**kwargs)
        monkeypatch.setattr(cls,'infer',infer)
        monkeypatch.setattr(module,'checkpoint_model_call',ignore_after_provider)
    elif mode=='omit-estimated-charge':
        def settle_without_charge(budget,reservation,*,charge_estimate=False):
            budget.fail_model_call(reservation,charge_estimate=False)
        monkeypatch.setattr(cls,'_fail_reservation',staticmethod(settle_without_charge))
    elif mode=='omit-failed-event':
        monkeypatch.setattr(cls,'_emit_failure',staticmethod(lambda *args,**kwargs:None))
    elif mode=='reject-before-provider':
        def reject(*args,**kwargs):
            raise module.ModelCallDeadlineExceeded('synthetic premature deadline rejection')
        monkeypatch.setattr(module,'call_model_next',reject)
    else:
        raise ValueError(mode)
