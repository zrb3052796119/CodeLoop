"""Controlled preparation latency, not a claim about the exact CI interleaving."""
import json,os,time
from pathlib import Path
import pytest

@pytest.fixture(autouse=True)
def observed_preflight_delay(request,monkeypatch):
    if 'test_provider_exception_does_not_mask_elapsed_parent_deadline[' not in request.node.nodeid:
        return
    import minicode.intent_semantic_classifier as module
    original=module.BudgetedSemanticIntentClassifier.infer
    def delayed(self,semantic_request,*,call_context=None):
        real_start=time.monotonic()
        time.sleep(0.02)
        elapsed=time.monotonic()-real_start
        record={'node':request.node.nodeid,'realPreparationSeconds':elapsed,'preflightDelaySeconds':0.02}
        try:
            return original(self,semantic_request,call_context=call_context)
        finally:
            budget=call_context['agent_budget'];sink=call_context['event_sink']
            snapshot=budget.snapshot()
            record.update(modelCalls=self._model.calls,eventTypes=[e.event_type for e in sink.events],usedModelCalls=snapshot.used_model_calls,reservedTokens=snapshot.reserved_total_tokens,usedInputTokens=snapshot.used_input_tokens)
            p=Path(os.environ['ORDER_PROOF']);rows=json.loads(p.read_text()) if p.exists() else []
            rows.append(record);p.write_text(json.dumps(rows,indent=2)+'\n')
    monkeypatch.setattr(module.BudgetedSemanticIntentClassifier,'infer',delayed)
