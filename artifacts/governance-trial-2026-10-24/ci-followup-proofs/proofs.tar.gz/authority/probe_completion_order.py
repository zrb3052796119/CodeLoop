"""Schedule the original event signal before ToolResult creation; real pools/results."""
from pathlib import Path
import importlib.util
import json
import inspect
import pytest
import sys
import threading
import time
import traceback
from types import SimpleNamespace

root=Path(sys.argv[1]).resolve()
expect_completed = sys.argv[2] == 'completed'
sys.path.insert(0,str(root))
import minicode.agent_loop as loop
assert Path(loop.__file__).resolve() == (root/'minicode/agent_loop.py').resolve()
spec=importlib.util.spec_from_file_location('original_cancellation_test',root/'tests/test_agent_cancellation.py')
test=importlib.util.module_from_spec(spec);spec.loader.exec_module(test)
records=[]
lock=threading.Lock()
release=threading.Event()

def record(event,**data):
 with lock:
  records.append({'index':len(records),'event':event,'thread':threading.current_thread().name,'monotonicNs':time.monotonic_ns(),**data})

class ControlledSignal(threading.Event):
 def set(self):
  super().set()
  record('fixture_signal_set')
  if threading.current_thread() is threading.main_thread():
   # add_done_callback may execute immediately when the real Future already
   # completed before registration. Do not block dispatch in that valid case.
   assert expect_completed
   record('completed_before_callback_registration')
   return
  assert release.wait(5), 'probe reducer never observed fatal'
  record('signal_set_returned')

original_reduce=loop._reduce_concurrent_batch_shutdown

def observing_reduce(**kwargs):
 states={c['id']:{'done':f.done(),'running':f.running(),'observedResult':f in kwargs['observed_results'],'observedError':f in kwargs['observed_errors']} for f,c in kwargs['future_to_call'].items()}
 record('reducer_enter',futureStates=states)
 decision=original_reduce(**kwargs)
 record('reducer_decided',mustDeliver=decision.must_deliver,control=type(decision.control_error).__name__,dispositions={d.call['id']:d.status for d in decision.dispositions})
 release.set()
 authority=next(f for f,c in kwargs['future_to_call'].items() if c['id']=='authority')
 result=authority.result(timeout=5)
 record('authority_future_eventually_complete',done=authority.done(),mustDeliver=result._must_deliver)
 return decision

test.threading=SimpleNamespace(Event=ControlledSignal)
loop._reduce_concurrent_batch_shutdown=observing_reduce
error=None
patch=pytest.MonkeyPatch()
try:
 function=test.test_concurrent_finalized_authority_outranks_fatal_without_cancellation
 function(**({'monkeypatch':patch} if 'monkeypatch' in inspect.signature(function).parameters else {}))
except BaseException as exc:
 error=exc
 record('original_test_raised',error=type(exc).__name__,message=str(exc))
 traceback.print_exc()
finally:
 release.set()
 loop._reduce_concurrent_batch_shutdown=original_reduce
 patch.undo()
print(json.dumps({'root':str(root),'productionOrigin':loop.__file__,'records':records},indent=2),flush=True)
state=next(r['futureStates']['authority'] for r in records if r['event']=='reducer_enter')
decision=next(r for r in records if r['event']=='reducer_decided')
if expect_completed:
 assert error is None,repr(error)
 assert state['done'] is True
 assert decision['mustDeliver'] is True
 assert decision['control']=='NoneType'
 assert decision['dispositions']=={'authority':'completed','fatal':'failed'}
else:
 assert isinstance(error,SystemExit),repr(error)
 assert state=={'done':False,'running':True,'observedResult':False,'observedError':False}
 assert decision['mustDeliver'] is False
 assert decision['control']=='SystemExit'
 assert decision['dispositions']=={'authority':'abandoned_running','fatal':'failed'}
print('PROBE CONFIRMED:', 'completed authority wins' if expect_completed else 'premature signal is insufficient')
