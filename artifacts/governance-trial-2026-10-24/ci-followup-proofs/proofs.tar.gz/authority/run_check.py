from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path(__file__).parent
label=sys.argv[1];root=Path(sys.argv[2]).resolve();args=sys.argv[3:]
python='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
env={k:v for k,v in os.environ.items() if not k.startswith('MINI_CODE_') and not any(x in k for x in ('API_KEY','ACCESS_TOKEN','AUTH_TOKEN')) and k not in ('PYTEST_ADDOPTS','PYTEST_PLUGINS')}
home=base/(label+'-home');home.mkdir(exist_ok=True)
env.update(HOME=str(home),USERPROFILE=str(home),MINICODE_PYTEST_REAL_HOME=str(home),PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1')
started=time.time()
with (base/(label+'.log')).open('w') as log:
 result=subprocess.run([python,*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
meta={'harnessSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'probeSha256':hashlib.sha256(Path(args[0]).read_bytes()).hexdigest() if args and args[0].endswith('.py') else None,'label':label,'root':str(root),'command':[python,*args],'exitCode':result.returncode,'durationSeconds':time.time()-started,'sourceHashes':{rel:hashlib.sha256((root/rel).read_bytes()).hexdigest() for rel in ('minicode/agent_loop.py','tests/test_agent_cancellation.py')}}
(base/(label+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta));print((base/(label+'.log')).read_text()[-9000:])
raise SystemExit(result.returncode)
