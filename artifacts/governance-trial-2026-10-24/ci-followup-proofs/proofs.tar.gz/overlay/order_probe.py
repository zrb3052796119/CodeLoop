"""Exercise the actual archive fixture; vary only filesystem boundary behavior."""
import json
import os
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
sys.path[:0] = [str(root), '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/lib/python3.12/site-packages']
os.chdir(root)
import pytest

class FileBoundary:
    @pytest.fixture(autouse=True)
    def vary_directory_boundary(self, monkeypatch):
        real_iterdir = Path.iterdir
        def observed(path):
            if path.name == 'private' and path.parent.name == 'prepared':
                if mode == 'missing':
                    (path / 'coverage-recovery-receipt.json').unlink()
                elif mode == 'extra':
                    (path / 'unexpected.txt').write_text('unexpected artifact\n')
                entries = list(real_iterdir(path))
                print('ACTUAL_PRIVATE_FILES', sorted(p.name for p in entries))
                return iter(sorted(entries, key=lambda p:p.name, reverse=True))
            return real_iterdir(path)
        if mode != 'normal':
            monkeypatch.setattr(Path, 'iterdir', observed)
        yield

print(json.dumps({'python':sys.version,'root':str(root),'mode':mode,'pytest':pytest.__version__}), flush=True)
result = pytest.main(['-q','-s','-p','no:cacheprovider','tests/test_coverage_interruption_recovery.py::test_harness_prepares_and_restores_explicit_overlay_from_authenticated_archive'], plugins=[FileBoundary()])
origins = {n:m.__file__ for n,m in sys.modules.items() if n.startswith(('minicode','scripts.')) and getattr(m,'__file__',None)}
assert origins and all(Path(value).resolve().is_relative_to(root) for value in origins.values())
print(json.dumps({'all_origins_in_source_root':True,'module_count':len(origins)}),flush=True)
raise SystemExit(result)
