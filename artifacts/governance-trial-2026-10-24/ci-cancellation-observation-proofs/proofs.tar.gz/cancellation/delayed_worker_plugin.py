"""Controlled schedule of the unchanged original fixture, not a product mutation."""
import json
import os
import threading
from pathlib import Path
import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.name != 'test_cancel_after_concurrent_batch_starts_stops_before_next_model_turn':
        yield
        return
    release = threading.Event()
    blocked = threading.Event()
    passed_gate = threading.Event()
    prior = threading.gettrace()
    test_path = str(item.path)
    def trace(frame, event, arg):
        if (event == 'line' and frame.f_code.co_filename == test_path
                and frame.f_code.co_name == 'run'
                and frame.f_locals.get('name') == 'list_files'
                and frame.f_lineno == 821):
            blocked.set()
            assert release.wait(10), 'controlled schedule was not cleaned up'
            passed_gate.set()
        return trace
    threading.settrace(trace)
    observed = {}
    try:
        outcome = yield
        if outcome.excinfo:
            tb = outcome.excinfo[2]
            while tb:
                values = tb.tb_frame.f_locals
                if tb.tb_frame.f_code.co_name == item.name:
                    observed = {
                        'modelCallsBeforeRelease': values['model'].calls,
                        'turnAliveBeforeRelease': values['worker'].is_alive(),
                        'turnErrorBeforeRelease': type(values['outcome'].get('error')).__name__,
                        'finishedBeforeRelease': list(values['finished']),
                    }
                    break
                tb = tb.tb_next
    finally:
        release.set()
        if blocked.is_set():
            assert passed_gate.wait(5)
        threading.settrace(prior)
        Path(os.environ['CANCEL_PROBE_FACTS']).write_text(json.dumps({
            **observed,
            'heldWorkerBeforeAppend': blocked.is_set(),
            'workerReleasedAfterTestAssertion': passed_gate.is_set(),
            'testFailedWhileHeld': bool(outcome.excinfo),
            'productionModified': False,
            'schedule': 'list_files pauses after release.wait, before append; release at test-call teardown'
        }, indent=2)+'\n')
