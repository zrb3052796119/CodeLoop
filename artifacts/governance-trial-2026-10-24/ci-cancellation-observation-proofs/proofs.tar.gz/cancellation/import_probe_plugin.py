import hashlib,json,os
from pathlib import Path

def pytest_sessionfinish(session,exitstatus):
    import minicode.agent_loop, minicode.tooling, minicode.turn_cancellation
    records={}
    for module in (minicode.agent_loop,minicode.tooling,minicode.turn_cancellation):
        p=Path(module.__file__).resolve()
        records[module.__name__]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    Path(os.environ['CANCEL_PROBE_FACTS']).write_text(json.dumps({'exitStatus':exitstatus,'imports':records},indent=2)+'\n')
