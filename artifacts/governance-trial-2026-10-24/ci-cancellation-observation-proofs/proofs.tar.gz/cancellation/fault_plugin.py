"""Synthetic contract faults, only in a separate pytest process."""
import os
import pytest

@pytest.fixture(autouse=True)
def contract_fault(request,monkeypatch):
    if request.node.name != 'test_cancel_after_concurrent_batch_starts_stops_before_next_model_turn':
        return
    fault=os.environ['CANCEL_FAULT']
    if fault=='wait_for_workers':
        import concurrent.futures
        original=concurrent.futures.ThreadPoolExecutor.shutdown
        def force_wait(self,wait=True,*,cancel_futures=False):
            return original(self,wait=True,cancel_futures=cancel_futures)
        monkeypatch.setattr(concurrent.futures.ThreadPoolExecutor,'shutdown',force_wait)
    elif fault=='ignore_cancel':
        from minicode.turn_cancellation import TurnCancellationToken
        monkeypatch.setattr(TurnCancellationToken,'request',lambda self,*args,**kwargs:False)
    elif fault=='extra_model_call':
        original=request.module.run_agent_turn
        def extra_call(**kwargs):
            try:
                return original(**kwargs)
            finally:
                kwargs['model'].next([])
        monkeypatch.setattr(request.module,'run_agent_turn',extra_call)
    else:
        raise AssertionError('Unknown synthetic fault')
