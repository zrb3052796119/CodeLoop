import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
b=Path(__file__).parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
label=sys.argv[1];args=sys.argv[2:]
env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ('API_KEY','SECRET','TOKEN','PASSWORD','CREDENTIAL'))}
env.update(HOME=tempfile.mkdtemp(prefix='home-',dir=b),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(b)+os.pathsep+str(root),CANCEL_PROBE_FACTS=str(b/(label+'-facts.json')))
cmd=[str(Path('/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python')),'-m','pytest','-q','-p','no:cacheprovider','--randomly-seed=20261024',*args]
files=['minicode/agent_loop.py','minicode/tooling.py','minicode/turn_cancellation.py','tests/test_agent_cancellation.py']
snapshot=lambda:{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
meta={'command':cmd,'cwd':str(root),'sourceBefore':snapshot(),'started':time.time()}
with (b/(label+'.log')).open('x') as out:
 r=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
meta.update(exitCode=r.returncode,finished=time.time(),sourceAfter=snapshot());meta['durationSeconds']=meta['finished']-meta['started']
(b/(label+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'label':label,'exitCode':r.returncode,'durationSeconds':meta['durationSeconds']}));print((b/(label+'.log')).read_text())
raise SystemExit(r.returncode)
