from pathlib import Path
import hashlib,json,os,subprocess,sys,time
D=Path(__file__).resolve().parent
R=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
PY=Path('/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python')
source=Path(sys.argv[1]);label=sys.argv[2];plugin=sys.argv[3] if len(sys.argv)>3 else None
node=str(source)+'::test_hung_final_observation_is_bounded_and_does_not_erase_audit'
argv=[str(PY),'-m','pytest',node,'-q','--randomly-seed=20261024','-o','cache_dir='+str(D/'pytest-cache')]
if plugin:argv+=['-p',plugin]
env={k:v for k,v in os.environ.items() if not k.startswith('MINI_CODE_') and not any(s in k.upper() for s in ('API_KEY','AUTH_TOKEN','ACCESS_TOKEN')) and k not in ('PYTEST_ADDOPTS','PYTEST_PLUGINS')}
home=D/(label+'-home');home.mkdir(exist_ok=True);env.update(HOME=str(home),PYTHONPATH=str(D)+os.pathsep+str(R),PYTHONDONTWRITEBYTECODE='1',OBSERVATION_PROOF_LABEL=label)
started=time.time()
with (D/(label+'.log')).open('wb') as out:p=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=25)
meta={'argv':argv,'cwd':str(R),'exitCode':p.returncode,'durationSeconds':time.time()-started,'testSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'isolatedHome':True,'providerCredentialsRemoved':True,'plugin':plugin,'sourceFiles':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ('minicode/conflict_port_runner.py','minicode/workflow_runner.py','minicode/workflow_finalization.py')}}
(D/(label+'-runmeta.json')).write_text(json.dumps(meta,indent=2)+'\n');print(label,p.returncode)
