"""A logical outer-clock counterexample, not a reconstruction of CI scheduling."""
import json
import os
from pathlib import Path
from types import SimpleNamespace
import time

HERE = Path(__file__).resolve().parent
proof = {'classification': 'controlled outer elapsed observation; real workflow and port clock unchanged', 'outerClockOffsetSeconds': 0.6, 'portCalls': []}

def pytest_collection_modifyitems(items):
    assert len(items) == 1
    module = items[0].module
    offset = [0.0]
    module.time = SimpleNamespace(**vars(time))
    module.time.monotonic = lambda: time.monotonic() + offset[0]
    actual_run = module._run
    def run_with_outer_duration(*args, **kwargs):
        offset[0] += 0.6
        return actual_run(*args, **kwargs)
    module._run = run_with_outer_duration
    base = module.BoundedConflictPortRunner
    class ObservedRunner(base):
        def run(self, operation, **kwargs):
            start = time.monotonic()
            outcome = 'returned'
            try:
                return super().run(operation, **kwargs)
            except BaseException as exc:
                outcome = type(exc).__name__ + ':' + str(exc)
                raise
            finally:
                proof['portCalls'].append({'name': kwargs['port_name'], 'realElapsedSeconds': time.monotonic()-start, 'outcome': outcome})
    module.BoundedConflictPortRunner = ObservedRunner

def pytest_sessionfinish(session, exitstatus):
    proof['exitCode'] = int(exitstatus)
    (HERE/(os.environ['OBSERVATION_PROOF_LABEL']+'-outer-clock-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
