"""Inject one explicit implementation fault without modifying source files."""
from pathlib import Path
import difflib
import inspect
import json
import os
import textwrap

D=Path(__file__).resolve().parent

def pytest_collection_modifyitems(items):
    name=os.environ['OBSERVATION_FAULT']
    import minicode.conflict_port_runner as port
    import minicode.workflow_finalization as finalization
    if name in ('double-port-budget','premature-capacity-release'):
        owner=port.BoundedConflictPortRunner
        original=owner.run
        namespace=dict(vars(port))
        source=textwrap.dedent(inspect.getsource(original))
        if name=='double-port-budget':
            old='local_deadline = now + self._default_timeout_seconds'
            new='local_deadline = now + 2 * self._default_timeout_seconds'
        else:
            old='''    def settle(kind: str, value: object) -> bool:
        with state_lock:
            if terminal:
                return False
            terminal.append((kind, value))'''
            new=old.replace('            terminal.append((kind, value))','            self._capacity.release()\n            terminal.append((kind, value))')
        method_name='run'
    elif name=='omit-audit-persistence':
        owner=finalization
        method_name='_project_trace_and_audit'
        original=getattr(owner,method_name)
        namespace=dict(vars(finalization))
        source=textwrap.dedent(inspect.getsource(original))
        old='persisted = ports.persist_audit(scheduler_audit)'
        new='persisted = True  # synthetic fault: skip durable audit call'
    else:
        raise ValueError(name)
    assert source.count(old)==1
    changed=source.replace(old,new)
    mutant=D/(name+'.py')
    mutant.write_text('from __future__ import annotations\n'+changed)
    exec(compile(mutant.read_text(),str(mutant),'exec'),namespace)
    setattr(owner,method_name,namespace[method_name])
    (D/(name+'.patch')).write_text(''.join(difflib.unified_diff(source.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile='original-method',tofile='synthetic-fault-method')))
    (D/(name+'-injection.json')).write_text(json.dumps({'name':name,'owner':getattr(owner,'__name__',str(owner)),'method':method_name,'classification':'synthetic sensitivity probe, not historical defect proof','sourceFilesModified':False},indent=2)+'\n')
