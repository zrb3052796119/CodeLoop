"""Seal the explicit reviewed fixture-proof allowlist; never execute tests."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile
import tempfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
sha = lambda data: hashlib.sha256(data).hexdigest()


def main():
    selected = json.loads((BASE / 'final-allowlist.json').read_text())
    assert selected['status'] == 'reviewed_ready_to_seal'
    sources = {entry['archivePath']: Path(entry['sourcePath']) for entry in selected['files']}
    assert len(sources) == len(selected['files'])
    payload = {}
    for entry in selected['files']:
        name = PurePosixPath(entry['archivePath'])
        source = sources[entry['archivePath']]
        assert not name.is_absolute() and '..' not in name.parts and source.is_file() and not source.is_symlink()
        data = source.read_bytes()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
        payload[entry['archivePath']] = data
    for name, expected in selected['finalTestSha256'].items():
        assert sha((ROOT / name).read_bytes()) == expected
    production = sha(b''.join(p.relative_to(ROOT).as_posix().encode() + b'\0' + p.read_bytes()
                             for p in sorted((ROOT / 'minicode').rglob('*.py'))))
    assert production == selected['unchangedProductionContentSha256']
    payload['packaging/source-map.json'] = (json.dumps(selected, ensure_ascii=False, indent=2) + '\n').encode()
    payload['packaging/build_package.py'] = Path(__file__).read_bytes()
    payload = dict(sorted(payload.items()))

    def archive_bytes():
        target = io.BytesIO()
        with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0, compresslevel=1) as gz:
            with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as tar:
                for name, data in payload.items():
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    tar.addfile(info, io.BytesIO(data))
        return target.getvalue()

    archive = archive_bytes()
    assert archive == archive_bytes()
    out = BASE / 'package'
    out.mkdir(exist_ok=False)
    (out / 'proofs.tar.gz').write_bytes(archive)
    seen = set()
    with tempfile.TemporaryDirectory(prefix='fixture-proof-restore-', dir=BASE) as temp:
        with tarfile.open(out / 'proofs.tar.gz', 'r:gz') as tar:
            for member in tar:
                name = PurePosixPath(member.name)
                assert member.isfile() and not name.is_absolute() and '..' not in name.parts
                assert member.name in payload and member.name not in seen
                data = tar.extractfile(member).read()
                assert data == payload[member.name]
                destination = Path(temp).joinpath(*name.parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
                assert destination.read_bytes() == data
                seen.add(member.name)
    assert seen == set(payload)
    for entry in selected['files']:
        assert sha(Path(entry['sourcePath']).read_bytes()) == entry['sha256']
    manifest = {
        'schemaVersion': 1,
        'classification': 'Two existing CI fixture precondition repairs; production unchanged; no full CI acceptance claim',
        'ciRun': 40121258480, 'ciJob': 120953074058,
        'ciHead': '715dd1226ef6994990283994ab8db9293185b176',
        'ciActualMergeRef': 'd793e1e673f16cd7d2e6ab0c632a5b3e273ca290',
        'candidateBase': '1decc8134528aa9795f32deab58493a288153c02',
        'finalTestSha256': selected['finalTestSha256'],
        'unchangedProductionContentSha256': production,
        'archive': 'proofs.tar.gz', 'archiveSha256': sha(archive), 'archiveBytes': len(archive),
        'entryCount': len(payload), 'rawBytes': sum(map(len, payload.values())),
        'deterministicArchive': 'sorted USTAR, mode0644, uid/gid/mtime0, empty owners; gzip filename empty, mtime0, level1; two builds identical',
        'restorationVerification': {'allMembersRestored': True, 'memberBytesEqualOriginals': True, 'memberCount': len(seen)},
        'entries': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in payload.items()],
    }
    (out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    readme = (BASE / 'README.template.md').read_text()
    for key in ('entryCount', 'rawBytes', 'archiveBytes', 'archiveSha256'):
        readme = readme.replace('{{' + key + '}}', str(manifest[key]))
    assert '{{' not in readme
    (out / 'README.md').write_text(readme)
    print(json.dumps({k: v for k, v in manifest.items() if k != 'entries'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
