from pathlib import Path
import os, subprocess, sys
root=Path(sys.argv[1])
log=Path(sys.argv[2])
py='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
env={k:v for k,v in os.environ.items() if not (k.startswith(('MINI_CODE_','OPENAI_','ANTHROPIC_','DEEPSEEK_','GEMINI_','GOOGLE_API_','AZURE_OPENAI_','DASHSCOPE_','MOONSHOT_','ZHIPU_','MISTRAL_','COHERE_')) or k.endswith(('_API_KEY','_API_TOKEN')))}
home=Path('/private/tmp/codeloop-governance-20261024/phase1-implementation/home')
home.mkdir(exist_ok=True)
env.update(HOME=str(home),PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1')
with log.open('w') as out:
    code='import minicode.agent_loop as x; import pathlib; print(x.__file__, flush=True); assert pathlib.Path(x.__file__).resolve().is_relative_to(pathlib.Path.cwd())'
    p=subprocess.run([py,'-c',code],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    if p.returncode: sys.exit(p.returncode)
    p=subprocess.run([py,'-m','pytest','--randomly-seed=20261024',*sys.argv[3:],'-q'],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    sys.exit(p.returncode)
