from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tarfile, time
root=Path(sys.argv[1]).resolve(); label=sys.argv[2]
out=Path(__file__).resolve().parent/label;out.mkdir(exist_ok=True)
py='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
env={k:v for k,v in os.environ.items() if not (k.startswith(('MINI_CODE_','OPENAI_','ANTHROPIC_','DEEPSEEK_','GEMINI_','GOOGLE_API_','AZURE_OPENAI_','DASHSCOPE_','MOONSHOT_','ZHIPU_','MISTRAL_','COHERE_')) or k.endswith(('_API_KEY','_API_TOKEN')) or k in ('PYTHONPATH','PYTHONHOME'))}
home=out/'home';home.mkdir(exist_ok=True)
env.update(HOME=str(home),USERPROFILE=str(home),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PIP_NO_INDEX='1',PIP_DISABLE_PIP_VERSION_CHECK='1',PIP_NO_CACHE_DIR='1')
record={'root':str(root),'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'commands':[]}
def run(name,args,cwd):
    started=time.monotonic()
    result=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,check=False,timeout=180)
    (out/(name+'.stdout')).write_text(result.stdout);(out/(name+'.stderr')).write_text(result.stderr)
    record['commands'].append({'name':name,'argv':args,'cwd':str(cwd),'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3)})
    if result.returncode:
        (out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps(record,indent=2));sys.exit(result.returncode)
    return result.stdout
archive=out/'source.tar'
with archive.open('wb') as f:
    subprocess.run(['git','-C',str(root),'archive','--format=tar','HEAD'],stdout=f,check=True,timeout=60)
source=out/'source';source.mkdir(exist_ok=True)
with tarfile.open(archive) as bundle:bundle.extractall(source,filter='data')
wheel_dir=out/'wheel';wheel_dir.mkdir(exist_ok=True)
run('build',[py,'-m','pip','wheel','--no-deps','--no-build-isolation','--wheel-dir',str(wheel_dir),'.'],source)
wheels=list(wheel_dir.glob('*.whl'));assert len(wheels)==1
installed=out/'installed';installed.mkdir(exist_ok=True)
run('install',[py,'-m','pip','install','--no-deps','--target',str(installed),str(wheels[0])],out)
certifi=Path(run('dependency-location',[py,'-I','-c','import certifi; print(certifi.__file__)'],out).strip()).parent
shutil.copytree(certifi,installed/'certifi',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
record['dependency']={'name':'certifi','source':str(certifi),'files':{str(p.relative_to(certifi)):hashlib.sha256(p.read_bytes()).hexdigest() for p in certifi.rglob('*') if p.is_file() and '__pycache__' not in p.parts}}
modules=['minicode.main','minicode.gateway','minicode.cron_runner','minicode.headless','minicode.agent_loop','minicode.memory','minicode.memory_hybrid','minicode.memory_hybrid_runtime','minicode.intent_semantic_calibration_cli']
smoke='\n'.join(['import sys, importlib, json','from pathlib import Path',f'target = Path({str(installed)!r}).resolve()','sys.path.insert(0, str(target))',"assert all('site-packages' not in p and 'dist-packages' not in p for p in sys.path), sys.path",f'modules = {modules!r}','origins = {}','for name in modules:','    module = importlib.import_module(name)','    origin = Path(module.__file__).resolve()','    assert origin.is_relative_to(target), (name, str(origin))','    origins[name] = str(origin)','from minicode.agent_runtime import final_response_text',"assert final_response_text([{'role':'user','content':'x'},{'role':'tool_result','content':'committed'}]) == 'committed'",'print(json.dumps({"origins": origins, "sysPath": sys.path, "noSite": sys.flags.no_site, "isolated": sys.flags.isolated}, indent=2))'])
record['proof']=json.loads(run('wheel-only-imports',[py,'-I','-S','-c',smoke],out))
record.update(passed=True,archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),wheelSha256=hashlib.sha256(wheels[0].read_bytes()).hexdigest(),headAfter=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),trackedStatusAfter=subprocess.check_output(['git','-C',str(root),'status','--porcelain','--untracked-files=no'],text=True).strip())
(out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'label':label,'passed':True,'head':record['head'],'origins':record['proof']['origins'],'report':str(out/'report.json')},indent=2))
