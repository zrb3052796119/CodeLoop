from pathlib import Path
import hashlib,json,os,subprocess,time
b=Path(__file__).parent/'phase1-post-policy-quality';b.mkdir(exist_ok=True)
w=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
python='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
def snapshot():
 files={p.relative_to(w).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for top in ('minicode','scripts') for p in sorted((w/top).rglob('*.py'))}
 p=w/'tests/test_continuous_request_policy.py';files[p.relative_to(w).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True),'files':files}
before=snapshot();(b/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
for profile in ('current','a'):
 assert not (b/(profile+'.json')).exists()
 env=dict(os.environ)
 for key in list(env):
  if key.startswith('MINI_CODE_') or key in ('PYTEST_ADDOPTS','PYTEST_PLUGINS','ANTHROPIC_API_KEY','OPENAI_API_KEY'):env.pop(key)
 home=b/(profile+'-home');home.mkdir(exist_ok=True)
 env.update(PYTHONPATH=str(w),HOME=str(home),MINICODE_PYTEST_REAL_HOME=str(home),PYTHONDONTWRITEBYTECODE='1')
 command=[python,'scripts/evaluate_agent_quality.py','--profile',profile]
 started=time.time()
 with (b/(profile+'.json')).open('w') as out:
  result=subprocess.run(command,cwd=w,env=env,stdout=out,stderr=subprocess.PIPE,text=True,timeout=600)
 (b/(profile+'.stderr')).write_text(result.stderr)
 data=json.loads((b/(profile+'.json')).read_text()) if result.returncode==0 else {}
 meta={'profile':profile,'command':command,'cwd':str(w),'startedAtUnix':started,'completedAtUnix':time.time(),'seconds':time.time()-started,'exitCode':result.returncode,'sourceBeforeHead':before['head'],'sourceFilesUnchanged':snapshot()['files']==before['files'],'resultSha256':hashlib.sha256((b/(profile+'.json')).read_bytes()).hexdigest(),'passed':data.get('gate',{}).get('passed'),'checkCount':len(data.get('gate',{}).get('checks',[])),'credentialsRemoved':True,'isolatedHome':True,'mode':data.get('mode')}
 (b/(profile+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True)
after=snapshot();(b/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before['files']==after['files']
