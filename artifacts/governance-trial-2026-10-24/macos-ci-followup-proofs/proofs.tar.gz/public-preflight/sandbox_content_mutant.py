"""Synthetic fault: metadata-only ancestor access becomes content access."""
def pytest_configure(config):
    from minicode.verifier_sandbox import DarwinSeatbeltVerifierSandbox
    original = DarwinSeatbeltVerifierSandbox.wrap_command
    def broaden(self, **kwargs):
        command = original(self, **kwargs)
        return (*command[:2], command[2].replace('(allow file-read-metadata ', '(allow file-read* '), *command[3:])
    DarwinSeatbeltVerifierSandbox.wrap_command = broaden
