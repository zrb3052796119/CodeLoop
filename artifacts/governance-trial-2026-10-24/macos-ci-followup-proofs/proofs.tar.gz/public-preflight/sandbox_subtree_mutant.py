"""Synthetic fault: metadata-only ancestor access becomes content access."""
def pytest_configure(config):
    from minicode.verifier_sandbox import DarwinSeatbeltVerifierSandbox
    original = DarwinSeatbeltVerifierSandbox.wrap_command
    def broaden(self, **kwargs):
        command = original(self, **kwargs)
        before, after = command[2].split('(allow file-read* (subpath \"/System\")', 1)
        before = before.replace('(allow file-read-metadata ', '(allow file-read* ').replace('(literal ', '(subpath ')
        return (*command[:2], before + '(allow file-read* (subpath \"/System\")' + after, *command[3:])
    DarwinSeatbeltVerifierSandbox.wrap_command = broaden
