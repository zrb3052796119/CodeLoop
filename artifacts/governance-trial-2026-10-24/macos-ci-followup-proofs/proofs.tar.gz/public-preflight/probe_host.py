"""Real preflight comparison with an explicitly registered host toolchain."""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
import pytest
repo = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir()
sys.path.insert(0, str(repo))
spec = importlib.util.spec_from_file_location('public_preflight_fixture', repo / 'tests/test_public_preflight_reports.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
from minicode.verifier_sandbox import DarwinSeatbeltVerifierSandbox
from scripts import public_verification_fixtures as preflight
unprovisioned = Path('/private/tmp/codeloop-governance-20261024/ci-40111546762/pytest-report-guard-import/before-control/toolchain-without-pytest/bin/python3')
assert unprovisioned.exists() and not unprovisioned.is_symlink()
rows = []
for label, executable in [('without-pytest', unprovisioned), ('registered-host', Path(sys.executable).resolve())]:
    document = fixture._document()
    with pytest.MonkeyPatch.context() as patch:
        patch.setenv('MINI_CODE_VERIFIER_TRUSTED_EXECUTABLES', f'python3={executable}')
        receipt = preflight.run_public_preflight(document, output / label,
            runtime={'_verifierSandboxBackend': DarwinSeatbeltVerifierSandbox()}, require_pytest_report=True)
    case = receipt['cases'][0]
    evidence = case['evidence'][0]
    assert evidence['resolvedExecutable'] == str(executable)
    receipt_path = output / label / 'receipt.json'
    if label == 'without-pytest':
        assert not receipt['passed'] and case['reason'] == 'host_pytest_report_unavailable'
        assert case['pytestReport'] is None
        assert 'No module named pytest' in evidence['stderr']['preview']
        with pytest.raises(preflight.PublicFixtureError):
            preflight.validate_public_preflight(document, receipt_path,
                hashlib.sha256(receipt_path.read_bytes()).hexdigest(), require_pytest_report=True)
    else:
        assert receipt['passed'], receipt
        preflight.validate_public_preflight(document, receipt_path,
            hashlib.sha256(receipt_path.read_bytes()).hexdigest(), require_pytest_report=True)
    rows.append({'label': label, 'registeredExecutable': str(executable), 'passed': receipt['passed'],
                 'reason': case.get('reason'), 'receiptSha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest()})
proof = {'kind': 'controlled dependency comparison, not a replay of Apple shim internals',
         'realSeatbelt': True, 'results': rows,
         'productionSha256': hashlib.sha256(Path(preflight.__file__).read_bytes()).hexdigest()}
(output / 'proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
