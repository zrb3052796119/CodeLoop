from pathlib import Path

base = Path(__file__).parent
text = (base / 'original-test_model_adapter_call_controls.py').read_text()
start = text.index('class _SlowDripResponse:')
end = text.index('class _BlockingReadOnlyResponse:', start)
text = text[:start] + text[end:]
start = text.index('    response = _SlowDripResponse()', text.index('def test_non_streaming_chunk_read_rechecks_absolute_deadline('))
end = text.index('\n\n@pytest.mark.parametrize', start)
text = text[:start] + '''    # Advance only the adapter/control clocks from the real reader thread.
    # Host scheduling cannot promise a minimum number of reads in 50 ms.
    now = 100.0
    clock_lock = threading.Lock()

    def monotonic() -> float:
        with clock_lock:
            return now

    def advance_read() -> None:
        nonlocal now
        with clock_lock:
            now += 0.02

    real_monotonic = time.monotonic
    clock = SimpleNamespace(**{**vars(time), "monotonic": monotonic})
    monkeypatch.setattr(f"minicode.{provider}_adapter.time", clock)
    monkeypatch.setattr("minicode.model_call_control.time", clock)
    response = _ChunkedResponse(
        b'{"unused":"body"}', chunk_size=1, on_read=advance_read
    )
    response.socket = _RecordingSocket()
    response.fp = SimpleNamespace(raw=SimpleNamespace(_sock=response.socket))
    monkeypatch.setattr(
        f"minicode.{provider}_adapter.open_verified_url",
        lambda _request, *, timeout: response,
    )

    with pytest.raises(ModelCallDeadlineExceeded):
        _adapter_for_provider(provider).next(
            [{"role": "user", "content": "classify"}],
            deadline_monotonic=100.05,
            max_response_bytes_override=4096,
        )

    assert monotonic() == pytest.approx(100.06)
    assert response.read_sizes == []
    assert len(response.read1_sizes) == 3
    assert response.socket.timeouts == pytest.approx([0.05, 0.03, 0.01])
    # This is a cleanup watchdog, not a response-latency assertion.
    assert response.closed_event.wait(timeout=5)
    assert time.monotonic is real_monotonic
''' + text[end:]
(base / 'final-test_model_adapter_call_controls.py').write_text(text)

text = (base / 'original-test_live_multi_agent_regressions.py').read_text()
start = text.index('    """Independent checks must overlap', text.index('def test_verification_checks_run_concurrently_and_keep_request_order('))
end = text.index('\n\n# --- P3: structured workflows', start)
text = text[:start] + '''    """Real check futures overlap and finish out of request order."""
    from concurrent.futures import ThreadPoolExecutor
    import threading

    monkeypatch.syspath_prepend(str(Path(__file__).parent))
    import test_workflow_v2_structured_routing as routing

    (tmp_path / "allowed.txt").write_text("before", encoding="utf-8")
    all_entered = threading.Barrier(3)
    finished = [threading.Event() for _ in range(3)]
    completion_order: list[str] = []
    evidence_refs: dict[str, str] = {}
    lock = threading.Lock()

    class ObservedPool(ThreadPoolExecutor):
        def submit(self, fn, check):
            future = super().submit(fn, check)

            def completed(done):
                assert done.done()
                with lock:
                    completion_order.append(check.check_id)
                finished[int(check.check_id.rsplit("_", 1)[1])].set()

            future.add_done_callback(completed)
            return future

    def worker(input_data, context):
        role = routing._worker_role(input_data)
        if role == "analyst":
            routing._write_analyst_result(input_data, context, prepare_change=True)
        elif role == "executor":
            Path(context.cwd, "allowed.txt").write_text("after", encoding="utf-8")
            routing._write_executor_declaration(input_data, context)
        else:
            routing._write_reviewer_result(input_data, context)
        return routing.ToolResult(ok=True, output="ok")

    def verifier(self, **request):
        check_id = request["checks"][0].check_id
        index = int(check_id.rsplit("_", 1)[1])
        # Watchdogs detect a deadlocked/serial implementation; they do not
        # impose a wall-clock performance budget on the whole workflow.
        all_entered.wait(timeout=5)
        if index < 2:
            assert finished[index + 1].wait(timeout=5)
        result = routing._verification_result(request)
        with lock:
            evidence_refs[check_id] = result["checks"][0]["artifactRef"]
        return result

    monkeypatch.setattr(routing.task_module, "_run", worker)
    monkeypatch.setattr(routing.DeterministicVerifier, "run", verifier)
    monkeypatch.setattr(
        routing.workflow_runner_module, "ThreadPoolExecutor", ObservedPool
    )

    request = routing._request()
    request["verificationChecks"] = [
        {
            "checkId": f"check_{index}",
            "kind": "tests",
            "argv": ["pytest", "-q", f"t{index}.py"],
            "criterionIds": ["ac1"],
        }
        for index in range(3)
    ]

    result = routing._run(
        tmp_path,
        request,
        monkeypatch,
        commit_audit_waived=True,
    )

    assert result.ok is True
    assert completion_order == ["check_2", "check_1", "check_0"]
    projected = routing.extract_subagent_result(result.output)
    assert projected is not None
    assert projected["verification"] == {
        "status": "passed",
        "checks": [
            f"check_{index}: passed [{evidence_refs[f'check_{index}']}]"
            for index in range(3)
        ],
    }
''' + text[end:]
(base / 'final-test_live_multi_agent_regressions.py').write_text(text)
