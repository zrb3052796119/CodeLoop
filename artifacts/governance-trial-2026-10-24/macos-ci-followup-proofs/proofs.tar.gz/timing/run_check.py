from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

base = Path(__file__).parent
label, source, *args = sys.argv[1:]
root = Path(source).resolve()
python = '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
env = {k: v for k, v in os.environ.items() if not k.startswith('MINI_CODE_')
       and not any(x in k for x in ('API_KEY', 'ACCESS_TOKEN', 'AUTH_TOKEN'))
       and k not in ('PYTEST_ADDOPTS', 'PYTEST_PLUGINS')}
home = base / (label + '-home')
home.mkdir(exist_ok=True)
env.update(HOME=str(home), USERPROFILE=str(home), MINICODE_PYTEST_REAL_HOME=str(home),
           PYTHONPATH=str(root), PYTHONDONTWRITEBYTECODE='1')
started = time.time()
command = [python, *args]
with (base / (label + '.log')).open('w') as output:
    result = subprocess.run(command, cwd=root, env=env, stdout=output,
                            stderr=subprocess.STDOUT, timeout=180)
paths = ['minicode/openai_adapter.py', 'minicode/anthropic_adapter.py',
         'minicode/model_call_control.py', 'minicode/workflow_runner.py',
         'tests/test_model_adapter_call_controls.py', 'tests/test_live_multi_agent_regressions.py']
meta = {'label': label, 'sourceRoot': str(root), 'command': command,
        'exitCode': result.returncode, 'durationSeconds': time.time() - started,
        'harnessSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'probeSha256': hashlib.sha256(Path(args[0]).read_bytes()).hexdigest()
        if args and args[0].endswith('.py') else None,
        'sourceSha256': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}}
(base / (label + '.json')).write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
print((base / (label + '.log')).read_text()[-10000:])
raise SystemExit(result.returncode)
