"""Reconstruct exact CI production plus final fixture bytes, with optional mutation."""
from pathlib import Path
import difflib
import io
import subprocess
import sys
import tarfile

base = Path(__file__).parent
repo = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
destination = base / sys.argv[1]
destination.mkdir()
paths = ['minicode', 'tests/test_model_adapter_call_controls.py',
         'tests/test_live_multi_agent_regressions.py', 'tests/test_workflow_v2_structured_routing.py',
         'tests/global_state_isolation.py', 'conftest.py', 'pyproject.toml']
data = subprocess.check_output(['git', 'archive', 'ff2f18eadeea3fb71de431fc002aee21a3f6481a', *paths], cwd=repo)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    archive.extractall(destination, filter='data')
for name in ('test_model_adapter_call_controls.py', 'test_live_multi_agent_regressions.py'):
    (destination / 'tests' / name).write_bytes((base / ('final-' + name)).read_bytes())
if len(sys.argv) > 2 and sys.argv[2] == 'reverse-aggregation':
    path = destination / 'minicode/workflow_runner.py'
    original = path.read_text()
    source = original
    for old, new in [('for partial in partials:', 'for partial in reversed(partials):'),
                     ('for index in range(len(requested_checks)):',
                      'for index in reversed(range(len(requested_checks))):')]:
        assert source.count(old) == 1
        source = source.replace(old, new)
    path.write_text(source)
    (base / 'fault-reverse-aggregation.patch').write_text(''.join(difflib.unified_diff(
        original.splitlines(keepends=True), source.splitlines(keepends=True),
        fromfile='a/minicode/workflow_runner.py', tofile='b/minicode/workflow_runner.py')))
