from pathlib import Path
import json
import subprocess

base = Path(__file__).parent
current = '/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main'
old = str(base / 'original-ci-source')
specs = [
    ('final-old-first-read', old, 1, 'first-read-deadline', 'openai'),
    ('final-old-overhead', old, 1, 'workflow-overhead'),
    ('final-new-first-read', current, 0, 'first-read-deadline', 'openai'),
    ('final-new-overhead', current, 0, 'workflow-overhead'),
    ('final-fault-deadline-openai', current, 1, 'disabled-deadline-check', 'openai'),
    ('final-fault-deadline-anthropic', current, 1, 'disabled-deadline-check', 'anthropic'),
    ('final-fault-timeout-openai', current, 1, 'fixed-socket-timeout', 'openai'),
    ('final-fault-timeout-anthropic', current, 1, 'fixed-socket-timeout', 'anthropic'),
    ('final-fault-serial', current, 1, 'serial-workers'),
    ('final-fault-order', str(base / 'fault-order-source'), 1, 'reverse-aggregation'),
]
results = []
for label, root, expected, *args in specs:
    command = ['python3', str(base / 'run_check.py'), label, root,
               str(base / 'probe_fixture_contracts.py'), root, *args]
    result = subprocess.run(command, stdout=subprocess.DEVNULL)
    record = {'label': label, 'exitCode': result.returncode, 'expectedExitCode': expected}
    results.append(record)
    print(json.dumps(record), flush=True)
    assert result.returncode == expected, record
(base / 'final-proof-exit-summary.json').write_text(json.dumps(results, indent=2) + '\n')
