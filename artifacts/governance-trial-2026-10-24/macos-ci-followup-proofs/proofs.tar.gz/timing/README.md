# macOS CI timing fixtures: deadline reads and parallel verification

This is a test-fixture correction, not a production fix. The original CI run is `40111546762`, macOS Python 3.12 job `120924144874`, source `ff2f18eadeea3fb71de431fc002aee21a3f6481a`. No full suite or CI was interrupted or rerun for this work.

The raw CI report shows two failures: the adapter correctly raised `ModelCallDeadlineExceeded` but made only one `read1` call before its 50 ms deadline, and the successful workflow took 1.240287 seconds against a 1.15-second assertion. Its overlap assertions had not yet run. The CI output does not recover the exact host scheduling interleaving. `original-ci-issues.json` preserves the two real failures; controlled probes below demonstrate permitted schedules independently.

## Contract and changes

1. The deadline contract requires stopping at the absolute deadline, not at least two reads within 50 ms. The final fixture uses module-local clocks for the selected adapter and deadline control, while preserving real reader threads and queues. Each read advances 20 ms; exactly three reads consume 60 ms, raise the typed absolute-deadline exception, request socket timeouts of 50/30/10 ms, and close the response. Other tests in the same file retain real-clock blocked-read/cancellation coverage. No global standard-library clock is patched.
2. The parallel verification contract requires overlapping execution and request-ordered evidence, not a whole-workflow latency below a serial-verifier floor. Three real verifier threads meet a barrier. Real outer Future done callbacks release the next verifier in reverse request order. The test then requires actual completion order `check_2, check_1, check_0` and exact final check/evidence strings in request order. Five-second waits are deadlock/cleanup watchdogs; no sleep or enlarged wall-latency threshold was added.

Only `tests/test_model_adapter_call_controls.py` and `tests/test_live_multi_agent_regressions.py` were changed. Four relevant production modules are byte-identical between the old CI source and current candidate; see `initial-source-comparison.json`. `fixture.patch` and the two `final-test_*.py` files contain the final reviewed change.

## Controlled counterexamples

- `final-old-first-read.log`: the unchanged original test and production, with a local clock advancing 60 ms during the first real reader-thread read, fail precisely at the old `read1_calls >= 2` assertion. The required deadline exception already occurred. This models a permitted first-read scheduling delay; it does not claim to recover the CI machine's interleaving.
- `final-old-overhead.log`: the unchanged original test executes the real workflow and three actual overlapping verifier intervals. A fixture-local clock models 900 ms of non-verification elapsed time after the real workflow finishes; the old wall assertion fails despite all three intervals overlapping. No production clock or deadline changes, extra sleeps, or fabricated workflow result are involved. This explicitly models caller/other-workflow elapsed time, not the actual CI delay.
- `final-new-first-read.log` and `final-new-overhead.log`: final fixtures pass in the same probe harness; the new tests establish their relevant timing/ordering premises directly.
- `original-normal.log`: all three old parameterized cases pass under ordinary local scheduling. A rerun pass is not presented as repairing or invalidating the original CI failure.

`probe_fixture_contracts.py` compiles exact fixture bytes with a private builtins/import mapping only to bind that fixture's time module in the controlled old-fixture probes. Production modules are imported from the recorded source root and their origins/SHA are asserted. Synthetic production faults are confined to separate processes or a reconstructed temporary source tree.

## Final validation and fault sensitivity

- Final identical test bytes on the current P1 source: **77 passed in 3.25 seconds** across both complete files (`final-identical-files.log`).
- The same final test bytes on exact original CI production: **3 passed in 1.64 seconds** (`final-identical-on-ci.log`). These are the changed parameterized cases, not a full old-source suite.
- All six intentional production faults are rejected: disable absolute I/O deadline checks for either provider (wrong `TimeoutError`), reset socket timeout on every read for either provider (50/30/10 ms assertion), force a serial worker limit (barrier cannot complete), reverse both aggregate checks and evidence (exact request-order projection assertion). See `final-fault-*.log`, the patch for the aggregation fault, and `final-proof-exit-summary.json`. These faults demonstrate test sensitivity and are not historical production bugs.
- `git diff --check` passes. Strict E/F lint introduced zero findings; three unrelated pre-existing findings remain in the live regression file (one unused `original_run`, two long lines), versus four before. This is reported transparently in `lint-comparison.json`; it is not a claim of a strict full-file lint pass. CI's production-only Ruff target was not changed.

This local evidence does not certify a new full suite or repaired macOS CI result. All test hashes, exact commands, source roots, runner/probe hashes, and exit codes are recorded in the corresponding JSON metadata. The byte mirrors used by final fault proofs and the old-source replay match the current final two files.

## Reproduction and archive boundary

Use the recorded Python environment with isolated HOME and source PYTHONPATH via `run_check.py`. `prepare_tests.py` regenerates the exact final tests from the included original fixture bytes. `prepare_original_source.py` reconstructs the selected original Git tree and can apply the explicit two-line reverse-aggregation fault. `run_final_proofs.py` lists the controlled proof/fault commands and expected exits. Temporary source trees, isolated HOME directories, caches, and unrelated evidence are deliberately excluded from the archive allowlist.
