"""Controlled clock/ordering probes; no provider calls or global stdlib patches."""
import builtins
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback
from types import ModuleType, SimpleNamespace

import pytest

root = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
provider = sys.argv[3] if len(sys.argv) > 3 else 'openai'
sys.path[:0] = [str(root), str(root / 'tests')]
is_deadline = 'deadline' in mode or mode == 'fixed-socket-timeout'
relative = ('tests/test_model_adapter_call_controls.py' if is_deadline
            else 'tests/test_live_multi_agent_regressions.py')
path = root / relative
observations = []
now = 100.0
offset = 0.0
lock = threading.Lock()
real_import = builtins.__import__


def clock_now():
    with lock:
        value = now if is_deadline else time.monotonic() + offset
        observations.append({'event': 'clock', 'thread': threading.current_thread().name,
                             'value': value})
        return value


def elapsed_read(_requested):
    global now
    with lock:
        now += 0.06
        observations.append({'event': 'first-read-consumed-deadline', 'value': now,
                             'thread': threading.current_thread().name})


clock = SimpleNamespace(**{**vars(time), 'monotonic': clock_now,
                          'sleep': elapsed_read if is_deadline else time.sleep})


def fixture_import(name, globals=None, locals=None, fromlist=(), level=0):
    if name == 'time' and mode in ('first-read-deadline', 'workflow-overhead'):
        return clock
    return real_import(name, globals, locals, fromlist, level)


fixture = ModuleType('timing_fixture_under_test')
fixture.__file__ = str(path)
fixture.__dict__['__builtins__'] = {**vars(builtins), '__import__': fixture_import}
sys.modules[fixture.__name__] = fixture
exec(compile(path.read_bytes(), str(path), 'exec'), fixture.__dict__)
modules = {}
for name in ('minicode.openai_adapter', 'minicode.anthropic_adapter',
             'minicode.model_call_control', 'minicode.workflow_runner'):
    module = importlib.import_module(name)
    source = Path(module.__file__).resolve()
    assert source.is_relative_to(root), (source, root)
    modules[name] = {'path': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()}

failure = None
try:
    with pytest.MonkeyPatch.context() as patch, tempfile.TemporaryDirectory() as workspace:
        if is_deadline:
            adapter = importlib.import_module(f'minicode.{provider}_adapter')
            control = importlib.import_module('minicode.model_call_control')
            if mode == 'first-read-deadline':
                patch.setattr(adapter, 'time', clock)
                patch.setattr(control, 'time', clock)
            elif mode == 'disabled-deadline-check':
                original = adapter._check_io_controls

                def ignore_absolute_deadline(**kwargs):
                    return original(**{**kwargs, 'deadline_monotonic': None})

                patch.setattr(adapter, '_check_io_controls', ignore_absolute_deadline)
            elif mode == 'fixed-socket-timeout':
                original = adapter._set_response_socket_timeout

                def reset_timeout(response, _remaining):
                    return original(response, 0.05)

                patch.setattr(adapter, '_set_response_socket_timeout', reset_timeout)
            fixture.test_non_streaming_chunk_read_rechecks_absolute_deadline(patch, provider)
        else:
            routing = importlib.import_module('test_workflow_v2_structured_routing')
            if mode == 'workflow-overhead':
                original = routing._run

                def add_nonverification_elapsed(*args, **kwargs):
                    global offset
                    result = original(*args, **kwargs)
                    observations.append({'event': 'real-workflow-finished', 'ok': result.ok})
                    # Model 900 ms outside the verification interval, without
                    # sleeping or changing any production clock/deadline.
                    offset += 0.9
                    return result

                patch.setattr(routing, '_run', add_nonverification_elapsed)
            elif mode == 'serial-workers':
                patch.setattr(routing.workflow_runner_module, '_PARALLEL_VERIFICATION_WORKERS', 1)
            fixture.test_verification_checks_run_concurrently_and_keep_request_order(Path(workspace), patch)
except BaseException as error:
    failure = {'type': type(error).__name__, 'message': str(error)}
    traceback.print_exc()

if mode == 'workflow-overhead' and observations:
    worker_times = {}
    for item in observations:
        if item.get('thread', '').startswith('ThreadPoolExecutor'):
            worker_times.setdefault(item['thread'], []).append(item['value'])
    intervals = [values for values in worker_times.values() if len(values) == 2]
    observations.append({'event': 'independent-overlap-check', 'intervals': intervals,
                         'allThreeOverlap': (max(v[0] for v in intervals) < min(v[1] for v in intervals))
                         if len(intervals) == 3 else None})
print(json.dumps({'mode': mode, 'provider': provider, 'fixture': str(path),
                  'fixtureSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'productionSources': modules, 'failure': failure,
                  'observations': observations}, indent=2))
raise SystemExit(1 if failure else 0)
