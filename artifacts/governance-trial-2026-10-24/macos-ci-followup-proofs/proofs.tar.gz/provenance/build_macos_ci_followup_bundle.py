"""Archive only the frozen, explicitly reviewed macOS proof allowlist."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import tarfile
import tempfile

BASE = Path('/private/tmp/codeloop-governance-20261024')
WORK = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
SHA = lambda data: hashlib.sha256(data).hexdigest()


def safe_name(name):
    p = PurePosixPath(name)
    assert p.parts and not p.is_absolute() and '..' not in p.parts and '.' not in p.parts
    return p


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    frozen = json.loads((BASE/'macos-ci-bundle-inputs.json').read_text())
    payload = {}
    for item in frozen['files']:
        safe_name(item['path'])
        source = BASE.joinpath(*safe_name(item['source']).parts)
        assert source.is_file() and not source.is_symlink(), source
        data = source.read_bytes()
        assert len(data) == item['bytes'] and SHA(data) == item['sha256'], source
        assert item['path'] not in payload
        payload[item['path']] = data
    for name, expected in frozen['finalSourceSha256'].items():
        assert SHA((WORK/name).read_bytes()) == expected, name
    payload['provenance/frozen-inputs.json'] = (BASE/'macos-ci-bundle-inputs.json').read_bytes()
    payload['provenance/build_macos_ci_followup_bundle.py'] = Path(__file__).read_bytes()
    payload = dict(sorted(payload.items()))

    def pack():
        raw = io.BytesIO()
        with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, data in payload.items():
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                entry.uid = entry.gid = entry.mtime = 0
                entry.uname = entry.gname = ''
                tar.addfile(entry, io.BytesIO(data))
        out = io.BytesIO()
        with gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
            gz.write(raw.getvalue())
        return out.getvalue()

    archive = pack()
    assert archive == pack()
    destination = args.output
    assert not destination.exists(), f'Will not overwrite {destination}'
    destination.mkdir(parents=True)
    (destination/'proofs.tar.gz').write_bytes(archive)
    restored = Path(tempfile.mkdtemp(prefix='codeloop-macos-proofs-restore-', dir='/private/tmp'))
    seen = set()
    with tarfile.open(destination/'proofs.tar.gz', 'r:gz') as tar:
        for member in tar.getmembers():
            name = safe_name(member.name)
            assert member.isfile() and member.name not in seen and member.name in payload
            data = tar.extractfile(member).read()
            assert data == payload[member.name]
            target = restored.joinpath(*name.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            assert target.read_bytes() == payload[member.name]
            seen.add(member.name)
    assert seen == set(payload)
    manifest = {
        'schemaVersion': 1,
        'classification': 'Original macOS CI negative evidence, fixture corrections, trusted-prefix metadata repair and evaluation transport receive-time repair; scoped verification only, no final full-suite or native-CI acceptance.',
        'ciRunId': 40111546762,
        'ciBaseline': 'ff2f18eadeea3fb71de431fc002aee21a3f6481a',
        'sourceCommits': frozen['sourceCommits'],
        'finalSourceSha256': frozen['finalSourceSha256'],
        'archive': 'proofs.tar.gz', 'archiveSha256': SHA(archive), 'archiveBytes': len(archive),
        'rawBytes': sum(map(len, payload.values())), 'entryCount': len(payload),
        'deterministicArchive': 'sorted USTAR regular files; mode0644 uid/gid/mtime0 empty owner names; gzip mtime0 empty filename; repeat pack identical',
        'restorationVerification': {'allMembersRestored': True, 'memberBytesEqualOriginals': True, 'memberCount': len(payload)},
        'entries': [{'path': name, 'bytes': len(data), 'sha256': SHA(data)} for name, data in payload.items()],
    }
    (destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    readme = (BASE/'macos-ci-bundle-README.md').read_text()
    for token, value in [('@@COUNT@@', len(payload)), ('@@RAW@@', manifest['rawBytes']), ('@@GZIP@@', len(archive))]:
        readme = readme.replace(token, f'{value:,}')
    assert '@@' not in readme
    (destination/'README.md').write_text(readme)
    # Recheck the frozen origins after building, not just prior to assembly.
    for item in frozen['files']:
        assert SHA((BASE/item['source']).read_bytes()) == item['sha256'], item['source']
    print(json.dumps({'path': str(destination), 'archiveSha256': SHA(archive), 'archiveBytes': len(archive), 'rawBytes': manifest['rawBytes'], 'entryCount': len(payload), 'restored': str(restored)}, indent=2))


if __name__ == '__main__':
    main()
