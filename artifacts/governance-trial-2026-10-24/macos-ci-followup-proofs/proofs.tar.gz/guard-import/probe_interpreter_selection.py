"""Real Seatbelt/pytest comparison; no model/API use and no sandbox relaxation."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import traceback

import pytest

ROOT = Path(sys.argv[1]).resolve()
OUTPUT = Path(sys.argv[2]).resolve()
OUTPUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('report_guard_fixture', ROOT / 'tests/test_pytest_report_guard_import.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
import minicode.deterministic_verifier as verifier_module
import minicode.verifier_sandbox as sandbox_module

toolchain = OUTPUT / 'toolchain-without-pytest'
subprocess.run([sys.executable, '-m', 'venv', '--without-pip', '--copies', str(toolchain)], check=True)
unprovisioned = toolchain / 'bin/python3'
assert unprovisioned.is_file() and not unprovisioned.is_symlink()
probe = subprocess.run([str(unprovisioned), '-c', 'import pytest'], capture_output=True, text=True)
assert probe.returncode != 0 and 'No module named' in probe.stderr and 'pytest' in probe.stderr

results = []
for label, executable in [('unprovisioned', str(unprovisioned)), ('selected-host', sys.executable)]:
    workspace = OUTPUT / label
    workspace.mkdir()
    outcome = {'label': label, 'registeredExecutable': executable}
    try:
        with pytest.MonkeyPatch.context() as patch:
            fixture._exercise_report(workspace, patch, "raise TypeError('synthetic constructor error')",
                                     'failed', 'exception', executable=executable,
                                     argv=('python3', '-m', 'pytest', '-q', 'test_public.py'))
    except AssertionError as error:
        outcome.update({'assertionFailed': True, 'message': str(error)})
        (OUTPUT / (label + '.trace.txt')).write_text(traceback.format_exc())
        assert label == 'unprovisioned' and 'No module named pytest' in str(error)
    else:
        outcome['assertionFailed'] = False
        assert label == 'selected-host'
    runtime = workspace / 'workspace/interpreter.json'
    if runtime.exists():
        outcome['actualRuntime'] = json.loads(runtime.read_text())
    results.append(outcome)

proof = {'scope': 'controlled missing-dependency toolchain comparison, not a replay of Apple shim internals',
         'realSeatbelt': True, 'sources': {}, 'results': results,
         'selectedHost': sys.executable, 'selectedHostVersion': list(sys.version_info[:3])}
for module in (fixture, verifier_module, sandbox_module):
    path = Path(module.__file__).resolve()
    proof['sources'][module.__name__] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(OUTPUT / 'proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
