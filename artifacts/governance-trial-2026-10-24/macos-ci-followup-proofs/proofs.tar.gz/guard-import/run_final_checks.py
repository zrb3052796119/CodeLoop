from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
OUT = Path(__file__).resolve().parent
env = {key: value for key, value in os.environ.items()
       if not key.startswith('MINI_CODE_') and not key.endswith('_API_KEY')
       and key not in {'ANTHROPIC_AUTH_TOKEN', 'PYTEST_ADDOPTS', 'PYTEST_PLUGINS'}}
home = OUT / 'final-home'
home.mkdir(exist_ok=True)
env.update({'HOME': str(home), 'PYTHONPATH': str(ROOT), 'PYTHONDONTWRITEBYTECODE': '1'})
commands = [
    ('final-target-file', [sys.executable, '-m', 'pytest', 'tests/test_pytest_report_guard_import.py',
                           '-q', '--randomly-seed=42', '-p', 'no:cacheprovider']),
    ('final-controlled-comparison', [sys.executable, str(OUT / 'probe_interpreter_selection.py'),
                                     str(ROOT), str(OUT / 'final-control')]),
]
records = []
for label, command in commands:
    started = time.time()
    with (OUT / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                timeout=120, check=False)
    records.append({'label': label, 'command': command, 'exitCode': result.returncode,
                    'durationSeconds': time.time() - started})
proof = {'runs': records, 'sourceHashes': {}}
for rel in ('tests/test_pytest_report_guard_import.py', 'minicode/deterministic_verifier.py',
            'minicode/verifier_sandbox.py'):
    raw = (ROOT / rel).read_bytes()
    proof['sourceHashes'][rel] = hashlib.sha256(raw).hexdigest()
    if rel.startswith('minicode/'):
        assert raw == subprocess.check_output(['git', 'show', 'ff2f18ea:' + rel], cwd=ROOT)
proof['productionBytesEqualOriginalCi'] = True
(OUT / 'final-checks.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
sys.exit(max(record['exitCode'] for record in records))
