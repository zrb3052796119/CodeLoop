# Evaluation transport: queued-byte idle accounting

The consumer could raise `EvaluationIdleTimeout` before inspecting bytes already queued during a slow durable ledger update. The fix first checks the queue, then validates the reader's `observed_at` gap. Absolute deadline/cancellation remain prior to processing; a completed delimited DONE need not wait for EOF. Late bytes, EOF, or reader errors cannot erase a real observed idle gap.

The old macOS CI failure is retained in `ci-failure.json`. Its exact thread schedule was not recorded. The original test, unchanged, fails under a causally sufficient real-clock ledger-lag schedule and passes with only the script repaired. The final deterministic tests are identical across old/new scripts: **3 failed / 7 passed → 10 passed**. Three deliberate synthetic faults fail at the expected assertions; they are not claims of additional historical defects.

The 31-case transport file and four directly related harness files pass together: **87 passed**, seed 20261024. These counts overlap. A first sandbox run was 80 passed / 7 failed because process scanning was denied; the same bytes pass with host process-table access. The denied cleanup receipt remains included. Static diff/F checks pass; broader E/F finds one unchanged historical E702 line.

Only reader-return timestamps are known; socket-buffer arrival and a full queue's backpressure are not covered. No provider/API calls or new full/native matrix were run. Phase2 directly imports and fingerprints this script; its prior manifest remains at 0 trials and must be explicitly withdrawn/versioned and refrozen before execution. No Phase2 file was modified here.
