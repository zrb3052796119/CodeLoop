"""Exact old fixture and real stream/queue/ledger; hold one ledger return until EOF."""
import json
import os
from pathlib import Path
import sys
import threading
import time
from types import SimpleNamespace

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
mode = sys.argv[3]
sys.path[:0] = [str(root), '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/lib/python3.12/site-packages']
os.chdir(root)
import pytest

trace=[]
started=time.monotonic()
eof=threading.Event()
def record(event, **values):
    trace.append({'event':event,'at':time.monotonic()-started,'thread':threading.current_thread().name,**values})

class Probe:
    @pytest.fixture(autouse=True)
    def instrument(self, monkeypatch):
        import test_evaluation_transport as case
        from scripts import evaluation_transport as transport
        original_read = case.ScriptedResponse.read1
        original_update = transport.SharedLedger.update
        original_queue = transport.queue
        class ObservedQueue(original_queue.Queue):
            def put(self,item,*args,**kwargs):
                result=super().put(item,*args,**kwargs)
                record('queued',bytes=len(item[0]) if item[0] is not None else None,observed_at=item[1]-started,qsize=self.qsize())
                return result
            def get(self,*args,**kwargs):
                item=super().get(*args,**kwargs)
                record('consumed',bytes=len(item[0]) if item[0] is not None else None,observed_at=item[1]-started,qsize=self.qsize())
                return item
        def read(response,amount):
            chunk=original_read(response,amount)
            record('read_return',bytes=len(chunk))
            if not chunk:eof.set()
            return chunk
        held=False
        def update(ledger,call,values):
            nonlocal held
            result=original_update(ledger,call,values)
            if mode=='lag' and 'firstContentSeconds' in values and not held:
                held=True
                record('ledger_consumer_hold')
                assert eof.wait(3), 'scripted stream did not finish'
                record('ledger_consumer_release')
            return result
        monkeypatch.setattr(case.ScriptedResponse,'read1',read)
        monkeypatch.setattr(transport.SharedLedger,'update',update)
        monkeypatch.setattr(transport,'queue',SimpleNamespace(Queue=ObservedQueue,Empty=original_queue.Empty,Full=original_queue.Full))
        yield

print(json.dumps({'python':sys.version,'root':str(root),'mode':mode}),flush=True)
result=pytest.main(['-q','-p','no:cacheprovider','tests/test_evaluation_transport.py::test_active_stream_exceeds_old_fixed_timer_but_respects_idle'],plugins=[Probe()])
origins={n:m.__file__ for n,m in sys.modules.items() if n.startswith(('minicode','scripts.')) and getattr(m,'__file__',None)}
assert origins and all(Path(p).resolve().is_relative_to(root) for p in origins.values())
out.write_text(json.dumps({'mode':mode,'exit':result,'events':trace,'all_imports_in_source_root':True},indent=2)+'\n')
print(json.dumps({'exit':result,'trace':str(out),'events':trace}),flush=True)
raise SystemExit(result)
