import os,subprocess,json
from pathlib import Path
p=Path(__file__).resolve().parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
cmd=['/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python','-I','-S',str(p/'run_scoped.py'),str(root),'-p','pytest_randomly','--randomly-seed=20261024','tests/test_evaluation_transport.py','tests/test_three_arm_live_harness.py','tests/test_three_arm_protocol.py','tests/test_three_arm_processes.py','tests/test_three_arm_process_phases.py']
env={k:v for k,v in os.environ.items() if k in ['PATH','SHELL','LANG','LC_ALL','TMPDIR']}
env.update(HOME=str(p/'home'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1')
with (p/'related-after.log').open('w') as log:
 result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(p/'related-after-runmeta.json').write_text(json.dumps({'command':cmd,'exit':result.returncode,'environment_keys':sorted(env)},indent=2)+'\n')
print((p/'related-after.log').read_text()[-18000:])
raise SystemExit(result.returncode)
