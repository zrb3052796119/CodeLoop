import hashlib,json,os,shutil,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
live=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
base=p/'baseline-ff2f'
proof=p/'proof-source'
shutil.copytree(base,proof,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'),dirs_exist_ok=True)
script=(live/'scripts/evaluation_transport.py').read_text()
test=(live/'tests/test_evaluation_transport.py').read_bytes()
old_script=(base/'scripts/evaluation_transport.py').read_text()
old_test=(base/'tests/test_evaluation_transport.py').read_bytes()
(proof/'tests/test_evaluation_transport.py').write_bytes(test)
env={k:v for k,v in os.environ.items() if k in ['PATH','SHELL','LANG','LC_ALL','TMPDIR']}
env.update(HOME=str(p/'home'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1')
py='/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
records=[]
selection='active_stream_exceeds or queued_terminal or absolute_deadline_precedes or unterminated_done'
def run(label,source,args,expected=0):
    (proof/'scripts/evaluation_transport.py').write_text(source)
    cmd=[py,'-I','-S',str(p/'run_scoped.py'),str(proof),*args]
    with (p/f'{label}.log').open('w') as log:
        result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    row={'label':label,'command':cmd,'exit':result.returncode,'expectedExit':expected,'scriptSHA':hashlib.sha256(source.encode()).hexdigest(),'testSHA':hashlib.sha256((proof/'tests/test_evaluation_transport.py').read_bytes()).hexdigest()}
    records.append(row)
    (p/'final-proof-runmeta.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    print((p/f'{label}.log').read_text()[-300:],flush=True)
    assert result.returncode==expected
run('final-same-tests-before',old_script,['tests/test_evaluation_transport.py','-k',selection],1)
run('final-same-tests-after',script,['tests/test_evaluation_transport.py','-k',selection])
gap='''                if observed_at - last_byte >= self.config.idle_timeout_seconds:
                    raise EvaluationIdleTimeout("evaluation stream idle timeout")
'''
assert gap in script
run('synthetic-no-receive-gap',script.replace(gap,''),['tests/test_evaluation_transport.py','-k','queued_terminal or unterminated_done'],1)
run('synthetic-consumer-timestamp',script.replace('last_byte = observed_at','last_byte = time.monotonic()'),['tests/test_evaluation_transport.py','-k','queued_terminal or unterminated_done'],1)
start=script.index('    def _consume(')
end=script.index('\n\ndef _worker_bootstrap',start)
consume=script[start:end]
consume='\n'.join(line for line in consume.split('\n') if 'checkpoint_model_call(' not in line)
run('synthetic-no-stream-deadline-checks',script[:start]+consume+script[end:],['tests/test_evaluation_transport.py','-k','absolute_deadline_precedes'],1)
(proof/'scripts/evaluation_transport.py').write_text(script)
(proof/'tests/test_evaluation_transport.py').write_bytes(old_test)
cmd=[py,'-I','-S',str(p/'probe_consumer_lag.py'),str(proof),str(p/'lag-after-fix-trace.json'),'lag']
with (p/'lag-after-fix.log').open('w') as log:
    result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
records.append({'label':'original-test-real-clock-lag-after-fix','command':cmd,'exit':result.returncode,'scriptSHA':hashlib.sha256(script.encode()).hexdigest(),'testSHA':hashlib.sha256(old_test).hexdigest()})
(p/'final-proof-runmeta.json').write_text(json.dumps(records,indent=2)+'\n')
print(records[-1],flush=True)
assert result.returncode==0
(proof/'tests/test_evaluation_transport.py').write_bytes(test)
(proof/'scripts/evaluation_transport.py').write_text(script)
