# Independent review: queued stream activity and consumer lag

GO for the scoped production/test change; no blocking finding. Reviewed the complete `_consume` boundary, P1 diff, test helper and ten parameterized cases, final same-byte proof metadata/logs, real-clock lag trace, import-isolated runner, and related regression result. This review ran no additional tests and changed no repository files.

The production defect is distinct from a wall-clock fixture failure: before the fix, the consumer checked its elapsed timer before consulting bytes already received by the real reader. Durable ledger work could therefore be labelled network inactivity even while queued receive timestamps remained within the idle allowance. The controlled original-fixture trace demonstrates this causal schedule; it does not claim to recover the CI host's exact unobserved schedule.

The fix preserves the relevant boundaries:

- An expired consumer timer permits only a nonblocking queue inspection. An empty queue still checks cancellation/absolute deadline, then enforces idle timeout. Timely queued bytes cannot make a real receive gap disappear: `observed_at - last_byte` is checked before handling data, EOF, or reader error.
- Cancellation and the absolute deadline are checked before queue access and immediately after it. Buffered data or DONE cannot override an already expired caller deadline; the final checkpoint remains.
- Initial `last_byte` is recorded before starting the worker, preventing the worker's first receive timestamp from preceding the baseline. Subsequent activity uses reader time, not durable-ledger completion time.
- A fully delimited DONE ends the stream, so later EOF is immaterial. An unterminated DONE still needs EOF, and late EOF remains an idle error. Ordinary timely EOF without DONE and reader errors retain their error paths. Existing response byte limits and cleanup are untouched.

The regression helper retains real queues, a real reader thread, and real SQLite ledger updates. Module-local clock/queue proxies do not mutate shared standard-library objects. The first durable update deliberately holds only consumer progress until the reader has queued the bounded scripted stream; watchdogs detect missing synchronization rather than weakening idle/deadline assertions. Positive cases assert exact receive telemetry and charged usage; negative cases preserve typed errors, partial usage, and missing-DONE evidence.

Final reviewed SHA-256:

- `scripts/evaluation_transport.py`: `b3034785c2268067b0503731aadafb4f29b5c36df5141b98e1a4fa1c69232534`
- `tests/test_evaluation_transport.py`: `7823259962f94f165a5c1ab10bf6b60b8a9b16cebab1b671fd730fb6f1d23bac`

Identical final tests produce 3 failures / 7 passes with the original script and 10 passes with the repaired script; final synthetic receive-gap/timestamp/deadline faults all fail. The real-clock original-fixture lag probe also changes from failure to pass. The final related file/direct-harness run reports 87 passes. Earlier sandbox process-inspection failures are retained separately and are not concealed as passing test attempts. None of these local results is a new full-suite or CI acceptance claim.
