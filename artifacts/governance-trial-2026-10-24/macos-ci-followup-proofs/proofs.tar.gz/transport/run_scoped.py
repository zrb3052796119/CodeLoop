import hashlib,json,os
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(root),'/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/lib/python3.12/site-packages']
os.chdir(root)
import pytest
from scripts import evaluation_transport
assert Path(evaluation_transport.__file__).resolve()==root/'scripts/evaluation_transport.py'
print(json.dumps({'python':sys.version,'root':str(root),'transportSHA':hashlib.sha256((root/'scripts/evaluation_transport.py').read_bytes()).hexdigest(),'testSHA':hashlib.sha256((root/'tests/test_evaluation_transport.py').read_bytes()).hexdigest(),'args':sys.argv[2:]}),flush=True)
result=pytest.main(['-q','-p','no:cacheprovider',*sys.argv[2:]])
origins={n:m.__file__ for n,m in sys.modules.items() if n.startswith(('minicode','scripts.')) and getattr(m,'__file__',None)}
assert origins and all(Path(p).resolve().is_relative_to(root) for p in origins.values()), origins
print(json.dumps({'exit':result,'all_source_imports_in_root':True}),flush=True)
raise SystemExit(result)
