# CI attempt来源映射：独立只读复核

结论：**现有本地事实支持以“attempt1五项成功原执行 + attempt2重跑macOS3.11”组织最后矩阵。当前只是来源映射可成立，尚不是完整CI通过结论。** 未查询API、执行测试、重跑CI或修改任何原件/观察器。审阅者曾参与个别fixture修复，但未实施本观察器或本次rerun；这里独立核对来源。

run `40130139264`，run number/原seed **50**，head `e6492f9be7357a707bb8f05c722aa2af4eefcc3d`。attempt1全部已完成，四POSIX pytest进程都成功；macOS3.11 job因随后upload-artifact ENOTFOUND而失败，缺XML。原raw明确14963passed/8skipped/3307.63s；这不等同job成功。原54份冻结文件已逐SHA/字节大小复算一致；原三份可用POSIX XML也独立重算SHA及结果数，与summary一致。两个Windows成功仅为实验性包检查。

本地`retry-request.json`记录恰好一次 `gh run rerun 40130139264 --failed`，exit0，并绑定冻结manifest SHA。该命令重跑完整失败job（含pytest），**不是只重试上传步骤**。原attempt1失败与缺件须永久保留。

## API身份与执行身份

| 项目 | attempt1原job | attempts/2 API job ID | 原始材料归属 |
| --- | ---: | ---: | --- |
| macOS3.11 | 120979908153 | 120994485852 | attempt2 新执行，待原迹 |
| Ubuntu3.12 | 120979908000 | 120994486483 | attempt1 成功原执行 |
| Ubuntu3.11 | 120979908190 | 120994486492 | attempt1 成功原执行 |
| macOS3.12 | 120979908130 | 120994486824 | attempt1 成功原执行 |
| Windows3.12包检查 | 120979908151 | 120994486987 | attempt1 成功原执行 |
| Windows3.11包检查 | 120979908081 | 120994515468 | attempt1 成功原执行 |

五个继承项的head、run、runner ID/name、started/completed、labels、conclusion以及整个steps列表都与attempt1原项一致；仅新API wrapper ID、created_at、run_attempt等变化。其完成时间甚至早于新的API created_at。macOS3.11则换了runner（1000000309→1000000313）并于21:36:47Z新开始。这个差异足以把五项映射为继承成功，不应算六次新执行。

初版“expected1”对完整API inventory的假设被6项响应否定，局部observer停止及原脚本/响应已保留。修订版先保留完整6项，逐项对照5个继承项，再精确选择job120994485852，语义正确；它没有把五个新执行静默过滤。最终manifest应同时存 **sourceExecutionAttempt/sourceExecutionJobId** 与 **attempt2ApiJobId**，不能把旧log/XML冒写成新job执行产物。

## 不能混同的边界

- **head与merge：** attempt1六项raw都绑定实际checkout `b0091e50b8f434cf811f3cdec5159d44052d3e09`，与PR head分列。attempt2实际merge尚未在本次复核中取得，要读该新job原log，不能仅凭相同head推定。
- **run number、attempt与seed：** 原seed50来自原raw；attempt2的2不是seed，局部测试20261024也无关。新raw须确认实际seed50，不能只用monitor配置代替执行证据。
- **XML：** Ubuntu3.11/3.12及macOS3.12使用attempt1原artifact ID、created_at、ZIP digest、XML SHA/counts；本次已核对。macOS3.11新XML只能归attempt2。原名`pytest-macos-latest-py3.11-seed-50`不含attempt，因此最终还须核artifact ID、创建/上传时刻、run/head及原archive/XML SHA，不能只按名字取件。
- **结果：** 原macOS3.11 pytest绿、上传红、job红、XML缺失四个事实同时保留。重跑不能倒填原XML或把原attempt改绿；不得将两次macOS结果累加成额外独立平台样本。
- **范围：** 最终是同run/同候选跨attempt合成的支持平台矩阵；不是一次attempt内六项全绿，也不是Windows完整runtime通过。原三份XML分别Ubuntu14952passed/19skipped、macOS14963passed/8skipped；平台间数量不同不需归一或相加。

待新macOS3.11最终job结论、完整raw、实际checkout/seed和正确归属XML到齐后，才由root作最终验收判断。当前无来源映射阻塞，但不得提前写CI通过。详细逐项身份、输入SHA与限定见同名JSON。
