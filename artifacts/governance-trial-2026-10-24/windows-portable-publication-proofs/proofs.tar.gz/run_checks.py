import json
import os
from pathlib import Path
import subprocess
import sys
import time

out = Path('/private/tmp/codeloop-governance-20261024/windows-portable-publication')
root = Path(os.environ.get('WINDOWS_PUBLISHER_PROOF_ROOT', '/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main'))
label = sys.argv[1]
args = sys.argv[2:]
env = {k: v for k, v in os.environ.items() if not k.startswith('MINI_CODE_') and not any(x in k for x in ('API_KEY', 'ACCESS_TOKEN', 'AUTH_TOKEN'))}
home = out / (label + '-home')
home.mkdir(exist_ok=True)
env.update(HOME=str(home), USERPROFILE=str(home), PYTHONPATH=str(root), PYTHONDONTWRITEBYTECODE='1')
python = '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python'
proof = subprocess.run([python, '-c', 'import minicode.memory_authority_publisher as p; print(p.__file__)'], cwd=root, env=env, text=True, capture_output=True, check=True).stdout.strip()
assert proof == str(root / 'minicode/memory_authority_publisher.py'), proof
started = time.time()
with (out / (label + '.log')).open('w') as log:
    log.write('publisher_import=' + proof + '\n')
    log.flush()
    result = subprocess.run([python, *args], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
meta = dict(label=label, root=str(root), publisher_import=proof, argv=[python, *args], returncode=result.returncode, duration_seconds=time.time()-started)
(out / (label + '.json')).write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
print((out / (label + '.log')).read_text()[-6000:])
sys.exit(result.returncode)
