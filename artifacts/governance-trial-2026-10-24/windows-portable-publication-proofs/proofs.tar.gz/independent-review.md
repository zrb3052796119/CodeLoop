# Windows portable publication 独立审查

结论：无阻塞发现，可接受当前最小补丁；本机 portable 反例不替代修复后的原生 Windows CI。只读审查，没有修改仓库、索引或额外运行 pytest；仅直接调用 fixture 做小型绑定隔离检查。

- 生产 diff 仅在 `minicode/memory_authority_publisher.py:1158` 加 `os.close(temporary_fd)` 和 `temporary_fd = None`。独立 AST 比对确认，移除这两条语句后与 HEAD 完全一致，POSIX 分支未变。close 位于 write/fsync/fstat/regular+size 校验之后、临时路径 lstat 之前；捕获的 inode/device/size 仍用于随后身份判断。
- 关闭后仍检查临时文件 regular/inode/size/reparse、父目录 inode 与 reparse 路径、既有目标 regular/reparse；replace 后仍检查已发布对象 inode/size/reparse 和父目录身份。关闭失败按原异常契约停止发布并清理；成功将 fd 置 None 避免 finally 重复 close。
- 测试是实际 mkstemp/fstat/fsync/close/replace/字节回读，分享冲突 seam 检查真实原 fd 已 EBADF，而非仅观察 close 调用。新增目标/覆盖目标各一例；after-close 同尺寸换 inode、同 inode 改 size、保留 temp inode 的父目录替换、目标改目录，均要求发布前拒绝及旧内容保持；postreplace inode/size/reparse 各拒绝。reparse 例只模拟 Windows 元数据标志，底层文件操作是真实的，没有冒充原生 Windows 测试。
- 最终测试 SHA `8561450fadc16e561a23d30fc9590221b53783c8cf755186d99984821d0aa938`，归档镜像与工作树字节一致。最终局部 fixture 相同字节、相同 argv：旧源 overlay 2 failed（0.32 秒），新源 2 passed（0.45 秒）；全 portable 10 passed（0.62 秒），安全/发布邻接 96 passed（3.30 秒）。overlay 实际导入路径、旧生产 SHA 与测试字节已独立核对。`before-positive.log` 属中间版，不用作最终同字节证据。原生产 SHA `3ae33616aa46b60cccbef75662be7e4f1210a7d2d02abe4f46610619da25b77a` 与 88ec/9f/Windows CI 故障源一致；原生 job 日志实际在 installed 包 _publish_portable 的 os.replace 抛 WinError32。
- 模块隔离已复核：4 个新增测试均显式依赖 `portable_publisher_modules`（第 740 行），先将 `publisher_mod.os` 绑定为保留原 API 的 SimpleNamespace、`publisher_mod.tempfile` 绑定为仅含原 mkstemp 的代理，后续 hook 只改代理属性。实际 `os.close/replace/lstat/fsync` 和 `tempfile.mkstemp` 不变；pytest monkeypatch 按逆序恢复属性和模块绑定。独立直接调用该真实 fixture、改动 5 个代理属性并退出，确认全部标准库属性与 publisher 绑定恢复；结果见 `independent-module-isolation-proof.json`。该探针未执行被替换函数、未另跑测试套件。
- 保留原 portable 限制：路径预后检查不能提供 POSIX dirfd 级 containment，也不能保证恶意同 UID 进程在校验间隙无法修改内容。补丁未将其表述为强竞态隔离，未移除任何现有检查。发布后检测异常意味着拒绝报告成功，不等于回滚已发生的 replace。

机器可读摘要见 `independent-review.json`。修复后的 Windows CI 与完整候选验收仍须另行记录。
