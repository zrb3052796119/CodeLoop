import json
import os
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(root), '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/lib/python3.12/site-packages']
os.chdir(root)
import pytest

print(json.dumps({'python': sys.version, 'pytest': pytest.__version__, 'root': str(root), 'args': sys.argv[2:]}), flush=True)
result = pytest.main(sys.argv[2:])
origins = {name: module.__file__ for name, module in sys.modules.items() if name.startswith('minicode') and getattr(module, '__file__', None)}
assert origins
assert all(Path(origin).resolve().is_relative_to(root) for origin in origins.values())
print(json.dumps({'minicode_module_count': len(origins), 'all_origins_within_source_root': True, 'run_command_origin': origins['minicode.tools.run_command']}), flush=True)
raise SystemExit(result)
