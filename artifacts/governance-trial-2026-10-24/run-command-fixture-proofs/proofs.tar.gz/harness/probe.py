from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import sys
import traceback

root = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
sys.path[:0] = [str(root), '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/lib/python3.12/site-packages']
import pytest
print(json.dumps({'python': sys.version, 'pytest': pytest.__version__, 'root': str(root), 'mode': mode}), flush=True)
os.chdir(root)
if mode == 'pytest':
    result = pytest.main(['-q', '-p', 'no:cacheprovider', 'tests/test_run_command_lifecycle.py::test_fallback_uses_process_group_and_windows_safe_flags'])
    target = sys.modules['minicode.tools.run_command']
    print('import origin:', target.__file__, flush=True)
    assert Path(target.__file__).resolve().is_relative_to(root)
    raise SystemExit(result)

import minicode.tools.run_command as target
assert Path(target.__file__).resolve().is_relative_to(root)
print('import origin:', target.__file__, flush=True)

spec = importlib.util.spec_from_file_location('fixture_test', root/'tests/test_run_command_lifecycle.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
workspace = Path(sys.argv[3]).resolve()
workspace.mkdir(parents=True, exist_ok=True)
error = None
patch = pytest.MonkeyPatch()
try:
    module.test_fallback_uses_process_group_and_windows_safe_flags(workspace, patch)
except BaseException:
    error = sys.exc_info()
finally:
    patch.undo()
if error:
    traceback.print_exception(*error)
    raise SystemExit(1)
print('direct test passed; shared platform state restored')
