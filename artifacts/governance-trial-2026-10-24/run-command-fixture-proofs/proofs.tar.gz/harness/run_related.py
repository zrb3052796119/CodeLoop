import json
import os
from pathlib import Path
import subprocess

p = Path(__file__).resolve().parent
root = '/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main'
env = {k: v for k, v in os.environ.items() if not k.startswith(('MINI_CODE_', 'MINICODE_')) and not any(s in k.upper() for s in ('TOKEN', 'SECRET', 'PASSWORD', 'CREDENTIAL', 'API_KEY', 'APIKEY'))}
env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1')
results = []
for label, interpreter in [('py311', '/Users/zhourunbo/.local/bin/python3.11'), ('py312', '/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python')]:
    home = p / ('home-' + label)
    home.mkdir(exist_ok=True)
    env['HOME'] = str(home)
    command = [interpreter, '-I', '-S', str(p/'run_tests.py'), root, '-q', '-p', 'no:cacheprovider', '-p', 'pytest_randomly', '--randomly-seed=20261024', 'tests/test_run_command_lifecycle.py', 'tests/test_background_tasks.py', 'tests/test_agent_cancellation.py', 'tests/test_tools.py']
    result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=180)
    log = label + '-related.log'
    (p/log).write_text(result.stdout)
    results.append({'label': label, 'command': command, 'exit': result.returncode, 'log': log})
    print(label, result.returncode, result.stdout[-3000:], flush=True)
(p/'related-runmeta.json').write_text(json.dumps(results, indent=2) + '\n')
