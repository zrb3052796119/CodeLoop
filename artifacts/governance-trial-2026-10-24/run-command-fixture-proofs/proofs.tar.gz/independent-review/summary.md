# Independent review: platform fixture isolation

GO — no blocking findings. Read-only review; no repository edits or additional pytest run.

The patch replaces only the run_command module bindings for os, sys and subprocess. It does not mutate the shared standard-library module attributes. The os.environ mapping is reused but this execution path only reads/copies it. MonkeyPatch teardown restores all local bindings. The proxy fields cover this Windows fallback path, and the copied subprocess namespace preserves constants/exception types/list2cmdline while replacing only Popen and CREATE_NEW_PROCESS_GROUP.

Existing result.ok, creationflags == 512 and exclusion of start_new_session assertions remain unchanged, with new assertions for unchanged global platform/Popen state. Synthetic wrong flags and unwanted start_new_session both fail these original assertions without breaking pytest.

I checked the original Python 3.11.15 direct Path(command) failure and pytest INTERNALERROR, final fixture pass, byte-identical ff2f production + final fixture pass with import-origin checks, and the 124-test Python 3.11/3.12 logs. Final test and runtime hashes independently match the preserved evidence copies. The fix addresses test isolation; it does not claim a production Windows behavior change or a completed CI rerun.
