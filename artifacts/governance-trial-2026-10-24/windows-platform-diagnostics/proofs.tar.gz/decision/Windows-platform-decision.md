# Windows 平台范围决策：保留失败事实，明确本期边界

建议选择 **A：本期以 Linux/macOS 为正式支持目标，明确收窄原生 Windows 为实验性入口/便携子集**，前提是用户明确同意改变既有平台承诺。若完整原生 Windows 是本期必需目标，应选 B 并安排原生 Windows 的修复与验收。这里的 A 是范围变更，不是把原 Windows 验收判成通过；当前尚未完成的 POSIX 验收也不能提前宣绿。

此次只读分析未改源码、CI 或 README，未运行新测试或调用模型。读取的是旧 P1 PR head `3cadcb7584526b41af7cc928d6c58d5bb19d8ea5` 的 CI run `40114448888`；Actions 原始日志显示实际 checkout 为该 PR 的 merge ref `5d3f61f77361dc107cb8bb2cc23e582563c16fcc`。没有把现在的修复候选当作旧 CI 运行源码。

## 已确认的验收事实

| 原生 Windows 运行 | passed | failed | errors | skipped |
|---|---:|---:|---:|---:|
| Python 3.11，job 120932734066 | 13,222 | 1,390 | 246 | 112 |
| Python 3.12，job 120932734106 | 13,217 | 1,395 | 246 | 112 |

安装、编译、打包和 committed archive 检查已独立完成；**完整 Windows 验收失败**。下面统计的是 JUnit 中 failure/error 记录的互斥 traceback 子串分组，包含 setup/teardown，不能直接当作相同数量的独立根因，也不能承诺一项修复能消除整个分组。

| 主簇 | 3.11 / 3.12 记录数 | 代码与证据 | 初步性质与安全边界 |
|---|---:|---|---|
| 找不到可信 Git | 739 / 739 | `minicode/workflow_workspace.py:516–535`；557 条直接落在 535。checkout 日志 56–57 显示 `C:\Program Files\Git\bin\git.exe`、Git 2.56.0.windows.2 已存在 | 不是缺 Git 安装。默认只搜 `os.defpath` 中绝对目录；Git for Windows 安装位置不在这条可信路径。已有 `MINICODE_TRUSTED_GIT_EXECUTABLE` 显式绝对路径入口，可做最小 CI 主机配置验证。不得回退为信任工作区/PATH 任意可执行文件。通过这一步也会暴露后续 safe-I/O 限制，不能推算 739 全绿。 |
| `O_NOFOLLOW` 缺失 | 142 / 142 | 133 条 `scripts/run_requirement_completion_checkpoint.py:108`，9 条 continuation 脚本 `:85` | 实验/恢复脚本直接使用 POSIX 安全文件标志；不是仅测试写法。不能用 `getattr(..., 0)` 取消防链接保护来伪兼容。 |
| Windows 证据绝对路径被拒 | 77 / 77 | `minicode/coverage_audit_state.py:33–38` | 实际运行时使用 `PurePosixPath` 并拒绝反斜杠；Windows 的盘符绝对路径也不满足 POSIX absolute。需要明确原生路径/序列化引用契约，并保留越界、伪造与证据绑定反例。 |
| `SIGKILL` 缺失 | 43 / 43 | 41 条 `scripts/three_arm_processes.py:346`，1 条 `run_three_arm_real.py:1041`，1 条测试 `test_three_arm_recovery.py:161` | 大部分是脚本执行路径。模块同时调用 `/bin/ps`、`os.getpgid`、SIGSTOP/进程组，属于真实 POSIX 进程树实现；不能用普通 terminate 替代后宣称同等后代清理保证。 |
| `fchmod` 缺失 | 34 / 34 | 33 条 `minicode/curator_schedule.py:984`；仅1条 `tests/test_conversation_turn_store.py:80` 自身读取缺失属性 | 前33条是真实持久化路径，后1条才是纯 fixture 缺陷。curator 后续还有目录 open/fsync；不能只给 fchmod 加 hasattr 就声称耐久性/隐私权限等价。 |
| Memory 发布目录不存在 | 36 / 36 | 35 条直接 `minicode/memory_authority_publisher.py:1112` | 原生 portable 分支真实失败；示例缺失 `.mini-code-memory` 父目录。需定位 portable 创建/事务绑定顺序，不能归为“从来不支持Windows”。 |
| Memory 路径身份/别名 | 35 / 35 | 33 条直接 `memory_authority_publisher.py:551` | 原始 trace 显示 `C:/Users/RUNNER~1/...` 与 `C:/Users/runneradmin/...` 词法 `relative_to` 不同。需处理长短路径一致性及重解析点/根身份校验；仅删除 scope check 不可接受。 |
| Candidate 安全读取不可用 | 20 / 20 | `minicode/implementation_candidate.py:182–188` | 明确 fail-closed：需要 `O_NOFOLLOW`、`O_DIRECTORY`、`os.open in supports_dir_fd`。这是能力缺失的显式拒绝；要支持相同安全功能需等价 Windows 实现，不能去掉 guard。 |
| Verification 安全 I/O 不可用 | 18 / 18 | `minicode/verification_output.py:43–49` | 明确 fail-closed，同样依赖安全目录/不跟随链接能力。 |
| Journal 写入后字节计数不符 | 13 / 13 | `minicode/subagent_journal.py:490` | 原 trace 在正常 start 后首次 append 即拒绝，尚未人工篡改。Windows binary/text I/O 与换行计数值得优先核查，但本次只读证据不足以确认唯一原因。 |
| `O_DIRECTORY` 缺失 | 10 / 10 | `scripts/run_requirement_completion_diagnostic.py:340` | 另一个实验脚本的真实 POSIX-only 文件操作。 |
| 其余尚未归因 | 469 / 474 | 完整事件清单与原始 XML 保留 | 包括 cp1252/UTF-8 编解码、精确字节 fixture/source pin 不匹配、下游 workflow 未启动断言等；不能统一归为 fixture 或已由 Git 根因解释。 |

以上已归类 1,167 条 failure/error；剩余数随 Python 版本差5。3.11 共1,636、3.12共1,641条 failure/error。Unicode 示例在测试 `Path.write_text(source)` 未指定 UTF-8 时失败；另有 scripts 读取和编码路径，不能一概只改测试。精确归因仍需要修复后的原生 Windows 小批验证。

## 平台承诺与实现现状冲突

- README `333–350` 明确给出 macOS/Linux 和 **Windows PowerShell 安装**，`364`及`400`附近继续给 Windows 配置与启动；`545–547`明确表示 Linux/macOS/Windows、Python 3.11/3.12 跑完整套件。
- README `76`、`115`把三 OS × 两 Python CI 和 Windows 加固列入项目证据。此为运行矩阵描述，不等于最近 Windows 已成功；应补实际结果，不能延用隐含全平台绿的读法。
- `.github/workflows/ci.yml:13–16`含三平台和两个 Python；**初始提交 `3036dd76`（2026-07-27）已有此矩阵**，不是本次治理临时新增。`1e5f3e15`新增随机 seed/JUnit，`c078b5b5`补归档输入恢复，未缩减平台。
- `pyproject.toml`要求 Python >=3.11，但没有 OS 支持限制或 POSIX-only 声明。缺少 OS 分类器本身不能当作支持承诺；应结合 README 与 CI 判断。
- README `591–595`已明确 Windows 后代进程清理限制，但没有说 workflow/coverage/Memory/恢复脚本整体不支持。
- 实现也不是统一 POSIX-only：`workflow_workspace.py:89`有 Windows 锁分支；`conversation_turn_store.py:767–774`按平台处理 fchmod/关闭后replace；`memory_authority_publisher.py:15`声明 portable fallback 并在 `:1158`专门处理 Windows replace。因此不能用“项目原本只面向POSIX”解释全部失败。

## 两个可选择范围

### A（建议）：本期收窄支持契约，保留 Windows 移植工作

需要用户明确同意调整已有平台承诺。正式验收目标为 Linux/macOS；原生 Windows 标为实验性、仅列出实际验证的安装/入口/配置/便携能力，且完整 runtime 未通过。若提 WSL，应明确那是 Linux 环境，不是原生 Windows 已通过。

具体可审阅修改提案：

| 验证层 | Linux/macOS | 原生 Windows |
|---|---|---|
| 安装、编译、CLI help/配置、打包/轮子来源 | 保持必过 | 保持明确列举的必过检查；本次先置步骤已有成功证据 |
| 完整 runtime suite、workflow、Memory、安全证据与进程树 | 本期正式验收目标，仍须最终候选真实跑绿 | 明示实验性/未支持完整契约；保留单独可见的完整诊断运行和 JUnit，报告失败；不称为全绿 |
| POSIX-only 实验守护/恢复脚本 | 保持功能与安全契约 | 记录未支持域，任何未来原生支持需相同边界的实现及原生验证 |

如未来把 Windows 完整诊断从“合入阻塞”改为“非阻塞可见诊断”，这是独立、显式的 CI 政策变化，必须在此次范围批准后写入 PR，并保留失败 artifact 与状态说明；不能偷偷 `continue-on-error`，不能批量 skip，也不能让子集绿被展示为完整Windows绿。最终子集清单应按可交付能力人工确定，并逐个原生验证，不通过排除失败 test 文件自动生成。

后续移植清单至少包含：可信Git发现、candidate/verification安全I/O、curator耐久发布、Windows native路径和长短名、Memory portable创建顺序、进程树/Job语义、UTF-8/二进制换行、fixture portability，以及这些边界的负例与原生矩阵验证。

### B：本期纳入完整原生 Windows 兼容

保留三平台完整必过的承诺，按“CI可信Git显式主机路径 → 编码/精确字节输入 → 安全I/O与持久化 → 路径身份 → 进程树 → 剩余原生回归”的顺序处理。Git设置和1个fchmod fixture可小范围修，**其余跨越多个真实生产域，不是一个统一小补丁**。需可运行 Windows 的环境/CI，对每个安全分支保留真实红绿和负例，再跑完整3.11/3.12。现有32-cell POSIX实验与本期已授权POSIX修复可继续，不把它们的成功替代Windows验收。

## 证据与限制

- 原始证据：`/private/tmp/codeloop-governance-20261024/ci-40114448888/windows-{311,312}-pytest-results.xml`，及对应 job raw log/summary。
- 互斥分组、逐事件索引、代表完整 traceback：`ci-40114448888/windows-platform-audit/windows-{311,312}-{classified,events}.json`。
- 精确源位置取自当前只读 P1 文件；已逐字节核对13个主要源文件与旧 PR head 3cad 完全一致，结果在 `windows-platform-audit/source-comparison.json`。本文没有声称新候选已在Windows复现、修复或通过。
- 没有读取凭证或改动正在进行的 ROOT 32-cell 实验、其源码和预注册。
