import collections,hashlib,json,re,xml.etree.ElementTree as ET
from pathlib import Path
p=Path(__file__).resolve().parent;source=p.parent
patterns=[('git_trusted_discovery',r'host Git executable is unavailable'),('os_nofollow_missing',r"module 'os' has no attribute 'O_NOFOLLOW'"),('coverage_posix_reference',r'coverage checkpoint reference or bytes changed'),('signal_sigkill_missing',r"module 'signal' has no attribute 'SIGKILL'"),('os_fchmod_missing',r"module 'os' has no attribute 'fchmod'"),('memory_publication_directory',r'Memory publication directory is unavailable'),('memory_publication_path',r'Memory publication target escapes its transaction root'),('candidate_safe_io_unavailable',r'safe descriptor-relative candidate reads unavailable'),('verification_safe_io_unavailable',r'safe verification output I/O unavailable'),('journal_changed',r'sub-agent journal changed outside its writer'),('os_getuid_missing',r"module 'os' has no attribute '(getuid|geteuid)'"),('fcntl_missing',r"No module named 'fcntl'"),('os_directory_missing',r"module 'os' has no attribute 'O_DIRECTORY'")]
allout={}
for platform in ['windows-311','windows-312']:
 path=source/f'{platform}-pytest-results.xml';tree=ET.parse(path)
 events=[];outcomes=collections.Counter();messages=collections.Counter();groups=collections.Counter();origins=collections.defaultdict(collections.Counter);examples={}
 for case in tree.iter('testcase'):
  marks=[x for x in case if x.tag in ('failure','error','skipped')]
  if not marks:outcomes['passed']+=1
  for item in marks:
   outcomes[item.tag]+=1
   if item.tag=='skipped':continue
   txt=item.text or '';msg=item.attrib.get('message','');combined=msg+'\n'+txt
   group=next((key for key,pattern in patterns if re.search(pattern,combined)),'unclassified')
   locations=re.findall(r'^([^\n]*?\.py):(\d+): (?:[\w.]+Error|AssertionError|[\w.]+Exception|[\w.]+Unavailable|[\w.]+UnsafePath|[\w.]+Failure)',txt,re.M)
   origin=':'.join(locations[-1]) if locations else ''
   node=case.attrib.get('classname','')+'::'+case.attrib.get('name','')
   groups[group]+=1;origins[group][origin]+=1;messages[msg]+=1
   row={'node':node,'type':item.tag,'group':group,'message':msg,'origin':origin}
   events.append(row)
   if group not in examples:examples[group]={**row,'traceback':txt}
 summary={'platform':platform,'junitSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'outcomes':dict(outcomes),'totalOutcomeRecords':sum(outcomes.values()),'exclusiveSubstringBuckets':dict(groups),'bucketOrigins':{g:dict(c.most_common(20)) for g,c in origins.items()},'topUnnormalizedMessages':messages.most_common(55),'examples':examples,'note':'Buckets are mutually exclusive traceback substring groupings, not independent proven causes or guaranteed recoverable counts.'}
 (p/f'{platform}-classified.json').write_text(json.dumps(summary,indent=2)+'\n')
 (p/f'{platform}-events.json').write_text(json.dumps(events,indent=2)+'\n')
 allout[platform]={k:summary[k] for k in ('outcomes','exclusiveSubstringBuckets','bucketOrigins')}
print(json.dumps(allout,indent=2))
