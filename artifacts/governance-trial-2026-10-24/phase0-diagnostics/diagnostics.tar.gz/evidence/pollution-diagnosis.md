# Suite order diagnosis — 2026-10-24

No repository changes were made by this subtask. The claimed latest full-run log (14,522 passed / 359 failed / 22 errors) was not found; an older /private/tmp/pytest-full-20261021.log has different counts and cannot establish the current failure snapshot.

## Same-current-tree probes

- tests/test_tools.py then tests/test_workflow_v2_structured_routing.py: 151 passed in 31.46s.
- Collect all tests, execute only test_public_low_scoped_change_defaults_to_executor_verifier_route: 1 passed, 4 skipped, 14,833 deselected in 14.45s.
- First 32 alphabetic test files before test_central_multi_agent_scheduler.py, excluding slow test_agent_quality_evaluator.py, then the routing victim: 3 failed, 483 passed in 74.58s; routing victim passed.
- Early prefix including quality evaluator was interrupted after it stalled in quality-report evaluation, to avoid overlapping the incoming frozen full run.
- tests/test_tools.py::test_core_tool_registry_does_not_import_utility_modules then test_http_request_safety.py: 70 passed, 1 failed; failure was sandbox PermissionError binding a loopback server, not an order-related assertion.

## Concrete failures in the early prefix

- test_behavior_evidence_parent_continuation.py::test_behavior_gap_returns_to_original_owner_for_real_repair_and_delivery, helper-only / omitted-sub-obligation: expected verified assistant response but received partial host receipt, requirementsAccepted=false.
- test_capability_registry_snapshot.py::test_core_tools_publish_complete_capability_metadata: actual core includes inspect_image absent from expected metadata list.

## Claim boundary

Suite pollution remains suspected, not reproduced. Standalone-green vs an earlier full-red run is insufficient without the same source snapshot and failure details. Current probes reject collection-time contamination and tools-module contamination as causes for the first routing victim. Root is preparing a frozen HEAD+WIP checkout and seeded full run. New repair requires a concrete red order/fresh failure; no broad global reset was added to conceal unexplained failures.

## Independent fixture repairs

The three independent failures reproduced standalone (3 failed in 8.58s). Original test bytes and SHA256 are retained in pre-fixture-repair/.

Instrumented receipts (behavior-diag-helper-only.json and behavior-diag-omitted-sub-obligation.json) show the intended same-owner repair occurred, actual public tests passed, and the second reconciliation stopped at the four-call bounded allowance with completion_review_budget_exhausted/model_calls. The first audit consumes three reconciliation model turns; the second requires further evidence reads and submission. This is the intended bounded-mode policy, not missing continuation or accepted weak evidence.

A one-variable environment probe selecting full review mode passed both behavior cases before the fixture edit (2 passed /8.37s). The fixture now explicitly selects full mode to test the two-audit continuity contract; every original source/receipt/witness/ownership/acceptance assertion remains intact. Separate bounded-review phase and limit tests remain in the validation set.

The capability snapshot now expects inspect_image as analysis/external, matching the explicit core registry declaration. No production files were changed.

Post-edit fixed-order validation: 53 passed /10.11s across both repaired test files, test_native_review_phase_limits.py and test_completion_review_limits.py. Fatal Ruff selection E9,F63,F7,F82 passes. Strict default Ruff reports preexisting I001/C408 style issues in the behavior fixture (untouched).

Counterexample claim boundary: this is a fixture migration to already-implemented current contracts, not a new production bug fix. No claim of test-counterexample PROVEN is made against unchanged production. The original-vs-repaired test evidence is retained explicitly rather than mislabeled as a production baseline failure.
