# HTTP module cache pollution, continuous timeout fixture, feedback classification

Changes owned in this batch: tests/test_tools.py and tests/test_continuous_request_policy.py only. No HTTP production changes, no altered HTTP expectations, no skipped tests.

HTTP causality: frozen R2 and current both reproduce 2 passed / 1 failed for core-registry lazy-import test -> full-registry test -> pinned-destination HTTP victim. Omitting the middle reimport gives 2 passed. The core test deleted utility modules from process-global sys.modules without restoring their identity. Reimporting a full registry creates new module objects; collected HTTP ToolDefinition still uses old globals while monkeypatch resolves the new module. The exact old core import-check procedure now runs in a disposable interpreter, preserving its all-utilities-absent assertion and additionally checking core read/write tools exist. Existing HTTP victim bytes remain identical to R2.

A temporary test-only socket tripwire denies all non-loopback socket connections. The one HTTP fixture needing localhost bind was run with sandbox escalation; this was local fixture access only. Standalone restricted-sandbox PermissionError on that server is environment evidence, distinct from the original twenty request_failed assertion failures.

Logs: http-module-pollution-r2-red.log; http-module-pollution-current-red.log; http-module-pollution-r2-minimal.log; http-module-pollution-full-http-green.log; http-module-pollution-r2-fixed-tests-green.log. Proof manifest: http-module-pollution-proof.json. Fixed current 86 passed (3.51s), exact final test files over unchanged R2 production 86 passed (3.32s), including all HTTP safety and continuous request policy tests.

Continuous request policy has the same fixture drift diagnosed in continuous_agent_diagnostic: assert the actual distinct idle/read cap 60 and connect/TLS metadata cap 30. Preserve no request deadline, exact output cap, complete usage, and completed streaming behavior. Its R2 red is in runtime-http-policy-feedback-r2-before.log.

Feedback failure is separate confirmed singleton pollution fixed by evidence_audit: frozen R2 multi smoke -> finalization feedback victim gives 1 passed / 1 failed with evaluation_write_scope_denied; current runner overlay fix yields 2 passed. Logs feedback-runner-pollution-r2-red.log and feedback-runner-pollution-current-green.log. No feedback test changes.

Scoped undefined-name Ruff checks and git diff --check passed. Shared runtime-triage.json updated after reread; global provenPollution is now true based on concrete minimal ordered reproduction.
