# Independent review of root governance changes

Scope compared with the initial dirty snapshot, not unrelated WIP: MCP SSE error binding/tests; tooling getter; workflow_runner unused import; audit inventory assertions; pytest-randomly/CI; README mock description. No review edits made.

## Finding
P2 — tests/functional_audit/test_runner.py capabilityCount assertion: replacing the fixed inventory cardinality with len(payload["capabilities"]) removes the independent completeness signal for non-registered-tool capabilities. scripts/run_functional_audit.py:1916 already assigns exactly len(capabilities), so omitting a non-tool entry leaves both values consistent; the new EXPECTED_REGISTERED_TOOLS set cannot catch omissions outside that category. Freeze a non-tool ID inventory (or independently expected per-category sets) if this test continues claiming exhaustive coverage. Identity assertions improve on a brittle total, but the full inventory needs an independent oracle.

## No new blockers found
- MCP: the error path previously referenced self from a staticmethod; passing server_name from the real parsing caller repairs that exact NameError. Tests call _parse_response_body with realistic headers/bytes and assert RuntimeError plus server/id, so the original failure is distinguishable. Success case covers skipping unrelated events. No network invocation.
- Tooling: lambda-to-def maintains the same getter closure, argument defaults and getattr behavior; postponed annotations avoid runtime effects.
- Workflow: only a genuinely unused import is removed relative to the initial snapshot.
- CI: seed interpolation is a numeric GitHub expression, no platform-specific shell syntax; the same run_number is used across all matrix entries and retries. pytest-randomly is in dev deps, and -ra preserves its seed header. Artifact name includes OS/Python/seed and always uploads an available JUnit report. This is static portability review, not executed Windows/Linux CI.
- README mock: configuration is loaded before adapter selection in agent_runtime; MockModelAdapter has scripted /ls and /read paths and natural-language help fallback, matching the new text.

## Executed review checks
.venv-acceptance/bin/python -m pytest tests/test_mcp_sse_response.py tests/functional_audit/test_runner.py --randomly-seed=20261024 -q
Result: 1 failed, 7 passed in 30.03s. Existing audit HTTP fixture expected a blocked: status but received PermissionError; not attributable to the reviewed diff and potentially caused by this execution sandbox's socket restriction. MCP tests all passed. Log: root-review-focused.log.

## Proposed first Phase 1 boundary (not implemented)
Existing enforce_skill_load_before_final is 23 physical lines, four lexical captures, one nonlocal reassignment, and two finalization call sites. SkillLoadGate can own only the normalized required_skills immutable set and one nudged flag. Its evaluation receives the current successful loaded-name set and returns status/feedback; the loop retains appending messages, callbacks, cancellation checkpoints, outcome assignment and control flow. Keep existing strings and sorting. The same normalized required set must remain available for the feedforward step-budget count. The tracker remains turn-local and populated only by actual successful load, never transcript replay. Keep discovery advisory semantics separate on the first change. A module-local class initially avoids adding a module family; moving an existing gate is not an added gating behavior. Do not refactor until full baseline is complete.

Validation for that future extraction must cover both existing finalization branches (assistant final and tool_calls with no calls), first refusal retry, second refusal failed status, successful load after retry, distinct turn reset, load capacity beyond telemetry truncation, and exact callback/message ordering. Current empty-calls branch emits callbacks earlier than the assistant branch; preserve that behavior in a mechanical extraction or address it as a separately authorized semantic fix.
