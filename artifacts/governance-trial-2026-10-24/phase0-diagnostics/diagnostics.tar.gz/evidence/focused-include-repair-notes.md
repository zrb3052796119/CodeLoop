# Focused include search: Phase 0 diagnosis and repair

## Contract
In opt-in bounded implementation mode, a directory plus one exact include must execute as one permitted existing file; wildcard/multiple/hidden/path-like includes, directories, and escaping symlinks must be rejected before searching. Continuous mode retains recursive glob semantics while silently filtering inaccessible descendants of a permitted search root.

## Reproduction and hypotheses
- Initial command: .venv-acceptance/bin/python -m pytest tests/test_focused_include_search.py -q
- Initial result: 16 failed in 1.54s; minimized symlink/directory pair: 2 failed in 1.73s.
- Ranked hypothesis 1: tests failed to opt in to the current bounded phase policy. Prediction: changing only the host bounded flag restores all old cases. Confirmed: 16 passed in 1.81s after that one-variable probe.
- Ranked hypothesis 2: the active phase guard failed to narrow include to a file. Falsified for these cases: _exact_include_target and admit_batch already implement narrowing when bounded is active.
- Ranked hypothesis 3: successful empty scans were mistaken for permission bypass. Confirmed: continuous grep filters inaccessible descendants and returns No matches found. Neither original symlink nor permission result exposed denied content.

## Semantic decision
Repair the stale fixture, not production behavior. ImplementationPhaseController explicitly documents continuous-by-default and bounded opt-in; admit_batch returns no phase rejections when not bounded. Neighboring phase tests already pass bounded_implementation_phases=True. The focused helper had omitted that migration.

Only tests/test_focused_include_search.py changed for this repair: explicitly choose bounded mode; make the outside_secret sentinel match the grep pattern; add one continuous recursive-include control and two continuous permission/symlink controls. No production search or phase source changed.

## Validation
- focused + phase tests: 53 passed.
- focused, executor-scoped search, source/navigation line identity, implementation phase and continuous tests: 139 passed in 6.89s.
- Ruff for focused tests and new analyzer: passed. git diff --check: passed.
- Final exact test bytes run on current production and reconstructed initial production: 19 passed on both. Counterexample status UNPROVEN is expected because this is fixture migration, not a production fix.
- Initial verifier attempt using baseline/ was INVALID evidence despite its raw PROVEN label: baseline/ is a delta-only backup, so Python fell back to the editable working-tree package. The existing import-root assertion caught it. That result is preserved as focused-include-counterexample-invalid-import.* and must never be cited as regression proof.
- Correct complete initial-source reconstruction: focused-include-initial-source/ = recorded initial Git HEAD minicode/tests/pyproject + baseline-manifest dirty file overlay and removals. Final verifier passed the import-root assertions.

## D1 measurement
Added scripts/analyze_agent_turn_state.py and docs/agent-turn-state-ownership-2026-10-24.md. AST boundaries + compiler symtable distinguish locals, parameters, free vars, owners, module globals, builtin references and explicit writes; 30/30 closure free-var sets match independently compiled CPython code objects. A tiny nested-scope fixture checks classification/ownership. Measurements: 26 immediate-body function definitions; 28 direct lexical children; 30 nested functions total; 91 unique turn captures, 40 shared by multiple closures (43.96%), 26 shared across six review responsibility groups (28.57%). The >60% cross-group threshold is not triggered. It remains a limited lexical metric, not all runtime coupling; direct whole-loop extraction is not authorized by this result. No production-loop refactor or new gate was added.
