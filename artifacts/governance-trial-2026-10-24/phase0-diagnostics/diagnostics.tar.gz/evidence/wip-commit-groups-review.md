# 原有 WIP 提交边界审阅（2026-10-24）

结论：最小安全方案是 **memory → core（workflow/completion/scheduler/transport）→ eval/docs/evidence**。不应按四个功能名直接整文件分四次提交。本次只读分析，未修改生产、运行测试、暂存或提交。

- 初始快照共 137 项：104 项已跟踪改动（含两项删除），33 项未跟踪源码/测试/文档。与快照相比仅 README、tooling、workflow_runner、pyproject 有后续内容差异，均须保留治理修复。
- memory 可以独立闭合：原有 memory/reflection 模块、run_events、run_journal、memory 脚本/测试与依赖配置；从 agent_loop 只取第 2725–2727 行 draft_rendered_ids hook。test_runtime_observation_events 的全部初始改动也是两项 memory 归因回归。
- core 应合并提交：LimitedBudgetView、ToolContext review limits、ToolUsageCounts、scheduler v6、admission、长 brief/输出传输彼此穿过 agent_budget/tooling/workflow_runner/tools/task；agent_loop 剩余部分同时改变完成审查和可委派提醒。只是 import 通过不足以证明拆分安全，还存在新增关键字参数、版本/审计协议耦合。
- 五个原有新生产模块均存在实际 import：completion_review_limits、memory_deposition_experiment、memory_hot_store、workflow_admission、workflow_brief，必须随所属闭包提交。
- agent_protocol/context_isolation 删除未发现内部残留引用。AST 扫描 1,212 个 Python 文件；两份原有语法错误测试另用文本补查。该结论仅针对内部静态引用，不证明外部导入兼容。
- 未跟踪 artifacts 541 项中，83 项（2,889,198 字节）有明确文件引用、传递证据引用或公开报告明确声明的同目录原始 JSON 保留承诺。精确路径、SHA256、引用文件/行号均在 JSON。最硬的漏项风险是 tests/test_multi_agent_trigger_audit.py:25 读取 pack-v3 下 source-manifest.json、offline-proof.json、reference-fixes.json；tasks.json 也未跟踪，被 .gitignore:110 的 /artifacts/**/tasks.json 规则忽略；首次审阅误称已跟踪，现已更正。
- 这四个测试输入应先单独补齐，或随最早的 runtime 提交一起加入；不能拖到最后的文档提交才补，否则中间提交的干净检出仍会缺夹具。
- 余下 458 项只列为可恢复本地归档候选；目录级历史引用单列，不能据此断言全部可删除。脚本默认输出路径不等于运行输入。已公开引用的原始证据若需移走，应先提供经过验证的恢复清单并修正引用。

详细、可机读方案：`wip-commit-groups.json` 的 `minimum_safe_groups`、`new_module_import_evidence` 和 `untracked_artifact_audit`。
