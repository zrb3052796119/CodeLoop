# R2 runtime fixture triage

Frozen diagnostic snapshot: `cb327c3796b0d34fb3235a15fec6f1988f072adf`, source `full-run-source-r2`, seed `20261024`.

The two initial runtime failures reproduce with the exact original tests on the frozen source (`r2-first-failures-standalone.log`: 2 failed in 2.66s). They are independent contract migrations, not evidence of test-order pollution.

- `tests/test_intent_runtime_integration.py`: retain the exact shared call-context equality and include the two new default-False directory/discovery controls.
- `tests/test_conditional_handoff_request_pricing.py`: explicitly enable bounded implementation phases for this bounded repricing scenario. Model fixture now independently serializes the actual visible tool schemas, includes their cost in reported input usage, and requires an exact message-plus-schema reservation. The phase-specific transcript estimate remains message-only as designed. All existing conditional-mode notice, ownership, blocker, and exact budget settlement assertions remain.

Validation after migration: 31 passed in 3.75s, seed 20261024, covering both changed files plus continuous-phase, finalize-deadline, and request-schema-budget contracts (`r2-first-failures-fixed-final.log`). Default Ruff passes both changed files.

No production code changes and no global reset/skip were introduced. The frozen full run continues unchanged, so its expected failures remain recorded separately from fixes in the working source.

## Finalization fixture migration

Five failures from `test_finalize_checked_completion.py` reproduce standalone on the frozen R2 source (5 failed, 4 passed, 4.80s). All file scenarios now explicitly select bounded phases, including the nested executor. The workflow requests its independently reviewed route explicitly. The direct flow substitutes its independent semantic assessment boundary only after checking actual changed source and nonempty passed receipts bound to the current production digest. Final delivery remains subject to the real completion gate; no success is invented.

Final exact file: 9 passed in 7.92s; adjacent bounded/continuous batch: 36 passed in 14.64s. Default Ruff passes. Negative tool-visibility checks also assert outside the model callback, because the production loop catches model callback assertion exceptions.

Fault counterexamples (diagnostic-only plugins, no committed fault):
- Remove actual check rows after the real public command passes: direct completion returns rejected/partial, and the outer success assertion fails. Captured assessment has sourceMatches=true, checksPassed=false.
- Force the four bounded negative-capability tests into continuous mode: all four fail at the new outer visibility assertion. Their internal model assertion is indeed logged and caught, demonstrating why an external witness is necessary.

Evidence: `r2-finalize-checked-standalone.log`, `r2-finalize-checked-final.log`, `r2-finalize-checked-neighbors.log`, `r2-finalize-missing-receipt-counterexample.log`, `finalize-receipt-counterexample.json`, `r2-finalize-visibility-counterexample.log`.
