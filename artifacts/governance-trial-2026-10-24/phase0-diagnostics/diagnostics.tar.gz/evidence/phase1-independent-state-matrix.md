30 closures; 92 captured turn bindings; cross-responsibility sharing 30.43%
