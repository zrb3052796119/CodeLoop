# R2 evaluation write-scope pollution — causal repair

Frozen R2 original sources remain unchanged. The copied R2 source uses the original source manifest hashes. No API requests or provider network calls were made; the existing harness uses a scripted adapter. No workflow/core code or victim assertions were weakened.

## Cause and change

`tests/test_single_vs_multi_live_harness.py::test_real_runtime_smoke_uses_local_scope_and_provider_receipts[multi]` at 67% of the remainder invokes the old two-arm runner. `ToolRegistry.filtered` borrows process-global core definitions. `execute_trial` assigns its observed task closure to that borrowed object, leaving `authorized_paths=["value.py"]` active for later production task calls. Five victims that pass alone fail after this one prefix; the full remainder contains 40 failures showing that exact leaked rejection text.

The old runner now overlays a copied task definition onto the filtered registry before attaching its observer. Each role and trial gets its own wrapper; owner disposal and the evaluation's write-scope denial remain intact. The existing smoke test checks that the production task handler retains identity after the real runtime completes.

## Evidence

- `submission-r2-before.log` and `submission-r2-random-before.log`: these five victim nodes pass without the contaminating prefix; the only failures are three distinct implicit-role fixtures fixed separately.
- `workflow-scope-r2-red.log`: original frozen prefix + five original victims = **1 passed, 5 failed**.
- `workflow-scope-r2-green.log`: identical copied R2 sequence with only `scripts/run_single_vs_multi_live.py` changed = **6 passed**. The original victim tests are byte-identical.
- `workflow-scope-counterexample.log`: the strengthened final smoke regression on the original R2 runner = **1 failed** at task handler identity, after the evaluation's actual write and oracle succeeded.
- `workflow-scope-current-related.log`: all four relevant files pass with final fixture inputs and runner repair.
- Ruff E9,F and git diff --check pass.

The 40 matching error strings identify the wider affected family, not a claim that all 40 have been rerun here. The full randomized acceptance run is still required. Full commands, return codes and timings are in the corresponding `.json` files; source digests are in `workflow-scope-*-source-manifest.json`. The original R2 source hashes were rechecked after proof.

## Read-only legacy commit authority review

The new legacy branch in `workflow_runner.prepare_commit` is restricted to policy 2/3 with exact `route.scoped_change` Executor→Verifier stages. It binds workflow/task, the current verification artifact, executor assignment, frozen patch, all required checks, passed aggregation, and equality with the actual state verification result. The existing commit-ready persistence and promotion checks still apply. Current policy 6 cannot select this branch via user request fields. The added tamper tests keep genuine passed verifier output and reject current-policy/stale-patch/missing-check evidence before writeback. No actionable bypass was established. Policy is recomputed rather than persisted in this branch, but current code exposes no user input that selects old policy; current mismatches fail closed.
