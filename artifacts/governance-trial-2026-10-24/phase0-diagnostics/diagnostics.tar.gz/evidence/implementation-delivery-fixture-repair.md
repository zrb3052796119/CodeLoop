# Delivery receipt fixture migration

Frozen R2 original fixture: 8 failed / 1 passed (10.21s), `implementation-delivery-r2-before.log`. Its implicit bounded policy produced final_start=None, its disabled-phase case expected the rejected final not to retry despite eight available calls, and the no-edit case expected success without the now-required host completion checks.

The fixture now explicitly requests bounded scheduling and the exact finite scenario budget (1/2/3 calls). This reflects its original no-extra-call contract. Failed completion wording remains in rejected progress and is never presented as accepted delivery. Partial receipt fields include actual requirementsAccepted=false and completionReview=rejected. No-edit final executes a real failed public test and remains partial.

The repaired case isolates semantic coverage assessment only: actual app.py must equal value=3, check list must be nonempty and all passed, and every receipt must bind the current candidate digest. An outer assertion independently checks the observations. Real writes, subprocess failure/pass results, cleanup, presentation failure, original KeyboardInterrupt/TurnCancellationRequested identity, failed/cancelled outcome and no continuing work remain asserted.

Validation:
- Current file: 9 passed (9.05s); final imports sorted, default Ruff green.
- Seeded neighboring finalization/continuous/outcome/cancellation suite: 75 passed (14.58s).
- Exact final test bytes over byte-identical immutable R2 production: 9 passed (10.55s), `implementation-delivery-r2-migrated.log`; source/test hashes in `delivery-fixture-r2-manifest.json`. This is a test-contract migration, not a production repair or an order-dependent failure.
- Diagnostic boundary fault: remove actual completion check receipts while retaining status; positive case fails at the model-external checksPassed assertion (`implementation-delivery-missing-receipt-counterexample.log`, 1 failed2.71s). This synthetic fault is test-signal evidence, not a historical PROVEN production regression claim.

No production files changed for these eight failures.
