# Phase 0 staged Memory baseline repair

The original v41 suite reproduced 12 failures / 11 passes. All failures descended from build_v41_candidate rejecting two source changes missing from the explicitly staged closure. No release-join or manifest-pin verifier was defective.

Pinned v40 source bytes for minicode/memory_curator_agent.py and minicode/run_events.py were recovered read-only from commit45e9a0cbb9addcf17339d323cd3b18f673b2d8c1 and verified against immutable v40 manifest SHA256. Current curator reserves provider-aware input through model_call_control. Current run_events records turn-local Skill discovery plus rendered Memory draft attribution. Both join the transport/runtime/lifecycle source boundary already staged in v41.

Decision: update existing unpinned v41 source candidate definition from23 to25 changed files, with explicit persistent_memory_lifecycle_authority reasons and matching independent closure set. This updates a staged source inventory, not a frozen evidence artifact. No minicode runtime file was edited. Tests retain rejection of truly undeclared inherited source mutations (conversation_turn_store and memory_store), and verify that a valid staged candidate still cannot activate without manifest and release join pins.

Validation:
- Original unchanged suite:12 failed,11 passed (baseline-v41-red.txt).
- Fixed focused suite:24 passed (baseline-v41-green.txt).
- Same exact final tests against isolated original HEAD baseline script:13 failed,11 passed, all attributable to missing source closure; fixed24 passed. Bundled test-counterexample verifier status PROVEN (v41-regression-proof.json). No import/missing-fixture failure.
- Related production-baseline and baseline-contract suite:193 passed in96.60s (v41-related-regression.txt).
- Scoped Ruff E/F:passed.
- All40 v1–v40 pinned manifests retain their original SHA256. ACTIVE_BASELINE_VERSION remains v40; active verifier matches=false against evolved source; select_active_production_hashes(v41)={}. No v41 manifest, release-join receipt, live request, new gate, or memory module created.

Changed files: scripts/memory_retrieval_production_baseline.py; tests/test_memory_retrieval_production_baseline_v41.py.
