# Runtime/bootstrap/review repairs

Owned files: scripts/run_requirement_completion_checkpoint.py; tests/test_requirement_completion_bootstrap_recovery.py; tests/test_continuous_agent_diagnostic.py; tests/test_requirement_review_integration.py.

Bootstrap production defect: the recovery gate treated durationMs > 0 as proof of execution, although unavailable-sandbox host preparation genuinely takes time. The final gate accepts only non-boolean, nonnegative integers and retains all original receipt identity, unavailable failure, absent exit code, and empty output requirements. A deterministic verifier clock emits positive preparation duration; eleven tamper cases cover invalid duration, exit/status/failure/identity, and nonempty stdout/stderr. The fixture's native resume now dispatches inspection before coverage audit; first read-only dispatch, three rechecks, phase order, final approved state, candidate bytes, and immutable predecessor artifacts are asserted externally.

bootstrap-duration-real-proof.json: PROVEN. Same final test bytes: fixed 2 passed, real frozen R2 2 failed at the original duration==0 gate. bootstrap-r2-baseline-manifest.json verifies 438 production Python files copied byte-for-byte from immutable R2.

Continuous transport fixture: request idle/read timeout 60 and physical connect/TLS metadata 30 are separate controls. Both are now asserted along with exact max_tokens=8192, complete 1,400,016 token usage, zero rejection, and 300-second request deadline.

Requirement review fixture: failed independent evidence now enters separate product-gap attribution; after repair, native independent inspection precedes coverage reconciliation. The scripted model routes by actual tool registry, uses unique tool call IDs, and preserves genuine failing and passing probes, one immutable probe identity, both candidate digests, exactly four subprocess executions, unchanged candidate during review, blocked premature approval, and zero-call approved cache reuse. Actual source reads and failure receipt validation are asserted outside the model.

The final two protocol fixtures pass all 12 tests against byte-identical R2 production (runtime-protocol-fixtures-r2-migrated.log); these are fixture drift, not claimed new production fixes or pollution.

Final current scoped run: 86 passed in 89.19s, --randomly-seed=20261024, five files including checkpoint and revalidation neighbors. Log runtime-bootstrap-review-final-seeded.log. Ruff F821/F822/F823/E9 and git diff --check pass; repository-wide style debt is outside these minimal fixes. No provider calls or second full suite.
