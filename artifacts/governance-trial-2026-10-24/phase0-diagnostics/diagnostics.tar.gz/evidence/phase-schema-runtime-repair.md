# Runtime repair evidence

Contract: Given a finite shared budget with real failed Executor checks and enough room for the complete selected request, when bounded phase output is sized, the loop must price the same messages and tool schemas as atomic admission, preserve the downstream floor, reach the same Executor and retain fail-closed behavior for unaffordable/inconclusive repair.

## Cause and minimal production change

The phase controller sized output from message-only input, while the atomic reservation included selected schemas. A recorded boundary reservation was used=476018, full input=3581, retained tail=20512: 500111 > the unchanged 500000 limit. Increasing fixture headroom merely enlarged the output quote by the same amount; this was a production pricing mismatch, not insufficient fixture budget.

`minicode/agent_loop.py` now previews the candidate phase on a copy, selects its actual tool view, and calls existing `estimate_budgeted_request_input` before sizing output. The copy does not consume notices or mutate actual phase state. Existing atomic admission remains authoritative. Original 500000 token / 40 call totals and 512 local margin remain unchanged. Exact isolated production diff: `phase-input-schemas.patch`.

## Current fixture contracts

- Failed candidate repair explicitly selects bounded phases and independent review. A semantic Analyst boundary diagnoses an actually missing regression file after a real formal failure. Executor and Reviewer loops, real file edits, public pytest, independent probe, transaction promotion and durable replay remain production paths.
- Successful scenario preserves nine original public/formal receipts plus exactly one real independent probe, selected by actual Reviewer Assignment identity (the probe reuses the public check ID). Exact same-session and budget assertions remain. Audit replay must equal persisted audit. Removing the diagnostic Analyst input ref or moving its completion after the dependent Reviewer dispatch must reject.
- Conditional repricing independently serializes selected schemas and requires exact full-input reservation and phase remembered input.
- Finalize output tests explicitly select bounded phases; all original ceilings, retained floors and real checks remain.
- Executor continuity partial session initializes real ReviewerProbeLedger, RLock and verification-output ledger; closes owned ledger. It still requires real failed->passed checks, one model, exact budget settlement and untouched parent workspace.
- Handoff observation partial state initializes actual empty review ledger/default mode. 3000 character bound, complete JSON, retention counts and secret redaction remain; actual emitted payload is checked for the secret.

## Baselines and validation

- R2 immutable source: `full-run-source-r2`, snapshot cb327c3796b0d34fb3235a15fec6f1988f072adf. Trimmed proof baseline `phase-schema-real-before-source` contains byte-identical production Python; hashes in `phase-schema-real-before-manifest.json`.
- Initial bundled verifier attempt omitted a sibling helper: its collection failure is INVALID_BASELINE_HARNESS, preserved in `phase-schema-real-proof-harness-error.json`; it is explicitly not proof.
- Before fixture migrations, `phase-schema-critical-regressions.log`: ten independently failing finalize/continuity cases. After migration and observation repair, `runtime-fixtures-final.log`: 22 passed.
- `executor-observation-before.log`: direct AttributeError for review_check_mode; before fixture bytes/hash preserved separately.
- `phase-candidate-current-final.log`: final candidate fixture 3 passed, including replay and tamper checks.
- Final bundled same-test real snapshot proof: PROVEN, current 4 passed (40.49s), baseline 4 failed (15.20s) at intended budget/input assertions. Evidence: `phase-schema-real-proof.json`. Seeded critical combined suite: 100 passed (69.58s), `phase-schema-final-critical.log`. Default Ruff passes the four touched phase/candidate test files; loop scoped E/F passes.

These are local deterministic adapter tests with estimated usage. No live provider calls or broad full-suite success is claimed. Previously suspected global test pollution remains unproven.
