# R2 global-state isolation failure

The two failing global-isolation assertions correctly detect that an earlier
test changed the parent process session.MINI_CODE_DIR and SESSIONS_DIR without
restoring them. Child-process initialization is not the defect; the final
parent-process readback reused that helper. This reroutes later tests to the
prior tmp_path, while the isolated HOME itself remains unchanged.

A 324-file snapshot was copied from the immutable R2 source and verified
against its existing manifest before replay. With R2-equivalent isolated HOME,
the global-isolation file alone passes 16 tests; adding only the identified
polluter reproduces the original two failures (15 pass). The fix changes only
that polluter's parent-process path assignments to pytest monkeypatch. The
same sequence then passes 17 tests, and both full files pass 32. No production
source, conftest or global-isolation assertion changed. Child helper behavior
is preserved. Ruff E9/F and diff whitespace validation pass.

All original and corrected logs, source hashes, commands and protected-host
status are retained beside this note. The runner's protected fake HOME has no
.mini-code in all four runs; this is evidence about the controlled replay,
not an independent scan or disclosure of the user's personal state.
