# Functional audit: derive findings from current probes

Contract: Given the runtime tool registry and this run's required-field, metadata and conversational fact probes, the audit must report observed failures, link the actual affected capabilities, and exit nonzero for a failed capability; repaired probes must clear their stale findings without changing unknown/partial coverage.

## Changes

- TOOL-002 reads actual `file_line_count.is_read_only` and `.is_concurrency_safe`. Both booleans appear in capability evidence. No old fixed failed-tool set remains.
- TOOL-003 uses all actual `required_rejects_empty` failures, sorted deterministically. The aggregate issue identifies observed tools; every affected capability has a failure status and TOOL-003 link. No seven-tool allowlist remains, and special web summaries cannot overwrite a contract failure.
- `memory.conversation_fact` uses existing `ordinaryFactPersisted` rather than a fixed `fail`. Its deterministic/truthfulness verdict and evidence are probe-derived; its other partial fields and all other surfaces remain unchanged. A false fact probe emits a failed capability and CLI exit 1, rather than crashing an assertion before writing an audit.
- Normal audit still enumerates exactly 207 capabilities and 59 registered tools. Exit 0; no findings. Status counts: pass 129, partial 55, fail 0, unavailable 1, blocked 6, not_reachable 16, not_tested 0.

## Test signal

The existing full offline inventory/reproducibility checks remain. Three new bounded fault cases replace only the relevant runtime boundary: bad actual metadata; a missing-required validator on json_format (outside the historical seven); and a false conversational fact probe. Each requires CLI exit 1 and the matching capability's actual failed evidence. The metadata and validator cases require exactly the right issue and no unrelated fixed issue.

`functional-audit-dynamic-before.log`: final-direction tests failed on old runner (3 failed). `functional-audit-dynamic-after.log`: localhost binding unavailable in restricted sandbox; preserved as environment evidence. `functional-audit-dynamic-after-localhost.log`: exposed the remaining fixed memory status (5 passed, 1 failed). `functional-audit-dynamic-final.log`: 7 passed in 44.26s with authorized local loopback fixture access. No live network/provider calls.

Final report: `functional-audit-final.json`. Default Ruff passes test_runner; scoped E/F passes both changed files. The runner's broader historical style warnings are outside this repair.

Same-test history verifier: PROVEN, fixed 7 passed (53.63s), baseline 5 failed / 2 passed (51.06s), substantive stale-finding/capability and false-memory handling assertions, in `functional-audit-real-proof.json`; baseline is an exact git archive of 3637aa63 (tools fixed, runner still old), identified in `functional-audit-real-before-manifest.json`. No synthetic production mutation is used for the history comparison.
