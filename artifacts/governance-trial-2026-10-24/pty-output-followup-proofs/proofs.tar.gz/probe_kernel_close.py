"""Actual Darwin PTY close/read behavior, no patched calls or scheduling sleeps."""
import hashlib
import json
import os
import platform
import pty
import select
import subprocess
import sys
from pathlib import Path

results=[]
for keep_slave in (False, True):
    master, slave = pty.openpty()
    child = subprocess.Popen(['/bin/echo', 'integration_test_ok'], stdin=slave,
                             stdout=slave, stderr=slave, close_fds=True,
                             start_new_session=True)
    if not keep_slave:
        os.close(slave)
    assert child.wait(timeout=3) == 0
    ready = select.select([master], [], [], 0)[0]
    data = os.read(master, 65536) if ready else None
    if keep_slave:
        os.close(slave)
    os.close(master)
    results.append({'parentRetainedSlave': keep_slave, 'returnCode': child.returncode,
                    'readableAfterChildExit': bool(ready),
                    'capturedBytes': None if data is None else data.decode()})
report={'platform': platform.platform(), 'python': sys.version, 'results': results,
        'scope': 'Actual local kernel semantics; not the unknown original CI interleaving.'}
Path(sys.argv[1]).write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
assert results[1]['capturedBytes'] == 'integration_test_ok\r\n'
if sys.platform == 'darwin':
    assert results[0]['capturedBytes'] == ''
