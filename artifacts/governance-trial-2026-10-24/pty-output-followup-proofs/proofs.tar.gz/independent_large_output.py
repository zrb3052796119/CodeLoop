import hashlib,json,os
from pathlib import Path
import sys,tempfile,time
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
sys.path[:0]=[str(root),'/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/lib/python3.12/site-packages']
import minicode.tools.run_command as command
from minicode.tooling import ToolContext
assert Path(command.__file__).resolve()==root/'minicode/tools/run_command.py'
source=Path(command.__file__).read_bytes()
program="import os; data=b'PTY_HEAD\\n'+b'x'*500000+b'\\nPTY_TAIL\\n'; offset=0\nwhile offset<len(data): offset+=os.write(1,data[offset:])"
started=time.monotonic()
with tempfile.TemporaryDirectory(prefix='minicode-pty-independent-') as workspace:
 result=command.run_command_tool.run(command.run_command_tool.validator({'command':sys.executable,'args':['-c',program],'timeout':5}),ToolContext(cwd=workspace,permissions=None))
assert result.ok, result.output
assert result.output.startswith('PTY_HEAD') and result.output.endswith('PTY_TAIL')
assert 'lines omitted' in result.output
assert len(result.output)<command.MAX_OUTPUT_CHARS+1024
assert Path(command.__file__).read_bytes()==source
report={'source':str(Path(command.__file__)),'sourceSha256':hashlib.sha256(source).hexdigest(),'python':sys.version,'resultOk':result.ok,'originalPayloadBytes':500019,'outputCharacters':len(result.output),'maxCaptureBytes':command.MAX_OUTPUT_CHARS,'headPreserved':True,'tailPreserved':True,'truncationReported':True,'truncationForm':'lines omitted', 'initialProbeCorrection':'The first independent probe wrongly required output truncated; this existing multiline helper uses lines omitted. The failed probe is retained and is not a product finding.','elapsedSeconds':time.monotonic()-started,'scope':'One real Python child and real PTY; no mocks or provider/API calls. Bounded-capture smoke only, not a full-suite or memory-allocation benchmark.'}
out=Path(__file__).with_suffix('.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
