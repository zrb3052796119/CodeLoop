"""Real PTY final empty-readiness boundary; module-local wrappers only."""
import builtins
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace
root=Path(sys.argv[1]);source=Path(sys.argv[2]);output=Path(sys.argv[3])
sys.path.insert(0,str(root))
from minicode.tooling import ToolContext, ToolTerminationReason
from minicode.turn_cancellation import TurnCancellationToken
results=[]
for control in ('cancel','deadline'):
    events=[]
    token=TurnCancellationToken('turn_'+'e'*32)
    with tempfile.TemporaryDirectory() as workspace:
        context=ToolContext(cwd=workspace,permissions=None,_cancellation_token=token)
        def popen(argv,**kwargs):
            child=subprocess.Popen(argv,**kwargs)
            assert child.wait(timeout=5)==0
            return child
        def readiness(readers,writers,errors,timeout=None):
            actual=select.select(readers,writers,errors,timeout)
            if timeout==0 and not actual[0]:
                events.append('final-empty-readiness')
                if control=='cancel':token.request()
                else:context._task_deadline_monotonic=time.monotonic()-1
            return actual
        local_select=SimpleNamespace(**{**vars(select),'select':readiness})
        real_import=builtins.__import__
        def local_import(name,globals=None,locals=None,fromlist=(),level=0):
            return local_select if name=='select' else real_import(name,globals,locals,fromlist,level)
        module=ModuleType('isolated_final_checkpoint');module.__file__=str(source)
        module.__dict__['__builtins__']={**vars(builtins),'__import__':local_import}
        sys.modules[module.__name__]=module
        exec(compile(source.read_bytes(),str(source),'exec'),module.__dict__)
        module.subprocess=SimpleNamespace(**{**vars(subprocess),'Popen':popen})
        tool=module.run_command_tool
        result=tool.run(tool.validator({'command':'echo','args':['final-checkpoint-output']}),context)
        expected=ToolTerminationReason.TURN_CANCELLED if control=='cancel' else ToolTerminationReason.DEADLINE_EXCEEDED
        results.append({'control':control,'events':events,'ok':result.ok,'reason':None if result._termination_reason is None else result._termination_reason.value,'expectedReason':expected.value,'passed':not result.ok and result._termination_reason is expected})
report={'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'results':results,'scope':'Controlled final-drain guard sensitivity; not an observed original CI defect.'}
output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
assert all(item['passed'] for item in results)
