# Independent PTY review

GO for this scoped fix. No remaining reproducible blocking finding. This is a code and evidence review, not full-suite or native platform-matrix acceptance.

Reviewed final source SHA-256 `750fddb1f2011bb617f2b779626853a4348dff8cafa3cdf513fd84125f2b0562` and final lifecycle test SHA-256 `a428918666d9133611cf874cea2297d9bc0d8a3f53fba50ca38740348c5a1e5d`. No repository source was changed by this reviewer; no provider/API call or heavy suite was run.

## Causality and implementation

The real PTY/child probes isolate two permitted failure schedules: on Darwin, closing the last slave before the master reads can discard output; separately, a real empty select followed by child write/exit lets the old poll-and-break path skip ready bytes. These explain concrete failure mechanisms. They do not recover the exact unrecorded CI scheduler interleaving.

The final loop polls the leader before reading, cleans its owned process group once before final drain, and retains the parent slave through the drain. Continuous readable output cannot prevent the next leader-status and deadline/cancellation checks. Nested `finally` closes both descriptors even if cleanup raises; the existing spawn-failure case still covers both descriptors. Existing OSError/EIO and EOF handling is retained.

The drain uses a zero-timeout readiness query after exit; the master FD itself is not switched to `O_NONBLOCK`. Shared checkpoints remain per iteration and after cleanup. Review identified a final empty-readiness boundary that also needed a checkpoint; the final source now checks before the successful break. The real-token/deadline probe passes, while deleting that one checkpoint yields incorrect success for both controls. This is synthetic guard-sensitivity evidence, not another historical CI bug.

## Evidence and verification

- Author's identical final tests: old source **4 failed / 12 deselected**, final source **4 passed / 12 deselected** (`same-tests-final-meta.json`, `before-final.log`, `after-final.log`). The final pair checks actual imported source identity after HOME isolation.
- Author's related run: **19 passed in 3.40s**: 16 lifecycle, the original agent integration node, and two existing truncation cases (`after-related-meta.json`, `after-related.log`). These overlap the four cases above; do not add them together.
- Independent reviewer smoke: one real Python child wrote **500,019 bytes** through the real tool/PTY. Success retained both end markers, a truncation notice, and **200,052 output characters**, including presentation marker overhead; elapsed 0.079s (`independent_large_output.*`). The existing bounded capture implementation is unchanged. This is not a memory-allocation benchmark.

Invalid preload/overlay attempts were rejected by import identity or HOME isolation and are not counted. The reviewer's first output probe expected the wrong truncation wording; its `invalid-marker` files are retained. The multiline formatter uses `lines omitted`. Correcting the probe expectation passed without any source change.

## Bounds

The inherited process-group cleanup has its own bounded grace/wait behavior. This review does not promise zero deadline overrun during cleanup or control of descendants that escape the owned process group. EIO/EOF handling was reviewed against unchanged logic; no new direct EIO fault injection was run. Full candidate and native-platform acceptance remain separate.
