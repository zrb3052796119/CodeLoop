import hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
label=sys.argv[1]
argv=['/Users/zhourunbo/code/coding agent/MiniCode-Python-main/.venv-acceptance/bin/python','-m','pytest','-q',*sys.argv[2:]]
env={k:v for k,v in os.environ.items() if not k.startswith('MINI_CODE_') and not any(t in k for t in ('TOKEN','API_KEY','SECRET','PASSWORD','CREDENTIAL'))}
home=p/('home-'+label);home.mkdir(exist_ok=True)
env.update(HOME=str(home),PYTHONPATH=str(root))
t=time.monotonic()
with (p/(label+'.log')).open('w') as f:
 r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
meta={'argv':argv,'cwd':str(root),'exitCode':r.returncode,'seconds':time.monotonic()-t,'sourceSha256':hashlib.sha256((root/'minicode/tools/run_command.py').read_bytes()).hexdigest(),'testSha256':hashlib.sha256((root/'tests/test_run_command_lifecycle.py').read_bytes()).hexdigest()}
(p/(label+'-meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2));print((p/(label+'.log')).read_text())
