"""Real PTY/echo causal ordering probe; no repository or global stdlib edits."""
import builtins
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace

root = Path(sys.argv[1]).resolve()
source = Path(sys.argv[2]).resolve()
output = Path(sys.argv[3]).resolve()
sys.path.insert(0, str(root))
from minicode.agent_loop import run_agent_turn
from minicode.mock_model import MockModelAdapter
from minicode.tooling import ToolRegistry

assert Path('/bin/echo').is_file()
results = []
for schedule in ('write-before-select', 'retain-slave-write-before-select', 'retain-slave-write-between-select-and-poll'):
    events = []
    gate_read, gate_write = os.pipe()
    holder = {}
    real_import = builtins.__import__

    def popen(argv, **kwargs):
        assert argv == ['echo', 'integration_test_ok'], argv
        if schedule.startswith('retain-slave'):
            holder['retained_slave'] = os.dup(kwargs['stdout'])
        child_code = (
            f'import os; os.read({gate_read}, 1); '
            "os.execv('/bin/echo', ['echo', 'integration_test_ok'])"
        )
        child = subprocess.Popen([sys.executable, '-c', child_code],
                                 **{**kwargs, 'pass_fds': (gate_read,)})
        holder['process'] = child
        events.append({'event': 'real-child-started', 'pid': child.pid, 'requestedArgv': argv})
        return child

    def release_child():
        os.write(gate_write, b'x')
        code = holder['process'].wait(timeout=5)
        assert code == 0
        events.append({'event': 'real-echo-finished', 'returnCode': code})

    def controlled_select(readers, writers, errors, timeout=None):
        master = readers[0]
        holder['master'] = master
        if 'selected' not in holder:
            holder['selected'] = True
            if schedule.endswith('write-before-select'):
                release_child()
            ready = select.select(readers, writers, errors, timeout)
            events.append({'event': 'real-select-snapshot', 'readable': bool(ready[0])})
            if schedule.endswith('write-between-select-and-poll'):
                assert not ready[0]
                assert holder['process'].poll() is None
                release_child()
                events.append({'event': 'ready-after-child-exit',
                               'readable': bool(select.select(readers, [], [], 0)[0])})
            return ready
        return select.select(readers, writers, errors, timeout)

    def close(fd):
        if fd == holder.get('master'):
            # Observe bytes only after production has decided to close the PTY.
            # This cannot feed the returned capture or make its read loop pass.
            if select.select([fd], [], [], 0)[0]:
                try:
                    remaining = os.read(fd, 65536)
                except OSError as error:
                    events.append({'event': 'master-close', 'unreadError': error.errno})
                else:
                    events.append({'event': 'master-close', 'unreadBytes': remaining.decode()})
        os.close(fd)

    local_select = SimpleNamespace(**{**vars(select), 'select': controlled_select})

    def local_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == 'select':
            return local_select
        return real_import(name, globals, locals, fromlist, level)

    module = ModuleType('isolated_run_command')
    module.__file__ = str(source)
    module.__dict__['__builtins__'] = {**vars(builtins), '__import__': local_import}
    sys.modules[module.__name__] = module
    exec(compile(source.read_bytes(), str(source), 'exec'), module.__dict__)
    module.subprocess = SimpleNamespace(**{**vars(subprocess), 'Popen': popen})
    module.os = SimpleNamespace(**{**vars(os), 'close': close})
    try:
        with tempfile.TemporaryDirectory() as workspace:
            messages = run_agent_turn(
                model=MockModelAdapter(), tools=ToolRegistry([module.run_command_tool]),
                messages=[{'role': 'user', 'content': '/cmd echo integration_test_ok'}],
                cwd=workspace, permissions=None,
            )
        tool = next(m for m in reversed(messages) if m['role'] == 'tool_result')
        assistant = next(m for m in reversed(messages) if m['role'] == 'assistant')
        results.append({'schedule': schedule, 'events': events, 'toolResult': tool,
                        'assistant': assistant, 'expectedTokenPreserved': 'integration_test_ok' in assistant['content']})
    finally:
        os.close(gate_read)
        os.close(gate_write)
        if 'retained_slave' in holder:
            os.close(holder['retained_slave'])
        child = holder.get('process')
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)

report = {'source': str(source), 'sourceSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'sourceRoot': str(root), 'python': sys.version, 'results': results,
          'scope': 'Permitted controlled ordering, not recovery of the CI interleaving; real echo/PTY/agent/MockModel.'}
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if sys.platform == 'darwin':
    assert not results[0]['expectedTokenPreserved']
assert results[1]['expectedTokenPreserved']
assert results[2]['toolResult']['isError'] is False
assert results[2]['assistant']['content'] == 'I received the tool result:\n\n'
assert any('integration_test_ok' in e.get('unreadBytes', '') for e in results[2]['events'])
