"""Load an exact source overlay before pytest's configured pythonpath insertion."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

p=Path(__file__).parent
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
if len(sys.argv)>1 and sys.argv[1]=='child':
    source_root=Path(os.environ['PTY_SOURCE_ROOT'])
    sys.path.insert(0,str(source_root))
    import pytest
    class SourceIdentity:
        def pytest_sessionstart(self, session):
            # Repository HOME isolation has run; now pin the source under test.
            sys.path.insert(0,str(source_root))
            module=importlib.import_module('minicode.tools.run_command')
            imported=Path(module.__file__).resolve()
            expected=Path(os.environ['PTY_SOURCE_FILE']).resolve()
            assert imported==expected,(imported,expected)
            print(json.dumps({'importedSource':str(imported),'sourceSha256':hashlib.sha256(imported.read_bytes()).hexdigest()},indent=2),flush=True)
    raise SystemExit(pytest.main(sys.argv[2:],plugins=[SourceIdentity()]))

overlay=p/'original-overlay'
for package in ('minicode','minicode/tools'):
    target=overlay/package;target.mkdir(parents=True,exist_ok=True)
    for item in (root/package).iterdir():
        if item.name=='__pycache__' or (package=='minicode' and item.name=='tools') or (package=='minicode/tools' and item.name=='run_command.py'):
            continue
        link=target/item.name
        if not link.exists():link.symlink_to(item,target_is_directory=item.is_dir())
original=overlay/'minicode/tools/run_command.py';original.write_bytes((p/'original_run_command.py').read_bytes())
args=['-q','-o','pythonpath=','-o',f'cache_dir={p}/pytest-cache','--randomly-seed=20261024','tests/test_run_command_lifecycle.py','-k','preserves_output_written_before_child_exit or final_drain_honors']
argv=[sys.executable,str(Path(__file__)),'child',*args]
reports=[]
for label,source_root in [('before-final',overlay),('after-final',root)]:
    env={k:v for k,v in os.environ.items() if not k.startswith('MINI_CODE_') and not any(t in k for t in ('TOKEN','API_KEY','SECRET','PASSWORD','CREDENTIAL'))}
    home=p/('home-'+label);home.mkdir(exist_ok=True)
    source=source_root/'minicode/tools/run_command.py'
    env.update(HOME=str(home),PYTHONPATH=str(source_root),PTY_SOURCE_ROOT=str(source_root),PTY_SOURCE_FILE=str(source))
    started=time.monotonic()
    with (p/(label+'.log')).open('w') as out:
        result=subprocess.run(argv,env=env,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=60)
    reports.append({'label':label,'argv':argv,'cwd':str(root),'sourceRoot':str(source_root),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'testSha256':hashlib.sha256((root/'tests/test_run_command_lifecycle.py').read_bytes()).hexdigest(),'exitCode':result.returncode,'seconds':time.monotonic()-started})
(p/'same-tests-final-meta.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
assert reports[0]['exitCode']==1 and reports[1]['exitCode']==0
assert reports[0]['testSha256']==reports[1]['testSha256']
