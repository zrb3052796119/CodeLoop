from pathlib import Path
import ast
p=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main/minicode/agent_loop.py')
s=p.read_text()
Path('/private/tmp/codeloop-governance-20261024/phase1-implementation/agent_loop.before-review-fix.py').write_text(s)
s=s.replace('from typing import TYPE_CHECKING, Any, Callable', 'from typing import TYPE_CHECKING, Any, Callable, Literal')
s=s.replace('    ContextCompactor,\n    AutoCompactConfig,', '    ContextCompactor,\n    CompactionResult,\n    AutoCompactConfig,',1)
s=s.replace('''    """Reactive recovery may replace the canonical list, unlike proactive paths."""

    recovered: bool
    messages: list[ChatMessage]
''','''    """Successful recovery awaiting canonical rebinding and observation.

    The loop must install messages before manager synchronization or any event
    can interrupt the turn. This record carries only this operation's facts.
    """

    messages: list[ChatMessage]
    result: CompactionResult
    context_operation_id: str | None
    messages_before: int | None
    kind: Literal["cybernetic", "compactor"]
''',1)
a=s.index('def _recover_overflow_context(');b=s.index('\ndef _revalidate_prompt_memory(',a)
part=s[a:b]
part=part.replace('    context_manager: ContextManager | None,\n','',1).replace(') -> ContextRecovery:',') -> ContextRecovery | None:',1)
for branch, expression in [('cybernetic','recovered_messages'),('compactor','recovery_result.messages')]:
    start=part.index('        if recovery_result and recovery_result.effective:') if branch=='cybernetic' else part.index('        if recovery_result and recovery_result.effective:',part.index('    elif context_compactor:'))
    end=part.index('            return ContextRecovery(True, current_messages)\n',start)+len('            return ContextRecovery(True, current_messages)\n')
    part=part[:start]+f'''        if recovery_result and recovery_result.effective:
            return ContextRecovery(
                messages=retention.reconcile({expression}),
                result=recovery_result,
                context_operation_id=context_operation_id,
                messages_before=recovery_messages_before,
                kind="{branch}",
            )
'''+part[end:]
part=part.replace('    return ContextRecovery(False, current_messages)','    return None')
part+='''def _complete_context_recovery(
    recovery: ContextRecovery,
    context_manager: ContextManager | None,
    event_sink: AgentEventSink | None,
    step: int,
) -> None:
    """Observe only after the loop has rebound its canonical transcript."""
    if context_manager:
        context_manager.messages = recovery.messages
    if recovery.context_operation_id is not None and recovery.messages_before is not None:
        emit_context_compaction_safely(
            event_sink,
            recovery.result,
            step=step,
            context_operation_id=recovery.context_operation_id,
            path=f"reactive_{recovery.kind}",
            messages_before=recovery.messages_before,
            messages_after=_observable_message_count(recovery.messages),
        )
        emit_recovery_completed_safely(
            event_sink,
            recovery.result,
            step=step,
            context_operation_id=recovery.context_operation_id,
            kind=recovery.kind,
            messages_before=recovery.messages_before,
            messages_after=_observable_message_count(recovery.messages),
        )
    logger.info(
        "Cybernetics Reactive recovered: freed %d tokens"
        if recovery.kind == "cybernetic"
        else "Reactive Compact recovered: freed %d tokens",
        recovery.result.tokens_freed,
    )

'''
s=s[:a]+part+s[b:]
s=s.replace('''                    recovery = _recover_overflow_context(
                        current_messages,
                        context_manager=context_manager,''','''                    recovery = _recover_overflow_context(
                        current_messages,''',1)
s=s.replace('''                    if recovery.recovered:
                        current_messages = recovery.messages
                        continue''','''                    if recovery is not None:
                        current_messages = recovery.messages
                        _complete_context_recovery(recovery, context_manager, event_sink, step)
                        continue''',1)
ast.parse(s)
p.write_text(s)
