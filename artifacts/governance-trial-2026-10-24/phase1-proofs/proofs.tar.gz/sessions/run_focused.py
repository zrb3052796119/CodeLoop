from pathlib import Path
import os,sys
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
evidence=Path('/private/tmp/codeloop-governance-20261024/phase1-subagent-sessions')
label=sys.argv[1]
for key in list(os.environ):
    if key.startswith('MINI_CODE_') or key in {'OPENAI_API_KEY','ANTHROPIC_API_KEY','GOOGLE_API_KEY','GEMINI_API_KEY','GROQ_API_KEY','DEEPSEEK_API_KEY','OPENROUTER_API_KEY','MOONSHOT_API_KEY','MISTRAL_API_KEY','AZURE_OPENAI_API_KEY','COHERE_API_KEY','XAI_API_KEY'}:
        os.environ.pop(key,None)
home=evidence/(label+'-home');home.mkdir(exist_ok=True)
os.environ['HOME']=str(home)
os.environ['MINICODE_PYTEST_REAL_HOME']='/Users/zhourunbo'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['PYTHONPATH']=str(root)+os.pathsep+str(evidence)
os.environ['PHASE1_IMPORT_PROOF']=str(evidence/(label+'-imports.json'))
os.chdir(root)
args=[sys.executable,'-m','pytest',*sys.argv[2:],'-q','--randomly-seed=20261024','--tb=short','-o','cache_dir='+str(evidence/(label+'-cache')),'-p','phase1_session_import_guard']
os.execv(sys.executable,args)
