import json,hashlib,os,sys
from pathlib import Path

def pytest_runtest_call(item):
    expected=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main').resolve()
    paths={}
    for name in ('minicode.tooling','minicode.tools.task','minicode.agent_loop'):
        module=sys.modules[name]
        path=Path(module.__file__).resolve()
        assert path.is_relative_to(expected),path
        paths[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    output=Path(os.environ['PHASE1_IMPORT_PROOF'])
    if not output.exists():
        output.write_text(json.dumps(paths,indent=2)+'\n')
