# Phase 1 context-retention 独立代码审查

结论：发现的 1 项 P2 抽取回归已修复，并通过同一反例复核；当前快照未发现其余可复现的阻塞问题。可以进入父级的 Phase 1 验收，但本审查不替代尚待执行的全量验收。

审查基线：`9f9369421486f018c837f84d21bd727aed6ab326`。工作树：`/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main`。最终 `minicode/agent_loop.py` SHA256：`0b47021135a64860caab6f27ced416ce4d366cde52acb82a777638870d267ad7`，与最终定向测试运行期导入证据及实施者冻结报告一致。本轮审查只读，未改源码、测试或提交 Git。ToolContext 单域迁移由本审阅者此前实现，下面对此部分属于兼容性复核；agent_loop 抽取为独立审阅。

## 已关闭的 P2：成功恢复的外层列表绑定晚于可中断观察

初版 `_recover_overflow_context` 仅在 helper 局部重绑恢复结果，先同步 ContextManager、发布 `context.compacted` / `recovery.completed`，再返回新列表给 loop。若事件接收器抛出 `KeyboardInterrupt` 或 `SystemExit`，按既有契约会直接传播；helper 没有返回，外层 `finally` 因而把 ContextManager 回写为旧的长列表。原内联实现会保留成功恢复后的列表。

相同实际 `run_agent_turn`、`ContextManager`、事件触发场景的差分结果：

- 基线：传播 `KeyboardInterrupt`，最终 manager 消息为 `successfully recovered context`。
- 初版抽取：传播相同异常，最终 manager 消息退回 `uncompressed long context`。
- 修复后：传播相同异常，最终 manager 再次保留 `successfully recovered context`。
- 三者事件序列一致：`model.started → model.failed → recovery.started → context.compacted → task.outcome`。差异确实来自成功结果的安装时机。

当前成功 helper 仅返回有界 `ContextRecovery`（消息、恢复结果、operation id、原消息数、恢复类别），见 `minicode/agent_loop.py:2518`；loop 在 `minicode/agent_loop.py:5068` 先更新自己的 canonical list，再由 `_complete_context_recovery`（2609 行）同步 manager、发成功事件和日志。失败观察仍留原分支，取消 / BaseException 未被吞掉。该次序恢复了原有语义。

复现和复核证据均在 `/private/tmp/codeloop-governance-20261024/phase1-context-review/`：`reactive_interrupt_probe.py`、`reactive-interrupt-before-final.log`、`reactive-interrupt-after-final.log`、`reactive-interrupt-after-fix.log`。初版未启用 work chain 的 probe 未进入恢复分支，是无效探测，未用于结论。

实施者新增的 8 参数回归覆盖 cybernetic/direct compactor × 两个成功事件 × KeyboardInterrupt/SystemExit，断言同一个异常实例、恢复输入不变、manager 保留恢复结果，以及事件顺序和 operation id。实施者保存了真实初版抽取的 8 失败证据，并在同字节 6 文件测试中得到基线 95 通过 / 修复后 95 通过；不是把基线绿的纯重构声称为历史缺陷修复。

## 核对范围与结果

- pre-request、high-water、reactive、predictive 原主体在显式 capture 参数和成功返回替换归一后，初版 AST 一致，记录在 `ast-equivalence.json`。随后成功 reactive 分拆经过上述跨函数状态次序复核；AST 一致本身不能证明无此类回归。
- pre/high 保留原地 slice 安装与回滚；原 `context_manager is not None` / truthiness 差别保留；memory guard 确认后才 finalize cybernetic/materialization 状态并发布成功事实。
- pre-request 仅转换 `ModelCallDeadlineExceeded`；high-water 先传播取消、转换 deadline、再吞普通异常；reactive 恢复异常继续原样传播；predictive 保留自己的异常边界。
- predictive 仍调用 `compact_messages(force=True)`，没有转成 reactive recovery，也没有消耗其 retry quota。
- `ContextRetention` 只借用 ledger 和当前 completion feedback 两个对象。旧 `reconcile_task_ledger` 调用点为 14，新 loop 现场构造点为 9；同一同步操作内可使用快照多次，没有跨模型请求缓存。双 host decision / 双 reactive recovery 测试确认第二次恢复看到更新后的 feedback。不能声称有 15 个 fresh 构造点。
- ToolContext 保留 slots、旧私有构造字段，通过只读 property 暴露 store，以显式 `with_subagent_sessions` 浅替换绑定。budget、cancel、permissions、mailbox、lifecycle 等共享对象不重新构造；实际并发测试检查了引用身份。生产 Runner 原契约就是 ToolContext；检索到的 SimpleNamespace Task 调用先替换了 `_run`，未发现真实生产路径依赖缺失 property 的 duck context。

## 验证范围和度量

独立执行两次定向验证（部分重复，不相加声称唯一用例数）：

- 修复前的常规路径检查：11 个选择器 / 17 个参数化用例全通过，`independent-targeted.log`，3.46 秒。覆盖新 feedback 回归、事件顺序、guard rejection/rollback、cybernetic finalize、取消和 deadline。
- 修复后：中断回归 8 项、direct recovery 成功 1 项、恢复异常身份 3 项、双 feedback 1 项，共 13 通过，`independent-after-fix.log`，4.73 秒。`import-proof-after-fix.json` 记录了实际工作树导入路径和 SHA；之后再次读文件 SHA 一致。

均使用独立 HOME，清除 MINI_CODE_* 与 API 凭证；无真实模型调用、无全量测试。另已读取实施者 `phase1-implementation/implementation-report.json`：最终 14 文件 336 通过、CI E/F Ruff 与 diff check 通过；这些是实施者结果，不冒充本审阅者重跑。

最终 AST 度量见 `measurements-after-fix.json`：`run_agent_turn` 5321 → 4824 行，函数体净减 497 行；并非整个模块净减 497。六个主要 helper 参数数为 11 / 7 / 7 / 4 / 3 / 4，另有 1 参数 count helper。没有新增模块、controller、gate 或吞并所有状态的 context。当前切片职责和状态所有权可审查，仍保留巨型 loop 的其他职责，后续切片需要另行判断。
