from pathlib import Path
import hashlib,json,sys,os

def pytest_runtest_call(item):
 root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
 evidence={}
 for name in ('minicode.agent_loop','minicode.tooling'):
  path=Path(sys.modules[name].__file__).resolve()
  assert path.is_relative_to(root),path
  evidence[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 out=Path(os.environ.get('PHASE1_REVIEW_IMPORT_PROOF', '/private/tmp/codeloop-governance-20261024/phase1-context-review/import-proof.json'))
 if not out.exists():out.write_text(json.dumps(evidence,indent=2)+'\n')
