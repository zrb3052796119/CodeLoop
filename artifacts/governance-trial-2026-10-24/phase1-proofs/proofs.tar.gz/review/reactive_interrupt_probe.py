from pathlib import Path
import importlib.util,json,os,sys
from unittest.mock import patch
root=Path('/Users/zhourunbo/.codex/worktrees/governance-context-retention/MiniCode-Python-main')
evidence=Path('/private/tmp/codeloop-governance-20261024/phase1-context-review')
label=sys.argv[1]
for key in list(os.environ):
 if key.startswith('MINI_CODE_') or key.endswith('_API_KEY'):os.environ.pop(key,None)
home=evidence/(label+'-interrupt-home');home.mkdir(exist_ok=True)
os.environ['HOME']=str(home);sys.path.insert(0,str(root));os.chdir(root)
if label=='before':
 import minicode
 spec=importlib.util.spec_from_file_location('minicode.agent_loop',evidence/'before_agent_loop.py')
 loop=importlib.util.module_from_spec(spec);sys.modules['minicode.agent_loop']=loop;spec.loader.exec_module(loop);minicode.agent_loop=loop
else:
 import minicode.agent_loop as loop
from minicode.context_manager import ContextManager
from minicode.context_compactor import CompactionResult,CompactStrategy,CompactTrigger
from minicode.tooling import ToolRegistry
from minicode.types import AgentStep
manager=ContextManager(model='default')
seen=[]
class Sink:
 def emit(self,name,**kwargs):
  seen.append(name)
  if name=='context.compacted':raise KeyboardInterrupt('interrupt after successful recovery')
class Model:
 calls=0
 def next(self,messages,**kwargs):
  self.calls+=1
  if self.calls==1:raise RuntimeError('prompt too long')
  return AgentStep(type='assistant',content='finished')
original=[{'role':'system','content':'uncompressed long context'}]
compacted=[{'role':'system','content':'successfully recovered context'}]
result=CompactionResult(success=True,strategy=CompactStrategy.REACTIVE,trigger=CompactTrigger.REACTIVE,messages=compacted,tokens_freed=100)
with patch.object(loop,'ContextCyberneticsOrchestrator',lambda *a,**k:None),patch.object(loop.ContextCompactor,'process_request',lambda _s,messages,**k:CompactionResult(success=False,strategy=CompactStrategy.FULL,trigger=CompactTrigger.AUTO,messages=messages)),patch.object(loop.ContextCompactor,'reactive_recover',lambda *_:result):
 try:
  loop.run_agent_turn(model=Model(),tools=ToolRegistry([]),messages=original,cwd=str(home),context_manager=manager,event_sink=Sink(),max_steps=3)
 except BaseException as error:
  failure=type(error).__name__+': '+str(error)
 else:failure=None
print(json.dumps({'module':loop.__file__,'failure':failure,'manager_messages':manager.messages,'events':seen},ensure_ascii=False))
